param([Parameter(Mandatory=$true)][string]$ArtifactRelative)
$hdDistributionResult = Get-Content -LiteralPath (Join-Path $ArtifactRelative 'result.json') -Raw | ConvertFrom-Json
if (-not $hdDistributionResult.cleanup.treeExited -or -not $hdDistributionResult.serverClosed) { throw 'Runtime cleanup is not terminal and accepted' }
$hdDistributionLive = @(Get-CimInstance Win32_Process)
$hdDistributionRows = @($hdDistributionResult.historicalRecordedIdentities | ForEach-Object {
    $hdDistributionRecorded = $_
    $hdDistributionCurrent = @($hdDistributionLive | Where-Object { $_.ProcessId -eq $hdDistributionRecorded.ProcessId })
    $hdDistributionBirth = if ($hdDistributionRecorded.CreationDate -is [datetime]) { $hdDistributionRecorded.CreationDate.ToUniversalTime() } else { [datetime]::Parse($hdDistributionRecorded.CreationDate).ToUniversalTime() }
    $hdDistributionExact = @($hdDistributionCurrent | Where-Object {
        $_.CreationDate.ToUniversalTime().Ticks -eq $hdDistributionBirth.Ticks -and $_.ExecutablePath -eq $hdDistributionRecorded.ExecutablePath
    })
    [ordered]@{ProcessId=$hdDistributionRecorded.ProcessId;CreationDateUtc=$hdDistributionBirth.ToString('o');ExecutablePath=$hdDistributionRecorded.ExecutablePath;currentPidPresent=($hdDistributionCurrent.Count -gt 0);exactIdentityPresent=($hdDistributionExact.Count -gt 0)}
})
[ordered]@{checkedAt=(Get-Date).ToUniversalTime().ToString('o');runtime=$ArtifactRelative;comparison='PID, executable path and exact UTC DateTime ticks';rows=$hdDistributionRows} |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath 'build/mobile-distribution-owned-historical-after-20261011.json' -Encoding utf8
if (@($hdDistributionRows | Where-Object { $_.exactIdentityPresent }).Count -ne 0) { throw 'An exact recorded owned browser identity still exists' }
$hdDistributionServicePids = @(Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
$hdDistributionServiceIdentities = @($hdDistributionServicePids | ForEach-Object {
    Get-CimInstance Win32_Process -Filter "ProcessId = $_" | Select-Object ProcessId, ExecutablePath, @{Name='CreationDateUtc';Expression={$_.CreationDate.ToUniversalTime().ToString('o')}}
})
$hdDistributionServiceHttp = (Invoke-WebRequest -Uri 'http://localhost:8080/' -UseBasicParsing).StatusCode
[ordered]@{checkedAt=(Get-Date).ToUniversalTime().ToString('o');listenPort=8080;identities=$hdDistributionServiceIdentities;httpStatus=$hdDistributionServiceHttp} |
    ConvertTo-Json -Depth 6 | Set-Content -LiteralPath 'build/mobile-distribution-user-service-after-20261011.json' -Encoding utf8
Write-Output "Historical owned identities checked: $($hdDistributionRows.Count); exact survivors: 0; user service HTTP: $hdDistributionServiceHttp"
