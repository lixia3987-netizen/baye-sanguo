// Generate only after the three accepted actual runs, all failed attempts,
// cleanup and immutable archive exist. Classic FIRE remains pending.
// This file is a dormant writer; creating it does not accept pending runs.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import assert from 'node:assert/strict';

const base='build/fire-window-20261011',stem='m5-fire-window-20261011';
const validation='docs/validation',archivePath=`${validation}/${stem}-archive.json`;
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
const json=v=>JSON.stringify(v,null,2)+'\n';
const array=(v,label)=>{assert.ok(Array.isArray(v),label);return v;};
const empty=(v,label)=>assert.equal(array(v,label).length,0,label);
const terminal=(r,name)=>{
 assert.ok(Number.isFinite(Date.parse(r.startedAt)),`${name}: startedAt`);
 assert.ok(Number.isFinite(Date.parse(r.finishedAt)),`${name}: terminal finishedAt`);
 assert.ok(Date.parse(r.finishedAt)>=Date.parse(r.startedAt),`${name}: ordered terminal timestamps`);
};
const archive=read(archivePath),bySource=new Map();
for(const entry of array(archive.entries,'archive entries')){
 assert.equal(typeof entry.source,'string');assert.ok(!bySource.has(entry.source),'unique archive source');
 bySource.set(entry.source,entry);
}
// Bind both the original source and its archived bytes, including gzip roundtrip.
const ref=source=>{
 const e=bySource.get(source);assert.ok(e,`Archive missing ${source}`);
 const raw=fs.readFileSync(source);assert.equal(raw.length,e.rawBytes,source);assert.equal(digest(raw),e.rawSha256,source);
 const target=path.resolve(validation,e.file),root=path.resolve(validation)+path.sep;
 assert.ok(target.startsWith(root),'archive path containment');
 const stored=fs.readFileSync(target);assert.equal(stored.length,e.bytes,source);assert.equal(digest(stored),e.sha256,source);
 const restored=e.file.endsWith('.gz')?zlib.gunzipSync(stored):stored;
 assert.equal(restored.length,raw.length,source);assert.equal(digest(restored),e.rawSha256,source);
 return e;
};
const optionalRef=source=>bySource.has(source)?ref(source):null;
const specs=[
 {name:'pc-1080-v1',width:1920,height:1080,classic:false,missingAssets:false},
 {name:'pc-720-v2',width:1280,height:720,classic:false,missingAssets:false},
 {name:'pc-missing-v1',width:1920,height:1080,classic:false,missingAssets:true}
];
const freeze=read(`${base}/fire5-product-freeze-v1-20261011.json`);
const sourceReview=read(`${base}/independent-review/fire5-frozen-product-source-review-v1.json`);
assert.equal(sourceReview.auditOk,true);assert.equal(freeze.checks.oldManifest.count,52);
assert.equal(freeze.checks.oldManifest.objectsAndOrderExact,true);assert.equal(freeze.checks.oldManifest.topLevelFieldsExact,true);
assert.equal(freeze.checks.newManifestCount,53);assert.equal(freeze.checks.forwardInverseExact,true);
assert.equal(freeze.native.rebuildRequired,false);assert.equal(freeze.native.aggregateMatchesInstalled,true);
for(const f of freeze.files){const b=fs.readFileSync(f.path);assert.equal(b.length,f.bytes,f.path);assert.equal(digest(b),f.sha256,f.path);}
const manifest=read('assets/hd-spe/manifest.json');assert.equal(manifest.entries.length,53);
const fire=manifest.entries.filter(e=>e.fireVersion===1);assert.equal(fire.length,1);assert.equal(fire[0].skillId,5);
assert.equal(manifest.libSha256,'3bd20146084054163d045c90987c756a6a210664e78253cc56bc4a274727903e');
for(const a of freeze.fire5.art){const b=fs.readFileSync(a.path);assert.equal(b.length,a.bytes);assert.equal(digest(b),a.sha256);}

const suite=read(`${base}/final-suite-v2/result.json`);terminal(suite,'final suite v2');
assert.equal(suite.exitCode,0);assert.equal(suite.executionConcurrency,1);assert.equal(suite.modules,89);
assert.equal(suite.counts.tests,4339);assert.equal(suite.counts.pass,4339);
for(const k of ['fail','cancelled','skipped','todo'])assert.equal(suite.counts[k],0,k);
empty(suite.sourceDrift,'suite source drift');assert.equal(array(suite.sources,'suite sources').length,228);
const cleanup=read(`${base}/cleanup-verification.json`);
assert.equal(cleanup.ok,true);empty(cleanup.survivors,'historical survivors');empty(cleanup.privateListeners,'private listeners');
assert.equal(cleanup.userUnchanged,true);assert.equal(cleanup.userHttpStatus,200);assert.equal(cleanup.userService.ProcessId,57860);
assert.ok(Number.isInteger(cleanup.recordedCount)&&cleanup.recordedCount>0);
assert.ok(Number.isInteger(cleanup.attemptCount)&&cleanup.attemptCount>=8);

function sources(r,name){
 const v=r.sourceVerification;assert.equal(v.ok,true,`${name}: source verification`);
 empty(v.drift,`${name}: source drift`);empty(v.added,`${name}: added source`);assert.equal(v.runnerMatch,true);
 assert.ok(Number.isInteger(v.count)&&v.count>0);assert.equal(v.sources.length,v.count);
 for(const pinned of freeze.files){const actual=v.sources.find(f=>f.path===pinned.path);assert.ok(actual,`${name}: ${pinned.path}`);assert.equal(actual.bytes,pinned.bytes);assert.equal(actual.sha256,pinned.sha256);}
 assert.equal(r.nativeSourceCheck.count,128);assert.equal(r.nativeSourceCheck.aggregate,freeze.native.aggregateSha256);
 assert.equal(r.engineManifest.engineSourceSha256,freeze.native.aggregateSha256);
}
function cleanupRun(r,name){
 assert.equal(r.cleanup.treeExited,true,`${name}: owned tree exited`);
 assert.equal(r.isolation.cleaned,true);assert.equal(r.isolation.chromeExited,true);assert.equal(r.isolation.httpClosed,true);
 assert.equal(r.isolation.user8080Touched,false);assert.equal(r.directoriesDeleted,false);assert.equal(r.profileRetained,true);
}
const unit=(snapshot,index)=>array(snapshot.units,'actual units').find(u=>u.i===index);
function summarizeAttempt(a,index){
 assert.equal(a.skill.id,5);assert.equal(a.skill.speId,35);
 const actorBefore=unit(a.before,a.actor.i),actorAfter=unit(a.after,a.actor.i),before=unit(a.before,a.target.i),after=unit(a.after,a.target.i);
 assert.ok(actorBefore&&actorAfter&&before,'sampled actual actor and target');
 return {attempt:index+1,weatherBefore:a.before.weather,actor:{slot:a.actor.i,nativeToken:a.actor.id,name:a.actor.name},target:{slot:a.target.i,nativeToken:a.target.id,name:a.target.name},
  mpBefore:actorBefore.mp,mpAfter:actorAfter.mp,armsBefore:before.arms,armsAfter:after?.arms??0,damage:before.arms-(after?.arms??0)};
}
function actual(spec){
 const p=`${base}/${spec.name}`,r=read(`${p}/result.json`);terminal(r,spec.name);
 assert.equal(r.preflightOnly,false);assert.equal(r.staged,false);assert.equal(r.ok,true);assert.equal(r.accepted,true);assert.equal(r.actualCastAccepted,true);
 assert.equal(r.classic,spec.classic);assert.equal(r.missingAssets,spec.missingAssets);assert.deepEqual(r.viewport,{width:spec.width,height:spec.height});
 const fallback=spec.classic||spec.missingAssets;assert.equal(r.hdAccepted,!fallback);assert.equal(r.fallbackAccepted,fallback);
 empty(r.exceptions,'actual exceptions');empty(r.observerErrors,'observer errors');sources(r,spec.name);cleanupRun(r,spec.name);
 assert.equal(r.actualLib.sha256,manifest.libSha256);
 const pixo=r.nativePixelOracle;assert.ok(pixo);assert.equal(pixo.sourceCopies,8);assert.ok(pixo.actualLcdCallbacks>0&&pixo.events>0);
 assert.ok(pixo.labels>0&&pixo.numericReadbacks>0&&pixo.completedHoldReadbacks>0,'actual label, NUM and native HOLD');
 assert.equal(pixo.outsidePixelsPerHdReadback,11200);
 const verified=array(pixo.verified,'verified readbacks');assert.ok(verified.length>0);
 for(const v of verified){assert.equal(v.nativeRgbaSha256,v.independentExpectedSha256);assert.equal(v.source,fallback?'lcd':'hd-assets');}
 if(fallback){assert.equal(pixo.movieHd,0);assert.equal(pixo.postHd,0);assert.ok(pixo.fallbackReadbacks>=2);assert.equal(pixo.outsidePixelComparisons,0);}
 else{assert.ok(pixo.movieHd>=2&&pixo.postHd>0);assert.equal(pixo.fallbackReadbacks,0);assert.equal(pixo.outsidePixelComparisons,(pixo.movieHd+pixo.postHd)*11200);}
 if(spec.missingAssets)assert.ok(r.requests.some(q=>q.status===404&&q.expected&&fire[0].pictures.some(f=>'/'+f.src===q.url)),'actual exact FIRE image404');
 const captures=array(r.skillCaptures,'actual captures').filter(c=>c.spe?.active&&c.spe.id===35&&c.spe.kind===2&&c.spe.contextKnown===true&&c.spe.skillId===5||
  c.result?.active&&c.result.speId===35&&c.result.skillId===5&&c.result.display?.valid);
 assert.ok(captures.length);for(const c of captures){assert.deepEqual(c.before,c.after);if(c.callbackBefore)assert.deepEqual(c.callbackBefore,c.callbackAfter);}
 const first=Math.min(...captures.map(c=>c.at)),last=Math.max(...captures.map(c=>c.at));assert.ok(Number.isFinite(first)&&Number.isFinite(last));
 const readonlyKeys=array(r.engineInputs,'actual engine inputs').filter(k=>k.at>=first&&k.at<=last);assert.equal(readonlyKeys.length,0,'no extra key during captured movie/NUM/HOLD');
 const attempts=array(r.fireAttempts,'legal FIRE attempts').map(summarizeAttempt);assert.ok(attempts.length>0);
 const nativeResult=captures.find(c=>c.result?.active&&c.result.skillId===5&&c.result.display?.digits?.length)?.result;
 assert.ok(nativeResult,'actual native numeric result');assert.equal(nativeResult.resultKind,1);
 const matched=r.fireAttempts.findIndex(a=>a.actor.i===nativeResult.actorIndex&&a.target.i===nativeResult.targetIndex&&
  (!a.resultOwnerAfter||a.resultOwnerAfter.session===nativeResult.session));
 assert.ok(matched>=0,'actual result belongs to a public legal attempt');assert.equal(attempts[matched].damage,nativeResult.value);
 const selectedImages=archive.entries.filter(e=>e.source.startsWith(p+'/')&&e.source.endsWith('.png')).map(e=>ref(e.source));
 return {name:spec.name,viewport:r.viewport,classic:r.classic,missingAssets:r.missingAssets,accepted:true,actualCastAccepted:true,hdAccepted:r.hdAccepted,fallbackAccepted:r.fallbackAccepted,
  startedAt:r.startedAt,finishedAt:r.finishedAt,phases:r.phases.length,publicInputs:r.inputs.length,engineInputs:r.engineInputs.length,sourceCount:r.sourceVerification.count,
  fireAttempts:attempts,appliedResult:{session:nativeResult.session,kind:nativeResult.resultKind,value:nativeResult.value,attempt:matched+1},
  readonlyExtraKeys:readonlyKeys.length,pixels:{...pixo,verified:undefined,verifiedReadbacks:verified.length},
  native:{count:r.nativeSourceCheck.count,aggregate:r.nativeSourceCheck.aggregate,installed:r.engineManifest},scope:r.scope,
  evidence:ref(`${p}/result.json`),executedTool:ref(`${p}/executed-tool.mjs`),captures:ref(`${p}/native-skill-captures.json`),
  sourceVerification:ref(`${p}/source-verification.json`),engineInputEvidence:ref(`${p}/engine-inputs.json`),selectedImages};
}
// These reads and assertions must all succeed before any document is written.
const runs=specs.map(actual),failedPath=`${base}/pc-720-v1`,failed=read(`${failedPath}/result.json`);
terminal(failed,'pc-720-v1');assert.equal(failed.ok,false);assert.equal(failed.accepted,false);assert.equal(failed.actualCastAccepted,false);
assert.equal(failed.hdAccepted,false);assert.equal(failed.fallbackAccepted,false);assert.equal(failed.preflightOnly,false);
assert.equal(failed.fireAttempts.length,3);assert.equal(failed.skillCaptures.length,0);sources(failed,'pc-720-v1');cleanupRun(failed,'pc-720-v1');
const classicFailedPath=`${base}/pc-classic-v1`,classicFailed=read(`${classicFailedPath}/result.json`);
terminal(classicFailed,'pc-classic-v1');
for(const k of ['ok','accepted','actualCastAccepted','hdAccepted','fallbackAccepted','preflightOnly'])assert.equal(classicFailed[k],false,`classic failed: ${k}`);
assert.equal(classicFailed.classic,true);assert.match(classicFailed.error,/Timed out waiting for one classic AIM cursor ACK/);
assert.equal(classicFailed.skillCaptures.length,0);sources(classicFailed,'pc-classic-v1');cleanupRun(classicFailed,'pc-classic-v1');
const classicModeAt=classicFailed.inputs.findIndex(i=>i.type==='presentation-mode'&&i.mode==='classic');assert.ok(classicModeAt>=0);
const classicKeys=classicFailed.inputs.slice(classicModeAt+1).filter(i=>i.type==='key');assert.equal(classicKeys.length,1);assert.equal(classicKeys[0].key,'ArrowRight');
assert.equal(classicFailed.engineInputs.at(-1).code,37);
const classicBefore=classicFailed.failureState.battle,classicAfter=classicFailed.failureState.fight;
assert.equal(classicBefore.inputKind,5);assert.equal(classicAfter.inputKind,5);assert.equal(classicBefore.actorIndex,2);assert.equal(classicAfter.actorIndex,2);
assert.equal(classicBefore.inputSeq,147);assert.equal(classicAfter.inputSeq,147);
assert.deepEqual(classicBefore.focus,{x:11,y:15});assert.deepEqual([classicAfter.focusX,classicAfter.focusY],[12,15]);
const classicExecuted=fs.readFileSync(`${classicFailedPath}/executed-tool.mjs`,'utf8');assert.ok(classicExecuted.includes('f.inputSeq!==\'+f.inputSeq+'));
const classicReviewPath=`${base}/independent-review/classic-v1-aim-ack-source-review-v1.json`,classicReview=read(classicReviewPath);
assert.equal(classicReview.auditOk,true);assert.equal(classicReview.classification,'runner-ACK-expects-sequence-change-during-same-native-AIM');
const classicNaturalPath=`${base}/pc-classic-v2`,classicNatural=read(`${classicNaturalPath}/result.json`);
terminal(classicNatural,'pc-classic-v2');
for(const k of ['ok','accepted','actualCastAccepted','hdAccepted','fallbackAccepted','preflightOnly'])assert.equal(classicNatural[k],false,`classic natural: ${k}`);
assert.equal(classicNatural.classic,true);assert.match(classicNatural.error,/Actual standard-LIB FIRE5 was naturally produced/);
assert.equal(classicNatural.fireAttempts.length,4);assert.equal(classicNatural.skillCaptures.length,0);
sources(classicNatural,'pc-classic-v2');cleanupRun(classicNatural,'pc-classic-v2');
const classicLatestPath=`${base}/pc-classic-v3`,classicLatest=read(`${classicLatestPath}/result.json`);
terminal(classicLatest,'pc-classic-v3');
for(const k of ['ok','accepted','actualCastAccepted','hdAccepted','fallbackAccepted','preflightOnly'])assert.equal(classicLatest[k],false,`classic latest: ${k}`);
assert.equal(classicLatest.classic,true);assert.match(classicLatest.error,/Actual standard-LIB FIRE5 was naturally produced/);
assert.equal(classicLatest.fireAttempts.length,5);assert.equal(classicLatest.skillCaptures.length,0);
sources(classicLatest,'pc-classic-v3');cleanupRun(classicLatest,'pc-classic-v3');
const classicLatestAttempts=classicLatest.fireAttempts.map(summarizeAttempt);
assert.deepEqual(classicLatestAttempts.map(a=>a.weatherBefore),[3,3,3,2,2]);
for(const a of classicLatestAttempts){assert.equal(a.damage,0);assert.equal(a.mpBefore-a.mpAfter,15);}
const classicNaturalReviewPath=`${base}/independent-review/pc-classic-v2-v3-untriggered-review.json`,classicNaturalReview=read(classicNaturalReviewPath);
assert.equal(classicNaturalReview.auditOk,true);assert.equal(classicNaturalReview.actualAcceptance,false);assert.equal(classicNaturalReview.classicFireAcceptance,'pending');
const preflight=read(`${base}/preflight-v1/result.json`);terminal(preflight,'preflight');assert.equal(preflight.ok,true);assert.equal(preflight.accepted,true);
assert.equal(preflight.preflightOnly,true);assert.equal(preflight.actualCastAccepted,false);assert.equal(preflight.hdAccepted,false);assert.equal(preflight.fallbackAccepted,false);
sources(preflight,'preflight-v1');assert.equal(preflight.inputs.length,0);assert.equal(preflight.phases.length,0);
const first=runs[0];assert.equal(first.fireAttempts.length,3);assert.deepEqual(first.fireAttempts.map(a=>a.damage),[0,0,400]);
assert.equal(first.fireAttempts[2].actor.name,'梁兴');assert.equal(first.fireAttempts[2].target.name,'方悦');
function testLog(name,expected){
 const p=`${base}/${name}`,text=fs.readFileSync(p,'utf8');
 for(const [key,value]of Object.entries(expected))assert.ok(new RegExp(`(?:^|\\n)[^\\n]*\\b${key}\\s+${value}(?:\\D|$)`,'m').test(text),`${name}: ${key} ${value}`);
 return {counts:expected,evidence:ref(p)};
}
const tests={newCases:{total:75,speFrontend:19,bridge:46,mobileControlledVm:10},
 speFrontend:testLog('fire5-spe-frontend-all-v1-20261011.log',{tests:173,pass:173,fail:0,cancelled:0,skipped:0,todo:0}),
 mobileAndOriginalEntry:testLog('mobile-entry-tests-v1.log',{tests:56,pass:56,fail:0,cancelled:0,skipped:0,todo:0}),
 bridge:testLog('bridge-v2.log',{tests:78,pass:78,fail:0,cancelled:0,skipped:0,todo:0}),
 nativeUnchangedRerun:testLog('native-fixtures-v1.log',{tests:35,pass:35,fail:0,cancelled:0,skipped:0,todo:0}),
 firstFrontend:{tests:16,pass:14,fail:2,evidence:ref(`${base}/fire5-spe-frontend-focused-v1-20261011.log`),
  classifications:['One expectation incorrectly required redraw after a safely closed overlay had restored the physical LCD; fixture corrected.',
   'One actual product boundary allowed raw skill5 with unverified context to retain the legacy crop; matching/crop exclusion corrected without authorizing HD.']},
 firstBridge:{...read(`${base}/bridge-v1-failure.json`),evidence:ref(`${base}/bridge-v1-failure.json`),classification:'fixture-negative-used-an-already-established-clear-frontier; not a product failure'},
 finalFocused:ref(`${base}/fire5-spe-frontend-focused-v2-20261011.log`)};
const failedSummary={name:'pc-720-v1',accepted:false,classification:'natural-FIRE-not-observed-within-three-legal-attempts',error:failed.error,
 fireAttempts:failed.fireAttempts.map(summarizeAttempt),sourceCount:failed.sourceVerification.count,
 evidence:ref(`${failedPath}/result.json`),executedTool:ref(`${failedPath}/executed-tool.mjs`),captures:ref(`${failedPath}/native-skill-captures.json`)};
const classicFailedSummary={name:'pc-classic-v1',accepted:false,actualCastAccepted:false,hdAccepted:false,fallbackAccepted:false,
 classification:classicReview.classification,error:classicFailed.error,sourceCount:classicFailed.sourceVerification.count,
 movement:{key:'ArrowRight',nativeCode:37,count:1,priorCachedPresentation:{inputKind:5,actorIndex:2,inputSeq:147,focus:classicBefore.focus},
  terminalNative:{inputKind:classicAfter.inputKind,actorIndex:classicAfter.actorIndex,inputSeq:classicAfter.inputSeq,focus:{x:classicAfter.focusX,y:classicAfter.focusY}},
  caveat:'Prior focus is the cached shared presentation, not an immediate atomic native pre-key snapshot.',confirmedCast:false,capturedFIRE:0},
 evidence:ref(`${classicFailedPath}/result.json`),executedTool:ref(`${classicFailedPath}/executed-tool.mjs`),captures:ref(`${classicFailedPath}/native-skill-captures.json`),
 engineInputEvidence:ref(`${classicFailedPath}/engine-inputs.json`),sourceVerification:ref(`${classicFailedPath}/source-verification.json`),independentReview:ref(classicReviewPath)};
const classicNaturalSummary={name:'pc-classic-v2',accepted:false,actualCastAccepted:false,hdAccepted:false,fallbackAccepted:false,
 classification:'natural-FIRE-not-observed-within-four-legal-attempts',error:classicNatural.error,
 fireAttempts:classicNatural.fireAttempts.map(summarizeAttempt),capturedFIRE:0,sourceCount:classicNatural.sourceVerification.count,
 evidence:ref(`${classicNaturalPath}/result.json`),executedTool:ref(`${classicNaturalPath}/executed-tool.mjs`),captures:ref(`${classicNaturalPath}/native-skill-captures.json`),
 engineInputEvidence:ref(`${classicNaturalPath}/engine-inputs.json`),sourceVerification:ref(`${classicNaturalPath}/source-verification.json`)};
const classicLatestSummary={name:'pc-classic-v3',accepted:false,actualCastAccepted:false,hdAccepted:false,fallbackAccepted:false,
 classification:'natural-FIRE-not-observed-within-five-legal-attempts',error:classicLatest.error,
 fireAttempts:classicLatestAttempts,capturedFIRE:0,sourceCount:classicLatest.sourceVerification.count,
 evidence:ref(`${classicLatestPath}/result.json`),executedTool:ref(`${classicLatestPath}/executed-tool.mjs`),captures:ref(`${classicLatestPath}/native-skill-captures.json`),
 engineInputEvidence:ref(`${classicLatestPath}/engine-inputs.json`),sourceVerification:ref(`${classicLatestPath}/source-verification.json`)};
const preflightSummary={name:'preflight-v1',preflightOnly:true,accepted:true,actualCastAccepted:false,hdAccepted:false,fallbackAccepted:false,
 sourceCount:preflight.sourceVerification.count,evidence:ref(`${base}/preflight-v1/result.json`)};
const sourceRefs=[ref(`${base}/fire5-product-freeze-v1-20261011.json`),ref(`${base}/fire5-product-delta-v1-20261011.json`),
 ref(`${base}/independent-review/fire5-frozen-product-source-review-v1.json`),ref(classicNaturalReviewPath)];
const suiteSummary={startedAt:suite.startedAt,finishedAt:suite.finishedAt,executionConcurrency:suite.executionConcurrency,modules:suite.modules,exitCode:suite.exitCode,
 counts:suite.counts,sourceCount:suite.sources.length,sourceDrift:[],evidence:ref(`${base}/final-suite-v2/result.json`),log:ref(`${base}/final-suite-v2/test-output.log`),
 priorSuite:optionalRef(`${base}/final-suite/result.json`),priorSuiteLog:optionalRef(`${base}/final-suite/test-output.log`)};
const cleanupSummary={sampledAt:cleanup.sampledAt,attemptCount:cleanup.attemptCount,recordedCount:cleanup.recordedCount,survivors:[],privateListeners:[],
 privatePorts:cleanup.privatePorts,userUnchanged:true,userPid:cleanup.userService.ProcessId,userBirth:cleanup.userService.CreationDate,userHttpStatus:200,
 evidence:ref(`${base}/cleanup-verification.json`)};
const limits=['Only actual original FIRE5/SPE35 is newly accepted; shared35 skills11/18 keep the old route and were not newly cast.',
 'Full160x96 presentation retains actual LCD outside65x64; this is not a complete HD battle background.',
 'Eight source copies and measured LCD callbacks are distinct; coalesced callbacks do not prove every physical display frame.',
 'Ten new mobile tests use controlled VM ABI/public getters and real ROM identity; no new mobile C/browser or real Android/iOS acceptance.',
 'Classic actual FIRE/movie/NUM/HOLD remains pending: v1 cursor ACK tool error, v2/v3 natural no-FIRE attempts all remain unaccepted; controlled fallback tests and actual cursor movement do not replace an actual cast.',
 'Other skills/periods, custom gameplay, full campaign/save/RNG continuity, visibility/resize matrix, performance and whole HD remain pending.'];
const result={schemaVersion:1,createdAt:new Date().toISOString(),status:'partial',globalHdComplete:false,originalOnly:true,versionSelectorRemoved:true,
 product:'FIRE5 retains the full160x96 native LCD and replaces only the authenticated opaque65x64@48,16 movie/NUM/HOLD window using the existing two pictures.',
 manifest:{before:52,after:53,oldObjectsAndOrderExact:true,topLevelExact:true,onlyAddedSkill5:true,art:freeze.fire5.art},runs,
 attempts:[...runs.map(r=>({name:r.name,accepted:true,actualCastAccepted:true,hdAccepted:r.hdAccepted,fallbackAccepted:r.fallbackAccepted,evidence:r.evidence})),failedSummary,classicFailedSummary,classicNaturalSummary,classicLatestSummary,preflightSummary],
 classic:{status:'pending',actualCastAccepted:false,hdAccepted:false,fallbackAccepted:false,attemptNames:['pc-classic-v1','pc-classic-v2','pc-classic-v3'],
  boundary:'Controlled classic fallback tests and actual AIM cursor movement do not prove actual classic FIRE movie/NUM/HOLD acceptance.'},
 suite:suiteSummary,tests,cleanup:cleanupSummary,native:{changed:false,rebuildRequired:false,count:128,aggregate:freeze.native.aggregateSha256},sourceRefs,limits,archive:`./${stem}-archive.json`};
const total=runs.reduce((a,r)=>({copies:a.copies+r.pixels.sourceCopies,callbacks:a.callbacks+r.pixels.actualLcdCallbacks,readbacks:a.readbacks+r.pixels.verifiedReadbacks}),{copies:0,callbacks:0,readbacks:0});
const note=`2026-10-11 最新[原版FIRE5完整LCD底图与高清窗口](validation/${stem}.md)：FIRE35／技能5保留完整160×96原版底图，仅在实际认证的65×64@48,16窗口复用两张高清素材；电影、原生数字及等待均沿真实提交，窗口外每次高清读回11200个逻辑像素与原版LCD精确一致。PC1080／720高清与精确缺图回退三个独立合法新局通过，经典FIRE实战仍待验；首720与经典v2／v3自然未产生FIRE、经典v1运行器ACK条件错误的失败原件均保留，预检不计实战。manifest53项，原52项及顺序不变，共享35技能11／18沿旧路径。新增75项受控用例（19前端／46桥／10移动VM），最终${suite.modules}模块串行 **${suite.counts.pass}／${suite.counts.tests}通过**，失败／取消／跳过／todo均0，${suite.sources.length}执行来源无漂移；原35项native夹具原样重跑，无新native构建。移动10项仅受控VM，不冒充手机浏览器／真机；完整HD仍为 **partial**，其它技能、性能与完整流程继续待验。`;
const table=runs.map(r=>`| ${r.name} | ${r.viewport.width}×${r.viewport.height} | ${r.hdAccepted?'高清窗口':'完整LCD回退'} | ${r.fireAttempts.length} | ${r.pixels.sourceCopies}／${r.pixels.actualLcdCallbacks} | ${r.pixels.numericReadbacks}／${r.pixels.completedHoldReadbacks} | ${r.readonlyExtraKeys} | ${r.sourceCount} |`).join('\n');
const md=`# 原版FIRE5完整LCD底图与高清窗口验证（2026-10-11）

${note.slice(note.indexOf('：')+1)}

## 产品范围

本批修复技能5旧130×64裁剪／整区暗色背景：完整160×96原版LCD先保留，仅替换真实mode2建立的65×64@48,16窗口。独立fireVersion1／opaqueCoverageVersion1条目绑定标准LIB、资源35／0、FNV0bf53f74／1212字节、8帧和2槽；NUM15的真实GBK标签、55,18及6px步距数字、56→49历史和原生等待保持。当前／显示提交、清除边界、代次／对象／flush与绘制后复查失效时恢复完整LCD；没有新增键、时钟或伤害／RNG写入。

生产manifest由52增至53，旧52项、顺序与顶层身份原样保持；原两PNG、units与数字资源复用。共享35技能11／18仍沿旧路径，不纳入本批新验收。原版唯一入口、暂停版本切换及现有存档保持。完整底图仍为LCD，不能写成完整HD战场。

## 实际三场通过

| 终态私局 | 浏览器尺寸 | 接受范围 | 合法施法尝试 | 源复制／实际LCD回调 | 数字／完整等待读回 | 捕获期额外键 | 来源数 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
${table}

三场均为独立公开合法新局、真实原版规则与自然结果；1080／720正常高清与精确缺图回退独立，不混用旧结果。共${total.copies}次源复制、${total.callbacks}次实际LCD回调和${total.readbacks}次已验读回；8次源复制不是8个必然逐一截取的物理帧。高清读回的窗口外11200个逻辑像素逐次对照当前原版LCD；缺图局逐像素保留完整LCD并验证精确图片404。经典实际FIRE仍pending，不计本表。三场原生标签、数字历史与真实等待均观察，不增自动确认。

pc-1080-v1三次合法尝试，前两次自然未产生伤害／FIRE，第三次${first.fireAttempts[2].actor.name}对${first.fireAttempts[2].target.name}真实伤兵${first.fireAttempts[2].damage}，MP${first.fireAttempts[2].mpBefore}→${first.fireAttempts[2].mpAfter}，目标兵${first.fireAttempts[2].armsBefore}→${first.fireAttempts[2].armsAfter}。三场捕获电影／NUM／等待期间均0额外原生键；各场最终人数、回调与读回数量从终态原件动态生成，详见结构化记录。

## 失败、测试与证据

pc-720-v1在三次合法自然尝试内未产生FIRE，actualCastAccepted／accepted均false，不能计高清通过；原始result、日志、工具、JSON与本地截图保留，fresh pc-720-v2才计本轮通过。preflight-v1虽accepted=true，明确preflightOnly、actualCastAccepted=false，0输入且不计实际局。没有改概率、重写人物／世界／RNG来制造成功。

pc-classic-v1在真实AIM输入内只发一次ArrowRight（原生37），焦点11,15→12,15而同一actor2／inputSeq147保持；运行器错误等待inputSeq变化，尚未确认技能，0次FIRE捕获，accepted／actualCastAccepted／HD／fallback均false。原生方向键只移动当前游标，输入序号在begin／end边界递增；修正工具为当前actor／同序号／实际坐标ACK，不改产品或键次数。pc-classic-v2随后四次合法施放自然未产生FIRE；pc-classic-v3五次合法施放也未产生FIRE，前三次天气3、后两次天气2，MP各扣15、伤兵均0。v2／v3均0捕获且全部接受标志false。三次失败result、执行工具、输入及来源原件独立保留，不混入成功局；经典v1独立审查区分缓存前焦点和终态原生焦点，不虚称即时原生前键快照。经典回退已有受控单测、实际AIM方向键已正常，但均不能替代经典FIRE电影／NUM／等待实战验收，本轮仍pending，未继续重试。

首轮前端专项16项14过2失败：一项是覆盖层已正确关闭并恢复物理LCD后，夹具仍要求画布重绘的期待错误；另一项是未知上下文但raw技能5时仍沿旧裁剪的真实产品边界，已以防裁剪而不授权HD的窄门修复。桥首轮78项77过1失败，反例把已经建立的clear-frontier当未来帧，改成真正超过显示前沿的bit3；该项为夹具错误。原失败记录均保留。最终前端173／173、桥78／78、移动与原版入口56／56、原35项native夹具重跑全部通过；本批新增19＋46＋10＝75项，其中移动10项仅VM受控ABI／公开getter与真实ROM身份，不是实际C或手机浏览器测试。

最终默认${suite.modules}模块串行${suite.counts.tests}／${suite.counts.tests}通过，失败／取消／跳过／todo均0、${suite.sources.length}执行来源无漂移。128份native来源聚合仍为\`${freeze.native.aggregateSha256}\`，成套安装来源一致，本批无新native构建。外部只读OS证明${cleanup.attemptCount}次有历史身份的尝试、${cleanup.recordedCount}个历史身份无存活、私有端口无listener；原8080 PID${cleanup.userService.ProcessId}／出生时间及HTTP200保持，私有profile未删除。

归档索引保存原JSON／日志／执行工具／冻结源和少量选定PNG的原字节或gzip往返SHA；全部原始截图与profile仍留本机，不能将未入库截图说成已归档。其它计谋、移动浏览器／真机、完整逐物理帧、可见性／resize完整矩阵、性能、完整流程／存读档／RNG及全HD仍待，globalHdComplete=false。

[结构化结果](${stem}.json) · [归档索引](${stem}-archive.json)
`;
function replaceRow(text,id,change){
 const lines=text.split('\n'),indices=lines.flatMap((line,i)=>line.startsWith(`| ${id} |`)?[i]:[]);assert.equal(indices.length,1,`${id} table row`);
 const i=indices[0],cr=lines[i].endsWith('\r')?'\r':'',parts=lines[i].replace(/\r$/,'').split('|');assert.equal(parts.length,8);
 change(parts);lines[i]=parts.join('|')+cr;return lines.join('\n');
}
const planWrites=['docs/hd-development-plan.md','docs/hd-remaining-work.md'].map(file=>{
 let text=fs.readFileSync(file,'utf8');assert.ok(!text.includes(`[原版FIRE5完整LCD底图与高清窗口](validation/${stem}.md)`),'writer is one-shot');
 const firstNl=text.indexOf('\n');assert.ok(firstNl>=0);text=text.slice(0,firstNl+1)+'\n'+note+'\n'+text.slice(firstNl+1).replace('2026-10-11 最新[原版人物装备属性卡]','2026-10-11 前批[原版人物装备属性卡]');
 if(file.endsWith('hd-remaining-work.md')){
  text=replaceRow(text,'R01',p=>{p[3]=' 本批原版FIRE5全160×96底图／65×64实际窗口电影＋NUM／HOLD的PC1080／720高清与精确缺图三场已验，经典FIRE实战待验；'+p[3].trim()+' ';p[5]=` [本批FIRE窗口](validation/${stem}.md)；`+p[5].trim()+' ';});
  text=replaceRow(text,'R02',p=>{p[3]=' FIRE5复用原两PNG，完整LCD底图与高清窗口三场已验，经典FIRE实战待验；'+p[3].trim()+' ';assert.ok(p[5].includes('当前manifest52项'));p[5]=p[5].replace('当前manifest52项',`当前manifest53项，原52项及顺序保持；[FIRE5窗口](validation/${stem}.md)`);});
  text=replaceRow(text,'R13',p=>{p[3]=` 当前${suite.modules}模块串行${suite.counts.tests}／${suite.counts.tests}通过，失败／取消／跳过／todo均0，${suite.sources.length}执行来源无漂移；FIRE5三场与原35项native夹具重跑通过，经典FIRE实战待验 `;p[5]=` [本批4339项与FIRE窗口](validation/${stem}.md)；`+p[5].trim()+' ';});
 }
 return {file,text};
});
// All inputs, archive SHA/roundtrips, pending-run gates and table anchors passed.
// Only now write the validation pair and the two current-plan summaries.
fs.writeFileSync(`${validation}/${stem}.json`,json(result));
fs.writeFileSync(`${validation}/${stem}.md`,md);
for(const p of planWrites)fs.writeFileSync(p.file,p.text);
console.log(json({written:[`${validation}/${stem}.json`,`${validation}/${stem}.md`,...planWrites.map(p=>p.file)],actualRuns:runs.length,tests:suite.counts.tests,globalHdComplete:false}));
