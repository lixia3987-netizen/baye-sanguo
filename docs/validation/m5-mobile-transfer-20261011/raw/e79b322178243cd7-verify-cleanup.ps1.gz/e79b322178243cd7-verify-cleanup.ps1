param([string[]]$RunDirectories)
$ErrorActionPreference='Stop'
$taskReports=@($RunDirectories | ForEach-Object {Get-Content -Raw -LiteralPath (Join-Path $_ 'result.json') | ConvertFrom-Json})
$taskIdentities=@($taskReports.historicalRecordedIdentities | Group-Object { [string]$_.ProcessId+'|'+[string]$_.CreationDate } | ForEach-Object {$_.Group[0]})
$taskAllProcesses=@(Get-CimInstance Win32_Process)
$taskSurvivors=@();$taskReused=@()
foreach($taskIdentity in $taskIdentities){$taskCurrent=$taskAllProcesses | Where-Object ProcessId -eq $taskIdentity.ProcessId;if($taskCurrent){if(([DateTimeOffset]$taskCurrent.CreationDate).UtcTicks -eq ([DateTimeOffset]$taskIdentity.CreationDate).UtcTicks -and $taskCurrent.ExecutablePath -eq $taskIdentity.ExecutablePath){$taskSurvivors+=$taskIdentity}else{$taskReused+=[ordered]@{pid=$taskIdentity.ProcessId;recordedBirth=$taskIdentity.CreationDate;currentBirth=$taskCurrent.CreationDate}}}}
$taskPorts=@($taskReports | ForEach-Object {$_.httpPort;$_.debugPort});$taskListeners=@(Get-NetTCPConnection -State Listen | Where-Object {$_.LocalPort -in $taskPorts} | Select-Object LocalAddress,LocalPort,OwningProcess)
$taskListener=Get-NetTCPConnection -State Listen -LocalPort 8080;$taskService=Get-CimInstance Win32_Process -Filter ('ProcessId='+$taskListener.OwningProcess)
$taskBefore=Get-Content -Raw -LiteralPath build/mobile-transfer-prebuild-20261011/user8080-before.json | ConvertFrom-Json
$taskAfter=[ordered]@{at=[DateTimeOffset]::UtcNow.ToString('o');pid=$taskService.ProcessId;birth=$taskService.CreationDate.ToUniversalTime().ToString('o');exe=$taskService.ExecutablePath;httpStatus=(Invoke-WebRequest -Uri 'http://localhost:8080/' -UseBasicParsing).StatusCode}
$taskUnchanged=$taskAfter.pid -eq $taskBefore.pid -and ([DateTimeOffset]$taskAfter.birth).UtcTicks -eq ([DateTimeOffset]$taskBefore.birth).UtcTicks -and $taskAfter.exe -eq $taskBefore.exe -and $taskAfter.httpStatus -eq 200
$taskEvidence=[ordered]@{at=[DateTimeOffset]::UtcNow.ToString('o');runs=$RunDirectories;recordedIdentities=$taskIdentities.Count;survivingRecorded=$taskSurvivors;pidReusedByOtherProcess=$taskReused;privateListeners=$taskListeners;allRuntimeCleanupPassed=(@($taskReports | Where-Object {-not $_.cleanup.treeExited -or -not $_.serverClosed}).Count -eq 0);user8080Before=$taskBefore;user8080After=$taskAfter;user8080Unchanged=$taskUnchanged}
$taskEvidence | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath build/mobile-transfer-prebuild-20261011/cleanup-user8080-verification.json -Encoding utf8
if($taskSurvivors.Count -or $taskListeners.Count -or -not $taskUnchanged -or -not $taskEvidence.allRuntimeCleanupPassed){throw 'Cleanup/service verification failed'}
$taskEvidence | Select-Object recordedIdentities,allRuntimeCleanupPassed,user8080Unchanged | ConvertTo-Json

