import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import assert from 'node:assert/strict';
const base='docs/validation/m4-attacks-20261008';
fs.mkdirSync(base+'/raw',{recursive:true});fs.mkdirSync(base+'/png',{recursive:true});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const previous=fs.existsSync('build/r09-runtime-archive.json')?JSON.parse(fs.readFileSync('build/r09-runtime-archive.json')):{files:[],images:[]};
const raws=new Map(previous.files.map(x=>[x.original,x]));const pngs=new Map(previous.images.map(x=>[x.original,x]));
function save(file){const bytes=fs.readFileSync(file),hash=sha(bytes);
    if(file.endsWith('.png')){const archived=base+'/png/'+hash+'.png';if(fs.existsSync(archived))assert.deepEqual(fs.readFileSync(archived),bytes);else fs.writeFileSync(archived,bytes);
        pngs.set(file,{original:file,archived,bytes:bytes.length,sha256:hash,originalBytesPreserved:true});}
    else{const archived=base+'/raw/'+file.replaceAll('\\','/').replace(/^build\//,'').replaceAll('/','__')+'.gz';
        fs.writeFileSync(archived,zlib.gzipSync(bytes,{level:9}));const packed=fs.readFileSync(archived);assert.deepEqual(zlib.gunzipSync(packed),bytes);
        raws.set(file,{original:file,archived,bytes:bytes.length,sha256:hash,gzipBytes:packed.length,gzipSha256:sha(packed),decompressedByteEqual:true});}}
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>{const f=dir+'/'+e.name;return e.isDirectory()?walk(f):[f];});}
for(const input of process.argv.slice(2)){
    if(fs.statSync(input).isDirectory()){
        const result=input+'/result.json';assert.ok(fs.existsSync(result),'Completed run must have its immutable result before archive');
        const r=JSON.parse(fs.readFileSync(result));assert.ok(r.finishedAt||r.isolation?.cleaned||r.sourceVerification,'Runtime cleanup/result must have finished');
        for(const f of walk(input).filter(f=>/\.(png|json|log|mjs|txt|rgba)$/.test(f)))save(f);
    }else save(input);
}
const report={capturedAt:new Date().toISOString(),scope:'Original runtime and failed-run evidence. PNGs deduplicated by original SHA256 with no editing; raw source/log/JSON bytes gzip roundtrip checked.',
    files:[...raws.values()].sort((a,b)=>a.original.localeCompare(b.original)),images:[...pngs.values()].sort((a,b)=>a.original.localeCompare(b.original))};
fs.writeFileSync('build/r09-runtime-archive.json',JSON.stringify(report,null,2)+'\n');
fs.writeFileSync(base+'/runtime-index.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({raw:report.files.length,logicalPNG:report.images.length,uniquePNG:new Set(report.images.map(x=>x.sha256)).size,rawBytes:report.files.reduce((n,x)=>n+x.bytes,0)}));
