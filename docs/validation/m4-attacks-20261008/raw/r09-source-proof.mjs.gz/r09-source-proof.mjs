import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const metadata = path => { const bytes=fs.readFileSync(path); return {path,bytes:bytes.length,sha256:sha(bytes)}; };
const base='7516faed6ac032c4976f4f672f4affaa67af0665';
const files=fs.readFileSync('build/wasm/engine-source-files','utf8').split('\0').filter(Boolean).sort();
assert.equal(files.length,128);
const hash=crypto.createHash('sha256');
const native=files.map(filename=>{hash.update(filename+'\0');hash.update(fs.readFileSync(filename));return metadata(filename);});
const manifest=JSON.parse(fs.readFileSync('build/wasm/src/baye.build.json','utf8'));
assert.equal(hash.digest('hex'),manifest.engineSourceSha256);assert.equal(manifest.sourceRevision,base);assert.equal(manifest.engineSourceModified,true);
assert.equal(manifest.hdAttackProtocol.version,1);assert.equal(manifest.hdSpeCompositionProtocol.version,1);
const engines=['baye.js','baye.wasm','baye.wasm.map','baye.build.json'].map(name=>metadata('build/wasm/src/'+name));
for(const f of engines.slice(0,3)){const expected=manifest.artifacts[f.path.split('/').at(-1)];assert.equal(f.bytes,expected.bytes);assert.equal(f.sha256,expected.sha256);}
const old=JSON.parse(execFileSync('git',['show',base+':assets/hd-spe/manifest.json'],{encoding:'utf8'}));
const current=JSON.parse(fs.readFileSync('assets/hd-spe/manifest.json','utf8'));
assert.deepEqual(current.entries.filter(e=>e.speId<19||e.speId>25),old.entries);
const entries=execFileSync('git',['ls-tree','-r','-z',base,'--','assets','libs'],{encoding:'utf8',maxBuffer:8*1024*1024}).split('\0').filter(Boolean)
    .map(line=>{const[header,path]=line.split('\t');return{path,blob:header.split(' ')[2]};}).filter(e=>/\.(png|lib)$/.test(e.path));
const conservation=entries.map(e=>{const bytes=fs.readFileSync(e.path),raw=crypto.createHash('sha1').update('blob '+bytes.length+'\0').update(bytes).digest('hex');
    assert.equal(raw,e.blob,'Exact prior PNG/LIB bytes '+e.path);return{...e,bytes:bytes.length,sha256:sha(bytes),rawGitBlobEqual:true};});
const changed=execFileSync('git',['diff','--name-only',base,'--','vendor/iBaye/src'],{encoding:'utf8'}).trim().split(/\r?\n/).filter(Boolean).sort();
assert.deepEqual(changed,['vendor/iBaye/src/FightSub.c','vendor/iBaye/src/PublicFun.c','vendor/iBaye/src/hd-bridge.c','vendor/iBaye/src/hd-bridge.h','vendor/iBaye/src/platform/common/sys.c'].sort());
const report={capturedAt:new Date().toISOString(),baseCommit:base,sourceModified:true,manifest,nativeCount:native.length,native,stagedEngines:engines,
    nativeChangedFiles:changed,unchangedPriorManifestEntries:true,preservedCount:conservation.length,preserved:conservation,
    comparison:'128 raw native source bytes match build aggregate. All prior PNG and LIB binaries retain exact raw Git blobs. Five declared native files and quartet intentionally change.'};
fs.writeFileSync('build/r09-source-proof.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({native:native.length,preserved:conservation.length,engineSourceSha256:manifest.engineSourceSha256,stagedEngines:engines}));
