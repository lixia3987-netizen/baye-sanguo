import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const base=path.resolve('docs/validation/m4-attacks-20261008');
const index=JSON.parse(fs.readFileSync('build/r09-runtime-archive.json'));
const native=JSON.parse(fs.readFileSync(base+'/native-input-index.json'));
const selected=new Set();
const records=new Map();
function record(value){if(!value||typeof value!=='object')return;
    if(typeof value.archived==='string'&&value.archived.endsWith('.png'))selected.add(path.resolve(value.archived));
    if(typeof value.archivedPath==='string'&&value.archivedPath.endsWith('.png'))selected.add(path.resolve(value.archivedPath));
    for(const x of Object.values(value))record(x);}
record(native);
const directories=[...new Set(index.files.filter(x=>x.original.endsWith('/result.json')).map(x=>path.dirname(x.original)))];
for(const dir of directories){const r=JSON.parse(fs.readFileSync(dir+'/result.json'));
    for(const phase of r.phases||[])for(const key of ['screenshot','file'])if(typeof phase[key]==='string'&&phase[key].endsWith('.png'))records.set((dir+'/'+phase[key]).replaceAll('\\','/'),true);
}
for(const p of index.images){const f=p.original.replaceAll('\\','/');
    const callback=/\/(?:[^/]*commit[^/]*|attack-\d+[^/]*)-hd\.png$/.test(f);
    const regression=/r09-(opening|maker)-staged-regression/.test(f);
    const frame=f.match(/-frame-(\d+)-hd\.png$/);
    const retain=!callback||!regression||records.has(f)||frame&&[0,4,7,8,32,64,95].includes(Number(frame[1]));
    if(retain)selected.add(path.resolve(p.archived||p.originalArchivePath));
    p.retained=!!retain;p.selection=retain?'Original PNG archived':'Regression HD intermediate omitted; full raw observations, hashes, draw logs and every native PNG retained';
}
let deleted=0,bytes=0;
for(const f of fs.readdirSync(base+'/png')){const absolute=path.resolve(base,'png',f);assert.equal(path.dirname(absolute),base+path.sep+'png');
    if(!selected.has(absolute)){bytes+=fs.statSync(absolute).size;fs.unlinkSync(absolute);deleted++;}}
for(const p of index.images){if(p.retained){p.archived||=p.originalArchivePath;const b=fs.readFileSync(p.archived);assert.equal(crypto.createHash('sha256').update(b).digest('hex'),p.sha256);}
    else {p.originalArchivePath||=p.archived;p.archived=null;}}
index.imageSelection='All attack callback pairs, every native regression PNG, all checkpoint/failure screenshots, selected MAIN/MAKER HD frontiers. Intermediate HD regression files have exact original metadata but no saved PNG; raw observations and native pixel checks remain archived.';
fs.writeFileSync('build/r09-runtime-archive.json',JSON.stringify(index,null,2)+'\n');fs.writeFileSync(base+'/runtime-index.json',JSON.stringify(index,null,2)+'\n');
console.log(JSON.stringify({removedFiles:deleted,removedBytes:bytes,retainedLogical:index.images.filter(p=>p.retained).length,omittedLogical:index.images.filter(p=>!p.retained).length}));
