import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const base=path.resolve('docs/validation/m4-attacks-20261008/png');
const index=JSON.parse(fs.readFileSync('build/r09-attack-evidence-native.json'));
let restored=0,checked=0;
function walk(v){if(!v||typeof v!=='object')return;
    if(typeof v.archivedPath==='string'&&path.resolve(v.archivedPath).startsWith(base+path.sep)){
        const target=path.resolve(v.archivedPath);assert.equal(path.dirname(target),base);
        if(!fs.existsSync(target)){const original=v.originalPath||v.originalSource;assert.ok(original);const b=fs.readFileSync(original);
            assert.equal(crypto.createHash('sha256').update(b).digest('hex'),v.sha256);fs.writeFileSync(target,b);restored++;}
        const b=fs.readFileSync(target);assert.equal(b.length,v.bytes);assert.equal(crypto.createHash('sha256').update(b).digest('hex'),v.sha256);checked++;
    }for(const x of Object.values(v))walk(x);
}walk(index);
fs.writeFileSync('build/r09-native-archive-restoration.json',JSON.stringify({restored,checked,reason:'Runtime selection initially protected archived but missed native archivedPath; reference archive copies restored from unchanged original bytes before commit, then every native archive mapping reverified.'},null,2)+'\n');
console.log(JSON.stringify({restored,checked}));
