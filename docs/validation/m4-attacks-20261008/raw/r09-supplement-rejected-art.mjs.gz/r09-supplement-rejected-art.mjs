import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';

const root = process.cwd();
const ledgerPath = 'assets/hd-spe/GENERATED-ATTACKS.json';
const indexPath = 'docs/validation/m4-attacks-20261008/native-input-index.json';
const runtimePath = 'docs/validation/m4-attacks-20261008/runtime-index.json';
const buildIndexPath = 'build/r09-attack-evidence-native.json';
const helperPath = 'build/r09-supplement-rejected-art.mjs';
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const read = name => fs.readFileSync(path.resolve(root, name));
const ledgerBytes = read(ledgerPath);
const runtimeBytes = read(runtimePath);
const priorIndexBytes = read(indexPath);
const ledger = JSON.parse(ledgerBytes);
const index = JSON.parse(priorIndexBytes);
assert.equal(sha(ledgerBytes), 'da437c4612298256ab3c5a3a16a8f9865ab454bc3c57d8005c12ee7f50249b5b');
assert.equal(index.ledgerCheckpoint.rawSha256, sha(ledgerBytes));
const items = [];
let newlyIndexedBlobCount = 0;
let newlyCopiedBlobCount = 0;
let newlyIndexedPathCount = 0;
function pngMetadata(bytes) {
  assert.equal(bytes.subarray(0, 8).toString('hex'), '89504e470d0a1a0a');
  assert.equal(bytes.subarray(12, 16).toString(), 'IHDR');
  return {width: bytes.readUInt32BE(16), height: bytes.readUInt32BE(20), colorType: bytes[25]};
}
function checkRecorded(meta, bytes, image) {
  if (!meta) return;
  if (meta.sha256 != null) assert.equal(sha(bytes), meta.sha256);
  if (meta.bytes != null) assert.equal(bytes.length, meta.bytes);
  if (meta.dimensions) assert.deepEqual([image.width, image.height], meta.dimensions);
  if (meta.width != null) assert.equal(image.width, meta.width);
  if (meta.height != null) assert.equal(image.height, meta.height);
  if (meta.mode != null) assert.equal(meta.mode, image.colorType === 6 ? 'RGBA' : 'RGB');
  if (meta.pngColorType != null) assert.equal(image.colorType, meta.pngColorType);
}
for (const group of ledger.groups) {
  for (const attempt of group.attempts || []) {
    const accepted = attempt.status === 'accepted-final';
    const rejected = attempt.status.startsWith('rejected-final-candidate');
    const failed = attempt.status === 'failed-call';
    assert(accepted || rejected || failed, `Unrecognized attempt status: ${attempt.status}`);
    const entry = {
      groupOrdinal: group.groupOrdinal,
      nativeRawSlotSha256: group.nativeRawSlotSha256,
      nativeSlots: group.slots,
      attempt: attempt.attempt,
      status: attempt.status,
      ledgerLocation: `${ledgerPath} groups[groupOrdinal=${group.groupOrdinal}].attempts[attempt=${attempt.attempt}]`,
      attemptRecord: attempt,
      rejectionReason: rejected ? attempt.visualCheck?.reason || attempt.review?.reason || null : null,
      error: failed ? attempt.error || null : null,
    };
    if (failed) {
      assert.equal(attempt.output, null);
      Object.assign(entry, {originalSource: null, archivedPath: null, storage: 'no-output', noOutput: true});
      items.push(entry);
      continue;
    }
    const originalSource = accepted
      ? group.final?.originalSource || attempt.output?.originalSource || attempt.originalSource
      : attempt.output?.originalSource || attempt.originalSource || attempt.output?.path;
    assert(originalSource, `Missing original source: group ${group.groupOrdinal} attempt ${attempt.attempt}`);
    const bytes = read(originalSource);
    const hash = sha(bytes);
    const image = pngMetadata(bytes);
    checkRecorded(attempt.output, bytes, image);
    if (accepted) {
      assert(group.final);
      checkRecorded(group.final, bytes, image);
      const target = group.final.target || group.target;
      assert(read(target).equals(bytes), `Accepted target is not original bytes: ${target}`);
      Object.assign(entry, {
        originalSource, archivedPath: target, storage: 'production-target-original-bytecopy',
        sha256: hash, bytes: bytes.length, ...image, byteExact: true,
      });
    } else {
      assert(entry.rejectionReason, `Missing rejection reason: group ${group.groupOrdinal}`);
      const archivedPath = `docs/validation/m4-attacks-20261008/png/${hash}.png`;
      const absoluteArchive = path.resolve(root, archivedPath);
      if (fs.existsSync(absoluteArchive)) {
        assert(read(archivedPath).equals(bytes), `SHA filename collision: ${archivedPath}`);
      } else {
        fs.writeFileSync(absoluteArchive, bytes, {flag: 'wx'});
        newlyCopiedBlobCount++;
      }
      assert(read(archivedPath).equals(bytes));
      Object.assign(entry, {
        originalSource, archivedPath, storage: 'sha-png-original-bytecopy',
        sha256: hash, bytes: bytes.length, ...image, byteExact: true,
      });
      let mapping = index.png.mapping.find(row => path.resolve(root, row.originalPath) === path.resolve(root, originalSource));
      const use = {groupOrdinal: group.groupOrdinal, attempt: attempt.attempt, status: attempt.status, reason: entry.rejectionReason};
      if (mapping) {
        assert.equal(mapping.sha256, hash);
        assert.equal(mapping.archivedPath, archivedPath);
        mapping.generationOutputUses = [use];
      } else {
        index.png.mapping.push({
          originalPath: originalSource, category: 'rejected-generated-candidate',
          archivedPath, sha256: hash, bytes: bytes.length, ...image,
          byteExact: true, generationOutputUses: [use],
        });
        newlyIndexedPathCount++;
      }
      if (!index.png.blobs.some(row => row.sha256 === hash)) {
        index.png.blobs.push({archivedPath, sha256: hash, bytes: bytes.length});
        newlyIndexedBlobCount++;
      }
    }
    items.push(entry);
  }
}
const counts = {
  attempts: items.length,
  accepted: items.filter(item => item.status === 'accepted-final').length,
  rejected: items.filter(item => item.status.startsWith('rejected-final-candidate')).length,
  failed: items.filter(item => item.status === 'failed-call').length,
};
assert.deepEqual(counts, {attempts: 22, accepted: 15, rejected: 6, failed: 1});
index.generationOutputs = {
  ...counts,
  allOutputMetadataMatched: true,
  allAcceptedOriginalsEqualProductionTargets: true,
  allRejectedOriginalsByteArchived: true,
  failedCallsWithoutOutput: 1,
  items,
};
index.png.allArchivedLogicalPaths = index.png.mapping.length;
index.png.uniquePngBytes = index.png.blobs.length;
index.png.totalStoredBytes = index.png.blobs.reduce((sum, item) => sum + item.bytes, 0);
index.limits = index.limits.map(text => text.startsWith('All actual ledger/fragment input references')
  ? 'All actual frozen ledger/fragment input references resolve to original bytecopies or verified preexisting HEAD-exact tracked originals. All6 frozen rejected output candidates are archived; all15 accepted originals map to their byte-exact tracked production targets. The1 failed builtin call returned no image and has no invented output. Future36 foreground groups remain outside this frozen checkpoint.'
  : text);
index.generationOutputSupplement = {
  helperPath, helperSha256: sha(read(helperPath)),
  previousIndexSha256: index.generationOutputSupplement?.previousIndexSha256 || sha(priorIndexBytes),
  frozenLedgerSha256: sha(ledgerBytes),
  runtimeIndexSha256AtSupplement: sha(runtimeBytes),
  runtimeIndexUnchangedBySupplement: true,
  newlyIndexedPathCount, newlyIndexedBlobCount, newlyCopiedBlobCount,
  reusedRejectedBlobCount: counts.rejected - newlyIndexedBlobCount,
  noImageCropResizeReencoding: true,
};
assert(read(ledgerPath).equals(ledgerBytes), 'Ledger changed during supplemental archive');
assert(read(runtimePath).equals(runtimeBytes), 'Runtime index changed during supplemental archive');
const result = Buffer.from(`${JSON.stringify(index, null, 2)}\n`);
fs.writeFileSync(path.resolve(root, indexPath), result);
fs.writeFileSync(path.resolve(root, buildIndexPath), result);
console.log(JSON.stringify({ok: true, counts, newlyIndexedPathCount, newlyIndexedBlobCount, newlyCopiedBlobCount,
  png: {logicalPaths: index.png.allArchivedLogicalPaths, uniqueBlobs: index.png.uniquePngBytes, bytes: index.png.totalStoredBytes},
  indexSha256: sha(result), ledgerSha256: sha(ledgerBytes), runtimeIndexSha256: sha(runtimeBytes)}, null, 2));
