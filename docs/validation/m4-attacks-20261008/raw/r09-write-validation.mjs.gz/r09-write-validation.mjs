import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
const read=f=>JSON.parse(fs.readFileSync(f,'utf8'));
const meta=f=>{const b=fs.readFileSync(f);return{path:f,bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex')};};
const proof=read('build/r09-source-proof.json'),native=read('build/r09-attack-evidence-native.json'),archive=read('build/r09-runtime-archive.json');
const entry=read('assets/hd-spe/manifest.json').entries.find(e=>e.speId===21);
const ledger=read('assets/hd-spe/GENERATED-ATTACKS.json');
const accepted=ledger.groups.filter(g=>g.status==='generated-accepted');assert.equal(accepted.length,15);assert.equal(ledger.groups.length,51);
const run=(d,role)=>{const file='build/'+d+'/result.json',r=read(file);assert.equal(r.ok,true,d);
    return {role,source:file,archived:archive.files.find(x=>x.original===file)?.archived,staged:r.staged,viewport:r.viewport,browser:r.browser,
        checkpoints:r.phases.length,hdAccepted:r.hdAccepted,runner:r.tool||r.runner,sourceVerification:r.sourceVerification,actualHurt:r.actualHurt,
        nativePixelOracle:r.nativePixelOracle&&Object.fromEntries(Object.entries(r.nativePixelOracle).filter(([k])=>k!=='verified')),
        intervals:r.gameplayIntervals,exceptions:r.exceptions.length,dialogs:r.dialogs.length,isolation:r.isolation};};
const runs=[run('r09-attack-staged-hd','First strict1080; initial runner bb9ad; later runner fixes recorded separately'),
    run('r09-attack-staged-hd-720','Final runner strict1280x720/DPR1'),run('r09-attack-installed-hd','Final installed strict1920x1080/DPR1'),
    run('r09-opening-staged-regression','Complete existing MAIN cold/skip/visibility/failure/unknown LIB regression'),
    run('r09-maker-staged-regression-v3','Complete existing MAKER seven-scene regression'),
    run('r09-core-staged-regression-v2','Real core flow, correct explicit Windows Chrome path'),
    run('r09-core-installed-regression','Installed real core flow'),run('r09-spe-staged-regression','Real ordinary attack and fourth-attempt FIRE35')];
const fallback=read('build/r09-attack-fallback-final-summary.json');
const rawFailure=[
    {source:'build/r09-all-tests-before-fixture-fix.log',cause:'Old details/overview actual-C fixtures missed the new real attack-retire dependency; fixtures linked the real function, with no no-op or skips.'},
    {source:'build/r09-all-tests-process-failure.log',cause:'One portraits test-file process failed without an assertion diagnostic:574/575. Unchanged focused45/45 and subsequent full618/618 passed; cause not established.'},
    {source:'build/r09-attack-staged-observer/result.json',cause:'Verifier incorrectly expected boolean false for the legacy public SPE U8 active=0. Actual attack reached numbers; corrected strict expected0, original output preserved.'},
    {source:'build/r09-maker-staged-regression/result.json',cause:'Legacy whole-display assertion did not allow additive composition. Corrected projection of all six original stamp fields plus explicit neutral composition assertions.'},
    {source:'build/r09-maker-staged-regression-v2/result.json',cause:'One later saved-source lookup still compared the whole object; same narrow projection applied, full v3 passed.'},
    {source:'build/r09-core-staged-regression/result.json',cause:'Old runner did not autodiscover Windows Chrome; explicit existing executable used for v2.'},
    {source:'build/r09-attack-staged-late/result.json',cause:'Real RNG route attacked with a nonselected family. Required selected gate failed honestly; legitimate planner now chooses actual effective arms/range, with no state writes.'},
    {source:'build/r09-attack-staged-classic/result.json',cause:'Runner queried nonexistent container id instead of actual closest LCD class; fixed selector retains visibility/stack assertions.'}
].map(x=>({...x,archived:archive.files.find(f=>f.original===x.source)?.archived||native.raw?.find?.(f=>f.originalPath===x.source)?.archivedPath}));
const fullLog=fs.readFileSync('build/r09-all-tests.log','utf8');assert.ok(/tests 618/.test(fullLog)&&/pass 618/.test(fullLog)&&/fail 0/.test(fullLog)&&/skipped 0/.test(fullLog));
const report={date:'2026-10-08',baseCommit:proof.baseCommit,scope:'R01/R02 standard ordinary attack observation + one delivered HD interval21/item0/9..17 (bow vs infantry); full HD goal remains active.',
    delivered:{speId:21,resourceIndex:0,startFrm:9,endFrm:17,nativeCount:54,nativePicmax:18,requiredPictureSlots:[0,1,2,3,6,7,16,17],
        backgroundId:16,numberId:15,manifest:meta('assets/hd-spe/manifest.json'),resourceFingerprint:entry.resourceFingerprint,
        unusedSlots:'Full native metadata preserved; unused ten slots explicitly src/width/height=null. Neighboring five defender ranges retain LCD, not accepted HD.'},
    generated:{tool:'image_gen.imagegen',mode:'builtin',foregroundTargetGroups:51,acceptedForegroundGroups:15,pendingForegroundGroups:36,
        calls:22,acceptedCalls:15,rejected:6,noOutputFailures:1,backdrop:{calls:1,accepted:1},postProcessing:false,
        provenance:['assets/hd-spe/GENERATED-ATTACKS.json','assets/hd-spe/GENERATED-ATTACKS.md','assets/hd-spe/GENERATED-ATTACK-BACKDROP.json','assets/hd-spe/GENERATED-ATTACK-BACKDROP.md'],
        unreferencedReadyArt:'Seven accepted foreground groups are saved for subsequent range integration; asset existence is not browser HD acceptance.',
        alpha:'46 native mask1 /5 mask0 group target. Accepted transparent figures contain actual alpha0 outside and mainly252-253 interiors; original soft alpha kept. Opaque arrow/backdrop fields have slight tonal variation.',
        inputsAndRejectedOutputs:'docs/validation/m4-attacks-20261008/native-input-index.json'},
    native:{changedFiles:proof.nativeChangedFiles,protocols:{spe:2,composition:1,attack:1},readonlyGetter:'baye.hd.attack()',
        sourceRevision:proof.manifest.sourceRevision,sourceModified:proof.manifest.engineSourceModified,sourceHash:proof.manifest.engineSourceSha256,nativeFiles:128,
        background:'Actual PlcRPicShowEx draw before child; true resource identity/signed origin.',clears:'Cumulative real erased footprints and live bits copied by actual SysCopyScreen; timed LCD flush publishes.',
        damage:'Actual CountPlusSub result; decimal glyph index/firstY/drawCount observed from true NUM15 opaque writes. Public SPE remains0 during numbers and hold.',
        gameplay:'CountAtkHurt/CountPlusSub/EXP, delays, key flags and original input branches unchanged; no new skip/return or JS animation clock.',
        retirement:'Native reset, unknown/custom hooks, nested or uncontrolled surfaces, flip/paint/palette mismatch remain neutral/LCD.',
        stagedArtifacts:proof.stagedEngines,installed:read('build/r09-installed-quartet.json'),priorPngAndLibExactRawPreserved:890,
        sourceProof:'docs/validation/m4-attacks-20261008/raw/r09-source-proof.json.gz'},
    validation:{unit:{passed:618,failed:0,skipped:0,includesActualC:true,attackC:65,attackBridge:16,speFrontend:37,
        log:'docs/validation/m4-attacks-20261008/raw/r09-all-tests.log.gz'},offline:'All37 native caller intervals/360 logical commits independently replayed and compared to the fresh native audit; not37 browser attacks.',
        actualPixelScope:'8320 arena pixels independently reconstructed from packed LIB plus native displayed clear/live/digit history;7040 outside pixels compared to first actual copied frame of that event.',
        captureScope:'Actual callback ImageData and separate explicitly labelled native hold readbacks; before/after actual native display stamps equal. Native bitmap oracle is distinct from HD geometry/draw-log checks.',
        runs,fallback,regressionFire:read('build/r09-spe-staged-regression/result.json').fireCoverage,
        makerNaturalHoldMs:read('build/r09-maker-staged-regression-v3/result.json').sessions[0].summary.holdObservedMs,failedRuns:rawFailure},
    visual:{review:native.visualReview.json,scope:'Independently viewed42 native/HD1080 callback/hold PNGs; root also viewed720 first-frame and completed14.',
        result:'Whole soldiers/weapons/projectiles; no blocking opaque-arrow patch/clear seam; damage14 readable and unoccluded.',
        numericHistory:'Native12x16 opaque digit box,6px advance and8 upward draws leave bottom-row trails. Georgia HD gold horizontal remnants are an art interpretation, not native/HD pixel equality.'},
    evidence:{nativeIndex:'docs/validation/m4-attacks-20261008/native-input-index.json',runtimeIndex:'docs/validation/m4-attacks-20261008/runtime-index.json',
        rawFiles:archive.files.length,pngLogicalPaths:archive.images.length,pngRetainedLogical:archive.images.filter(p=>p.retained).length,pngOmittedLogical:archive.images.filter(p=>!p.retained).length,
        selection:archive.imageSelection,gzip:'Every stored raw gzip roundtrip equals its indexed original captured bytes; every retained PNG is an original byte copy.',
        restoration:'Runtime image selection initially missed the native-index archivedPath field;216 reference copies were restored from unchanged originals and603 native mappings rechecked before commit. Final native archive has no missing PNG.'},
    limits:['Only21:9:17 delivered HD;36 other intervals still pending actual HD integration/playback.','36 of51 foreground groups remain unmade at this commit;7 completed art groups are not connected yet.',
        'No actual unknown-LIB/custom attack browser run; actualC/custom and general MAIN/MAKER unknownLIB coverage are separate.','No full four-period/Mod campaign, full succession, fixed-device performance acceptance, Android/iOS or cloud-account acceptance added.'],
    service:{url:'http://localhost:8080/pc',userTabNavigatedOrReloaded:false,privateBrowserProfilesCleaned:true},goalComplete:false};
fs.writeFileSync('docs/validation/m4-attacks-20261008.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({report:'docs/validation/m4-attacks-20261008.json',runs:runs.length,foregroundAccepted:15,pending:36}));
