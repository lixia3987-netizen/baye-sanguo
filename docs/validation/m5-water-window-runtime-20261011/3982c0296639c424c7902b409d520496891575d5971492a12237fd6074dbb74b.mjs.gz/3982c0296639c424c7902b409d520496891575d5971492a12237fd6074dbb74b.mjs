// Dormant writer. Root executes after all four actual scenarios, every attempted
// run, the final suite, final external cleanup proof and immutable archive exist.
// Creating this file neither runs the game nor accepts pending evidence.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import assert from 'node:assert/strict';

const base='build/water-window-runtime-20261011',stem='m5-water-window-runtime-20261011';
const validation='docs/validation',archivePath=`${validation}/${stem}-archive.json`;
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const json=v=>JSON.stringify(v,null,2)+'\n';
const array=(v,label)=>{assert.ok(Array.isArray(v),label);return v;};
const empty=(v,label)=>assert.equal(array(v,label).length,0,label);
const terminal=(r,name)=>{assert.ok(Number.isFinite(Date.parse(r.startedAt)),name+': startedAt');assert.ok(Number.isFinite(Date.parse(r.finishedAt)),name+': finishedAt');assert.ok(Date.parse(r.finishedAt)>=Date.parse(r.startedAt),name+': ordered terminal timestamps');};
const checkpointPins=[
 ['docs/validation/m5-water-window-20261011.md','a720046e5bac6bd49e43ab6dcb3be8ad9cc33330d96ddd2f64cdebe00a6fb1db'],
 ['docs/validation/m5-water-window-20261011.json','038c8c478a35d4edfc2f9af5a5bf4b0e8fb94b190419a6596c6e078655cbd5dd'],
 ['docs/validation/m5-water-window-20261011-archive.json','30a2f403f0b0e2575dd9f481dbc93678790f1ca03dff915ef89496ae32369188']
];
for(const suffix of ['.md','.json'])assert.equal(fs.existsSync(`${validation}/${stem}${suffix}`),false,'new runtime document is append-only');
const archive=read(archivePath),bySource=new Map();
for(const e of array(archive.entries,'archive entries')){assert.equal(typeof e.source,'string');assert.ok(!bySource.has(e.source),'unique source in archive');bySource.set(e.source,e);}
function ref(source){
 const e=bySource.get(source);assert.ok(e,'archive missing '+source);
 const raw=fs.readFileSync(source);assert.equal(raw.length,e.rawBytes,source);assert.equal(sha(raw),e.rawSha256,source);
 const storedPath=path.resolve(validation,e.file),prefix=path.resolve(validation,stem)+path.sep;
 assert.ok(storedPath.startsWith(prefix),'new archive path containment');
 const stored=fs.readFileSync(storedPath);assert.equal(stored.length,e.bytes,source);assert.equal(sha(stored),e.sha256,source);
 const restored=zlib.gunzipSync(stored);assert.equal(restored.length,raw.length,source);assert.equal(sha(restored),e.rawSha256,source);return e;
}
const optionalRef=p=>bySource.has(p)?ref(p):null;
const checkpoint=checkpointPins.map(([p,h])=>{assert.equal(sha(fs.readFileSync(p)),h,'historical source checkpoint unchanged');return ref(p);});
const prior=read(checkpointPins[1][0]);assert.equal(prior.status,'source-validated-runtime-pending');assert.equal(prior.actualRuntime.executed,false);assert.equal(prior.globalHdComplete,false);
const freezePath='build/water-window-20261011/water12-product-final-freeze-v1.json',freeze=read(freezePath);
assert.equal(freeze.frozen,true);assert.equal(freeze.inverseAllThreeByteExact,true);
assert.equal(freeze.manifest.beforeEntries,53);assert.equal(freeze.manifest.afterEntries,54);assert.equal(freeze.manifest.oldEntriesObjectAndOrderExact,true);assert.equal(freeze.manifest.topFieldsExact,true);
assert.equal(freeze.scope.nativeChanged,false);assert.equal(freeze.scope.newArt,false);
for(const f of freeze.products){const b=fs.readFileSync(f.path);assert.equal(b.length,f.bytes,f.path);assert.equal(sha(b),f.sha256,f.path);}
for(const f of [freeze.source.lib,...freeze.source.pictures]){const b=fs.readFileSync(f.path);assert.equal(b.length,f.bytes,f.path);assert.equal(sha(b),f.sha256,f.path);}
const manifest=read('assets/hd-spe/manifest.json');assert.equal(manifest.entries.length,54);assert.equal(manifest.libSha256,freeze.source.lib.sha256);
const water=manifest.entries.filter(e=>e.waterVersion===1);assert.equal(water.length,1);assert.equal(water[0].skillId,12);assert.equal(water[0].opaqueCoverageVersion,1);
const nativeAggregate=prior.native.aggregate;
const suitePath=`${base}/final-suite/result.json`,suite=read(suitePath);terminal(suite,'final suite');
assert.equal(suite.exitCode,0);assert.equal(suite.executionConcurrency,1);assert.ok(Number.isInteger(suite.modules)&&suite.modules>0);
assert.ok(Number.isInteger(suite.counts.tests)&&suite.counts.tests>0);assert.equal(suite.counts.tests,suite.counts.pass);
for(const k of ['fail','cancelled','skipped','todo'])assert.equal(suite.counts[k],0,k);
empty(suite.sourceDrift,'final suite source drift');assert.ok(array(suite.sources,'suite sources').length>0);

// Enumerate only named terminal result directories, never profiles. This retains
// both the unaccepted attempt and the superseded preflight under their own IDs.
const all=[];
for(const name of fs.readdirSync(base).filter(n=>/^(?:pc-|preflight-)[a-z0-9-]+$/i.test(n)).sort()){
 const directory=`${base}/${name}`;if(!fs.statSync(directory).isDirectory())continue;
 const r=read(`${directory}/result.json`);terminal(r,name);all.push({name,directory,r});
}
assert.ok(all.length>=4,'actual scenarios must exist');
function sourceCheck(r,name){
 const v=r.sourceVerification;assert.equal(v.ok,true,name+': frozen sources');empty(v.drift,name+': source drift');empty(v.added,name+': added sources');assert.equal(v.runnerMatch,true,name+': runner');
 assert.ok(Number.isInteger(v.count)&&v.count>0);assert.equal(array(v.sources,'runtime source list').length,v.count);
 for(const f of freeze.products){const a=v.sources.find(s=>s.path===f.path);assert.ok(a,name+': '+f.path);assert.equal(a.bytes,f.bytes);assert.equal(a.sha256,f.sha256);}
 assert.equal(r.nativeSourceCheck.count,128);assert.equal(r.nativeSourceCheck.aggregate,nativeAggregate);assert.equal(r.engineManifest.engineSourceSha256,nativeAggregate);
 assert.equal(sha(fs.readFileSync(`${base}/${name}/executed-tool.mjs`)),r.tool.sha256,name+': executed tool bytes');
}
function cleanupRun(r,name){
 assert.equal(r.cleanup.treeExited,true,name+': historical owned tree exited');assert.equal(r.isolation.cleaned,true);assert.equal(r.isolation.chromeExited,true);assert.equal(r.isolation.httpClosed,true);
 assert.equal(r.isolation.user8080Touched,false);assert.equal(r.directoriesDeleted,false);assert.equal(r.profileRetained,true);
}
const unit=(w,index)=>array(w.units,'actual units').find(u=>u.i===index);
function attempt(a,index){
 assert.equal(a.skill.id,12);assert.equal(a.skill.speId,36);
 const actor0=unit(a.before,a.actor.i),actor1=unit(a.after,a.actor.i),target0=unit(a.before,a.target.i),target1=unit(a.after,a.target.i);
 assert.ok(actor0&&actor1&&target0,'actual actor and target samples');assert.equal(actor0.id,a.actor.id);assert.equal(target0.id,a.target.id);
 assert.equal(actor0.mp-actor1.mp,20,'real WATER12 MP cost');
 return {attempt:index+1,weather:a.before.weather,actor:{slot:a.actor.i,nativeToken:a.actor.id,personIndex:a.actor.personIndex,name:a.actor.name},target:{slot:a.target.i,nativeToken:a.target.id,personIndex:a.target.personIndex,name:a.target.name},mpBefore:actor0.mp,mpAfter:actor1.mp,armsBefore:target0.arms,armsAfter:target1?.arms??0,damage:target0.arms-(target1?.arms??0)};
}
const realCapture=c=>!!(c.spe?.active&&c.spe.id===36&&c.spe.kind===2&&c.spe.contextKnown===true&&c.spe.skillId===12||c.result?.active&&c.result.speId===36&&c.result.skillId===12&&c.result.display?.valid);
function normalizedRgba(value){const b=Buffer.from(value||'','base64');assert.equal(b.length,160*96*4,'complete160x96 raw readback');for(let i=0;i<b.length;i+=4)if(!b[i+3])b.fill(0,i,i+4);return b;}
function imageRef(directory,saved){
 assert.equal(typeof saved.file,'string');const p=path.resolve(directory,saved.file),prefix=path.resolve(directory)+path.sep;assert.ok(p.startsWith(prefix),'saved PNG remains inside its run');
 const b=fs.readFileSync(p);assert.equal(b.length,saved.bytes);assert.equal(sha(b),saved.sha256);return {file:saved.file,bytes:saved.bytes,sha256:saved.sha256,archived:optionalRef(path.relative(process.cwd(),p).replaceAll('\\','/'))};
}
function actual({name,directory,r},scenario){
 for(const k of ['ok','accepted','actualCastAccepted'])assert.equal(r[k],true,name+': '+k);
 assert.equal(r.preflightOnly,false);assert.equal(r.staged,false);assert.equal(r.skillId,12);assert.equal(r.speId,36);
 assert.deepEqual(r.viewport,scenario.viewport);assert.equal(r.classic,scenario.classic);assert.equal(r.missingAssets,scenario.missingAssets);
 const fallback=r.classic||r.missingAssets;assert.equal(r.hdAccepted,!fallback);assert.equal(r.fallbackAccepted,fallback);
 empty(r.exceptions,name+': browser exceptions');empty(r.observerErrors,name+': observer errors');sourceCheck(r,name);cleanupRun(r,name);
 assert.equal(r.actualLib.sha256,manifest.libSha256);assert.equal(r.actualLib.byteLength,207195);
 const wr=r.waterNativeResource;assert.ok(wr,'actual ROM skill/name/range report');assert.equal(wr.id,36);assert.equal(wr.length,1084);assert.equal(wr.fingerprint,'fnv1a32:6d62e7a8:1084');
 assert.equal(wr.actualSkillName.hex,'cbaed1cd');assert.equal(wr.actualSkillName.name,'水淹');assert.equal(wr.actualSkill.useMp,20);assert.equal(wr.actualSkill.aim,0);assert.equal(wr.actualSkill.state,0);
 assert.deepEqual(wr.defaultNavySkills.row,[12,13,11,0,0,0,0,0,0,0]);assert.equal(wr.special.value,0);
 assert.equal(wr.units.length,8);wr.units.forEach((u,i)=>assert.deepEqual(u,{x:0,y:0,cdelay:20,ndelay:20,picIndex:i%2}));
 assert.deepEqual(wr.pictures,[{picIndex:0,width:64,height:64,mask:0},{picIndex:1,width:64,height:64,mask:0}]);
 const pixo=r.nativePixelOracle;assert.equal(pixo.sourceCopies,8);assert.ok(pixo.actualLcdCallbacks>0&&pixo.events>0);assert.equal(pixo.outsidePixelsPerHdReadback,11264);
 assert.ok(pixo.labels>0&&pixo.numericReadbacks>0&&pixo.completedHoldReadbacks>0,'actual GBK label, NUM and HOLD');
 const verified=array(pixo.verified,'independent native LCD/readback comparisons');assert.ok(verified.length>0);
 for(const v of verified){assert.equal(v.nativeRgbaSha256,v.independentExpectedSha256,'actual native LCD equals independent ROM/NUM reconstruction');assert.equal(v.source,fallback?'lcd':'hd-assets');}
 if(fallback){assert.equal(pixo.movieHd,0);assert.equal(pixo.postHd,0);assert.ok(pixo.fallbackReadbacks>=2);assert.equal(pixo.outsidePixelComparisons,0);}
 else{assert.ok(pixo.movieHd>=2&&pixo.postHd>0);assert.equal(pixo.fallbackReadbacks,0);assert.equal(pixo.outsidePixelComparisons,(pixo.movieHd+pixo.postHd)*11264);}
 if(r.missingAssets)assert.ok(r.requests.some(q=>q.status===404&&q.expected&&water[0].pictures.some(f=>'/'+f.src===q.url)),'actual exact WATER image404');
 const savedCaptures=read(`${directory}/native-skill-captures.json`);assert.deepEqual(savedCaptures,r.skillCaptures,'separate capture original equals terminal result');
 assert.deepEqual(read(`${directory}/observer-errors.json`),r.observerErrors);assert.deepEqual(read(`${directory}/engine-inputs.json`),r.engineInputs);
 const captures=array(r.skillCaptures,'actual captures').filter(realCapture);assert.equal(captures.length,verified.length,'every accepted readback represented');
 const filePairs=[];
 for(const c of captures){
  assert.deepEqual(c.before,c.after,'read-only observer');if(c.callbackBefore)assert.deepEqual(c.callbackBefore,c.callbackAfter,'read-only LCD callback');
  assert.equal(c.hidden,false);assert.equal(c.nativeWidth,160);assert.equal(c.nativeHeight,96);
  const native=normalizedRgba(c.nativeRgba),shown=normalizedRgba(c.hdLogicalRgba);
  if(fallback){assert.deepEqual(shown,native,'complete15360 LCD pixels preserved');assert.equal(c.displayedCanvas,r.classic?'lcd':'hd-spe-canvas');}
  else{
   assert.equal(c.ui.open,true);assert.equal(c.ui.source,'hd-assets');assert.equal(c.ui.outsideSource,'lcd');assert.deepEqual(c.ui.sourceRect,{x:0,y:0,width:160,height:96});assert.deepEqual(c.ui.hdRegion,{x:48,y:16,width:64,height:64});
   assert.equal(c.dom.visible,true);assert.equal(c.dom.inViewport,true);assert.equal(c.dom.stackOwned,true);
   for(let y=0;y<96;y++)for(let x=0;x<160;x++)if(!(x>=48&&x<112&&y>=16&&y<80)){const i=(y*160+x)*4;assert.ok(native.subarray(i,i+4).equals(shown.subarray(i,i+4)),'outside WINDOW exact LCD pixel');}
  }
  filePairs.push({native:imageRef(directory,c.nativeFile),shown:imageRef(directory,c.hdFile)});
 }
 const first=Math.min(...captures.map(c=>c.at)),last=Math.max(...captures.map(c=>c.at));assert.ok(Number.isFinite(first)&&Number.isFinite(last));
 const readonlyKeys=array(r.engineInputs,'native engine inputs').filter(k=>k.at>=first&&k.at<=last);assert.equal(readonlyKeys.length,0,'no extra key during movie/NUM/HOLD');
 const legal=array(r.waterAttempts,'legal WATER attempts').map(attempt);assert.ok(legal.length>0);
 const numeric=captures.find(c=>c.result?.active&&c.result.skillId===12&&c.result.display?.digits?.length)?.result;
 assert.ok(numeric,'actual native numeric result');assert.equal(numeric.resultKind,1);assert.equal(numeric.custom,false);assert.equal(numeric.sourceValid,true);
 const matched=r.waterAttempts.findIndex(a=>a.actor.i===numeric.actorIndex&&a.target.i===numeric.targetIndex&&(!a.resultOwnerAfter||a.resultOwnerAfter.session===numeric.session));
 assert.ok(matched>=0,'actual result belongs to public legal attempt');assert.equal(legal[matched].damage,numeric.value);assert.equal(r.actualDamage.value,numeric.value);
 const summary={...pixo};delete summary.verified;
 return {name,scenario:scenario.id,viewport:r.viewport,classic:r.classic,missingAssets:r.missingAssets,accepted:true,actualCastAccepted:true,hdAccepted:r.hdAccepted,fallbackAccepted:r.fallbackAccepted,
  startedAt:r.startedAt,finishedAt:r.finishedAt,phases:r.phases.length,publicInputs:r.inputs.length,engineInputs:r.engineInputs.length,sourceCount:r.sourceVerification.count,tool:r.tool,
  attempts:legal,result:{session:numeric.session,kind:numeric.resultKind,value:numeric.value,attempt:matched+1},readonlyExtraKeys:0,pixels:{...summary,verifiedReadbacks:verified.length},scope:r.scope,
  evidence:ref(`${directory}/result.json`),executedTool:ref(`${directory}/executed-tool.mjs`),captures:ref(`${directory}/native-skill-captures.json`),engineInputEvidence:ref(`${directory}/engine-inputs.json`),sourceVerification:ref(`${directory}/source-verification.json`),
  selectedImages:archive.entries.filter(e=>e.source.startsWith(directory+'/')&&/\.png$/i.test(e.source)).map(e=>ref(e.source)),readbackFiles:filePairs};
}
const scenarios=[
 {id:'pc1080-hd',viewport:{width:1920,height:1080},classic:false,missingAssets:false},
 {id:'pc720-hd',viewport:{width:1280,height:720},classic:false,missingAssets:false},
 {id:'exact-image404-lcd',viewport:{width:1920,height:1080},classic:false,missingAssets:true},
 {id:'classic-lcd',viewport:{width:1920,height:1080},classic:true,missingAssets:false}
];
const runs=scenarios.map(s=>{
 const choices=all.filter(a=>a.r.accepted===true&&a.r.actualCastAccepted===true&&!a.r.preflightOnly&&a.r.staged===false&&a.r.classic===s.classic&&a.r.missingAssets===s.missingAssets&&a.r.viewport?.width===s.viewport.width&&a.r.viewport?.height===s.viewport.height).sort((a,b)=>Date.parse(a.r.finishedAt)-Date.parse(b.r.finishedAt));
 assert.ok(choices.length,'actual terminal scenario remains pending: '+s.id);return actual(choices.at(-1),s);
});
// All accepted matrix runs must use the same frozen repaired runner. Failed and
// superseded records retain their own executed bytes and are not rewritten.
assert.equal(new Set(runs.map(r=>r.tool.sha256)).size,1,'one final actual runner');
const correction=read(`${base}/runner-resource-correction-v1.json`);assert.equal(correction.frozen,true);assert.equal(correction.delta.onlyDelta,true);assert.equal(correction.delta.inverse.byteExactBefore,true);
assert.equal(runs[0].tool.sha256,correction.after.sha256,'all accepted cases use the repaired native-resource report');
const attempts=all.map(({name,directory,r})=>{
 sourceCheck(r,name);const preflight=!!r.preflightOnly;
 if(preflight){assert.equal(r.actualCastAccepted,false);assert.equal(r.hdAccepted,false);assert.equal(r.fallbackAccepted,false);assert.equal(r.inputs.length,0);assert.equal(r.phases.length,0);}
 else cleanupRun(r,name);
 if(!r.accepted)for(const k of ['actualCastAccepted','hdAccepted','fallbackAccepted'])assert.equal(r[k],false,name+': unaccepted flags');
 const missingReport=name==='preflight-v1'&&r.waterNativeResource==null;
 const missingReportFailure=name==='pc-1080-v1'&&/actualSkillName/.test(r.error||'');
 if(missingReportFailure){assert.equal(r.accepted,false);assert.equal(r.skillCaptures.length,0);}
 return {name,preflightOnly:preflight,accepted:r.accepted===true,actualCastAccepted:r.actualCastAccepted===true,hdAccepted:r.hdAccepted===true,fallbackAccepted:r.fallbackAccepted===true,
  classification:missingReport?'superseded-preflight-missed-native-resource-report-gate':missingReportFailure?'runner-missing-native-resource-report-before-cast':preflight?'preflight-only-not-actual':r.accepted?'accepted-actual':r.skillCaptures?.length?'unaccepted-actual-check-failure':'unaccepted-no-WATER-capture',
  error:r.error||null,startedAt:r.startedAt,finishedAt:r.finishedAt,tool:r.tool,sourceCount:r.sourceVerification.count,legalAttempts:(r.waterAttempts||[]).map(attempt),capturedWATER:(r.skillCaptures||[]).filter(realCapture).length,
  evidence:ref(`${directory}/result.json`),executedTool:ref(`${directory}/executed-tool.mjs`),captures:optionalRef(`${directory}/native-skill-captures.json`),inputEvidence:optionalRef(`${directory}/engine-inputs.json`)};
});
// A superficially ok historical proof with zero parsed identities is retained as
// invalid evidence. Acceptance uses the FINAL UTF8+terminating-error proof only.
const cleanup=read(`${base}/cleanup-verification.json`);assert.equal(cleanup.ok,true);empty(cleanup.survivors,'historical survivors');empty(cleanup.privateListeners,'private listeners');assert.equal(cleanup.userUnchanged,true);assert.equal(cleanup.userHttpStatus,200);
assert.equal(cleanup.userService.ProcessId,57860);assert.equal(cleanup.userService.CreationDate,'2026-10-10T11:26:04.2797180Z');assert.equal(cleanup.userService.ExecutablePath,'C:\\Program Files\\nodejs\\node.exe');
const historical=all.filter(a=>Object.hasOwn(a.r,'historicalRecordedIdentities')),identities=new Map(),ports=new Set();
for(const a of historical){
 for(const p of array(a.r.historicalRecordedIdentities,'historical identities')){assert.ok(Number.isInteger(p.ProcessId)&&p.ProcessId>0);assert.match(p.CreationDate,/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{7}Z$/);const key=p.ProcessId+'|'+p.CreationDate;const old=identities.get(key);if(old)assert.equal(old.ExecutablePath,p.ExecutablePath);identities.set(key,p);}
 for(const port of [a.r.httpPort,a.r.debugPort,a.r.isolation?.httpPort,a.r.isolation?.debugPort])if(port)ports.add(port);
}
assert.equal(cleanup.attemptCount,historical.length,'final proof covers every historical attempt');assert.equal(cleanup.recordedCount,identities.size,'final proof covers the exact PID/birth union');assert.ok(identities.size>0);
assert.deepEqual([...cleanup.privatePorts].sort((a,b)=>a-b),[...ports].sort((a,b)=>a-b),'all private ports covered');assert.ok(Date.parse(cleanup.sampledAt)>=Math.max(...all.map(a=>Date.parse(a.r.finishedAt))),'final external proof follows every terminal attempt');
const invalidPath=`${base}/cleanup-verification-after-v1.json`,invalidProof=optionalRef(invalidPath);
if(invalidProof){const old=read(invalidPath);assert.equal(old.recordedCount,0);}
const preflights=attempts.filter(a=>a.preflightOnly),finalPreflight=preflights.filter(a=>a.accepted&&a.tool.sha256===runs[0].tool.sha256).at(-1);assert.ok(finalPreflight,'final runner preflight exists; not counted as actual');
const suiteSummary={startedAt:suite.startedAt,finishedAt:suite.finishedAt,executionConcurrency:suite.executionConcurrency,modules:suite.modules,exitCode:suite.exitCode,counts:suite.counts,sourceCount:suite.sources.length,sourceDrift:[],evidence:ref(suitePath),log:ref(`${base}/final-suite/test-output.log`),executedRunner:ref(`${base}/final-suite/runner-executed.mjs`)};
const cleanupSummary={sampledAt:cleanup.sampledAt,attemptCount:cleanup.attemptCount,recordedCount:cleanup.recordedCount,survivors:[],privateListeners:[],privatePorts:cleanup.privatePorts,userUnchanged:true,userPid:57860,userBirth:cleanup.userService.CreationDate,userHttpStatus:200,evidence:ref(`${base}/cleanup-verification.json`),invalidHistoricalProof:invalidProof?{classification:'invalid-not-acceptance',reason:'PowerShell5 UTF8 decoding / nonterminating ConvertFromJson failure yielded recordedCount0; superficially ok does not establish an identity union.',evidence:invalidProof,executedScript:optionalRef(`${base}/verify-cleanup-before-utf8-fix.ps1`)}:null,finalScript:ref(`${base}/verify-cleanup.ps1`)};
const independentPaths=['pc-1080-v2-independent-audit-v1.json','pc-720-v1-independent-audit-v1.json','pc-missing-v1-independent-audit-v1.json','pc-classic-v1-independent-audit-v1.json','fallback-transparent-display-review-v1.json'].map(n=>`${base}/independent-review/${n}`);
for(const p of independentPaths)assert.equal(read(p).auditOk,true,'frozen independent review: '+p);
const limits=['Only original WATER12/SPE36 is newly accepted. Shared36 skill19 retains its legacy route; FIRE classic remains pending under its own record.',
 'The complete160x96 base and every pixel outside64x64 remain actual LCD. This is not a complete HD battle scene or an independent colored-pixel oracle inside the HD window.',
 'LCD equality is a raw RGBA readback result, including alpha; only invisible RGB under alpha0 is normalized. Transparent canvas PNGs require the page light CSS background for black text. HOLD computedStyle and a held full-page composited screenshot were not captured, so CSS-composited contrast is not independently accepted; see fallback-transparent-display-review-v1.json.',
 'Eight distinct source copies and measured LCD callbacks are separate quantities; coalesced callbacks do not prove every physical display frame.',
 'New mobile tests remain controlled VM tests, not mobile browser/real Android/iOS acceptance. Other periods/skills, custom gameplay, full campaign/save/RNG continuity, visibility/resize matrix and performance remain pending.'];
const result={schemaVersion:1,createdAt:new Date().toISOString(),status:'partial',globalHdComplete:false,originalOnly:true,versionSelectorRemoved:true,
 product:'Original WATER12 retains the full160x96 native LCD and replaces only the authenticated opaque64x64@48,16 movie/NUM/HOLD window with the existing two PNGs.',checkpointPreserved:checkpoint,
 manifest:{before:53,after:54,oldObjectsAndOrderExact:true,topLevelExact:true,onlyAddedSkill12:true,art:freeze.source.pictures},runs,attempts,preflight:{final:finalPreflight,actualAcceptance:false},suite:suiteSummary,cleanup:cleanupSummary,
 native:{changed:false,rebuilt:false,count:128,aggregate:nativeAggregate},sourceRefs:[ref(freezePath),ref(freeze.delta.path),ref(freeze.pureGates.path),ref('build/water-window-20261011/frontend-tests-freeze-v1.json'),ref(`${base}/runner-resource-correction-v1.json`),...independentPaths.map(ref)],
 controlledCheckpoint:{addedTests:prior.addedTests,suite:prior.defaultSuite,boundary:'Preserved source checkpoint; its actual/preflight pending fields are historical and are not rewritten.'},limits,archive:`./${stem}-archive.json`};
const total=runs.reduce((s,r)=>({copies:s.copies+r.pixels.sourceCopies,callbacks:s.callbacks+r.pixels.actualLcdCallbacks,readbacks:s.readbacks+r.pixels.verifiedReadbacks}),{copies:0,callbacks:0,readbacks:0});
const note=`2026-10-11 最新[原版WATER12高清窗口实战](validation/${stem}.md)：水淹36／技能12保留完整160×96原版底图，只替换实际认证的64×64@48,16范围，电影／原生数字／等待沿真实提交。PC1080／720高清、精确缺图与经典LCD四个独立合法新局通过；高清窗口外每次11264个逻辑像素与原版LCD的RGBA读回一致，两种回退完整15360像素读回一致，不扩为HOLD页面CSS合成对比度验收。manifest54项，原53项及共享海啸19保持，无新素材或native构建。最终${suite.modules}模块串行 **${suite.counts.pass}／${suite.counts.tests}通过**，失败／取消／跳过／todo均0，${suite.sources.length}执行来源无漂移。首1080运行器缺少原生资源报告、过早预检及无效旧清理proof均保留并明确不计接受；旧源码检查点原样保留。移动仅受控VM、真机／其它技能／性能与完整流程仍待，完整HD保持 **partial**。`;
const table=runs.map(r=>`| ${r.name} | ${r.viewport.width}×${r.viewport.height} | ${r.hdAccepted?'高清窗口':r.classic?'经典LCD':'精确缺图LCD'} | ${r.attempts.length} | ${r.pixels.sourceCopies}／${r.pixels.actualLcdCallbacks} | ${r.pixels.numericReadbacks}／${r.pixels.completedHoldReadbacks} | ${r.readonlyExtraKeys} | ${r.sourceCount} |`).join('\n');
const failureText=attempts.filter(a=>!a.accepted&&!a.preflightOnly).map(a=>`- ${a.name}：${a.classification}；${a.legalAttempts.length}次已记录合法施放、${a.capturedWATER}次WATER读回，actual／HD／fallback均false。${a.error?.split('\n')[0]||'失败原件单独保留。'}`).join('\n');
const md=`# 原版WATER12高清窗口实战验证（2026-10-11）

${note.slice(note.indexOf('：')+1)}

## 产品与原生范围

本批实际验证原版时期3韩玄、长沙33→桂阳36的合法公开流程，水军王朗Person14／原生token15使用水淹12／SPE36。依据当前实际ROM技能名、34字节技能记录、水军默认技能、8邻格范围与公开AIM判定，不改人物、世界、概率或RNG。施法MP真实扣20，伤兵与原生resultKind1/value、实际目标兵数逐次绑定，不能从动画推算伤害。

独立waterVersion1／opaqueCoverageVersion1绑定标准LIB与资源36／0、FNV6d62e7a8／1084字节、0..7八单位、两槽64×64和真实20／20延迟。完整160×96 LCD先保留，只替换64×64@48,16不透明窗口。NUM15真实GBK“兵力减少”、55,18标签与6px步距数字、56→49绘制历史及原生等待保留；current／display／clear-frontier／flush／data与绘制后复核失效时回LCD，不新增输入或等待流程。manifest54项，旧53项及顺序和顶层身份原样保持，两张原PNG复用，共享36海啸19仍沿旧路径。

## 四场终态实际通过

| 私局 | 浏览器尺寸 | 接受范围 | 合法施放尝试 | 源复制／实际LCD回调 | 数字／完整等待读回 | 捕获期额外键 | 冻结来源 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
${table}

四场共${total.copies}次源复制、${total.callbacks}次实际LCD回调和${total.readbacks}次已验读回。8次不同源复制不等于8个物理帧均逐一截取；回调合并范围明确保留。高清每次读回的窗口外11264个逻辑像素与当前原版LCD逐像素一致；精确图片404与经典两场完整15360个逻辑像素一致。上述LCD一致限原始RGBA读回口径，包含alpha，仅alpha=0时不可见RGB按原验算口径归一。原生LCD另经实际ROM图片、GBK／数字历史独立重建比对；此处没有宣称窗口内彩色高清画面具备独立逐像素美术基准。实际DOM可见、视口及遮挡、NUM／HOLD、真实退休和捕获期0额外键分别记录。

单张canvas导出的PNG有大量透明背景、黑色文字和半透明灰色河流；PNG本身不包含页面CSS背景，在黑底查看器中黑字可能不可见。实际页面依赖浅色canvas背景，缺图画布CSS为\`#e6edd4\`，经典LCD采用silver（全局HD主题可为\`#c8c8c8\`）。本轮没有采集HOLD时的computedStyle或当时全页CSS合成截图，因此原始RGBA／alpha相等及DOM可见不能扩大为最终CSS合成对比度验收，也没有据此认定产品显示失败。四场独立审查和透明PNG显示边界原件\`fallback-transparent-display-review-v1.json\`均见结构化sourceRefs；待验边界单独保留。

各次真实actor／target／天气／MP／兵力／会话与伤害结果见结构化记录，四场不混用旧FIRE或历史WATER结果。实际只读观察器前后原生快照与LCD回调快照一致；没有模拟伤害或为动画补键。

## 失败、预检与旧检查点

${failureText||'没有未接受的实际尝试。'}

preflight-v1虽accepted但仅准备检查，遗漏waterNativeResource报告发布门；首1080在读取actualSkillName时停止，尚未施放WATER，不能计实战。修复只恢复1886字节原生技能／名称／范围报告块，旧runner／失败／修复逆差保留，正式四场使用同一修复后runner。新preflight-v2仍只是预检，不计实际施放；其余未来或失败尝试同样不因预检／单测通过而接受。

旧清理输出cleanup-verification-after-v1.json受PowerShell5读取UTF8无BOM及ConvertFromJson非终止错误影响，记录attempt1／recorded0而表面ok=true，明确为 **invalid-not-acceptance**。最终清理采用显式UTF8和终止错误策略，仅本轮最终proof计入接受。旧脚本和错误输出均保留，不伪装为一次有效OS核验。

[WATER源码检查点](m5-water-window-20261011.md)的MD／JSON／归档三件SHA及runtime-pending状态保持原字节；新实战记录只补充本轮事实。源码批新增${prior.addedTests.total}项受控用例，移动${prior.addedTests.mobileControlledVm}项仅VM；编译C夹具不是手机浏览器实跑。源码批首轮共用C夹具锚点／mode碰撞导致的15项失败及恢复记录保留，不混同本轮实际失败。

## 回归、冻结与隔离

最终默认${suite.modules}模块串行${suite.counts.pass}／${suite.counts.tests}通过，失败／取消／跳过／todo均0，${suite.sources.length}执行来源无漂移；该数来自本轮终态，旧检查点的228执行来源只属历史。原128份native来源聚合仍为\`${nativeAggregate}\`，安装来源一致，本轮无新native构建或素材生成。

最终外部只读证明覆盖${cleanup.attemptCount}次含历史身份记录的尝试、${cleanup.recordedCount}个精确PID／出生时间身份；无存活和私有端口listener。原8080 PID57860／出生时间／exe及HTTP200保持。各运行器自身也报告owned tree退出和私服关闭；profile保留未删，外部OS结论只归属于根代理的保存proof。

归档保存全部终态JSON／JSONL／NDJSON／日志／执行工具、冻结来源、独立审查和测试／清理证明，并选取首末已捕获电影、NUM／HOLD及失败／退休PNG。其它原始截图与私有profile仍留本机，不说成全量截图入库；gzip存储及原字节SHA均可往返核对。

完整HD仍为partial，globalHdComplete=false。共享海啸19、其它技能／时期、移动实际浏览器／真机、每物理帧、完整可见性／resize矩阵、性能、完整战役／存读档／RNG连续性继续待验；经典FIRE另批仍pending，本轮经典WATER不替代它。

[结构化结果](${stem}.json) · [归档索引](${stem}-archive.json)
`;
function replaceRow(text,id,change){const lines=text.split('\n'),indices=lines.flatMap((line,i)=>line.startsWith(`| ${id} |`)?[i]:[]);assert.equal(indices.length,1,id+' unique table row');const i=indices[0],cr=lines[i].endsWith('\r')?'\r':'',parts=lines[i].replace(/\r$/,'').split('|');assert.equal(parts.length,8);change(parts);lines[i]=parts.join('|')+cr;return lines.join('\n');}
const planWrites=['docs/hd-development-plan.md','docs/hd-remaining-work.md'].map(file=>{
 let text=fs.readFileSync(file,'utf8');assert.ok(!text.includes(`validation/${stem}.md`),'one-shot current plan update');
 const nl=text.indexOf('\n');assert.ok(nl>=0);text=text.slice(0,nl+1)+'\n'+note+'\n'+text.slice(nl+1).replace('2026-10-11 最新[原版WATER12高清窗口源码检查点]','2026-10-11 前批[原版WATER12高清窗口源码检查点]');
 if(file.endsWith('hd-remaining-work.md')){
  text=replaceRow(text,'R01',p=>{const old='本批WATER12全LCD底图／64×64窗口源码及受控回归通过，实际矩阵待验；';assert.ok(p[3].includes(old));p[3]=p[3].replace(old,'本批原版WATER12全LCD底图／64×64窗口电影＋NUM／HOLD的PC1080／720高清、精确缺图和经典LCD四场已验；');p[5]=` [本批WATER实战](validation/${stem}.md)；`+p[5].trim()+' ';});
  text=replaceRow(text,'R02',p=>{p[3]=' WATER12复用原两PNG，完整LCD底图与高清窗口／两种LCD回退四场已验；'+p[3].trim()+' ';const old='[WATER12源码检查点](validation/m5-water-window-20261011.md)的实际施放仍待验';assert.ok(p[5].includes(old));p[5]=p[5].replace(old,`[WATER12实战](validation/${stem}.md)四场通过，[源码检查点](validation/m5-water-window-20261011.md)保留原历史范围`);});
  text=replaceRow(text,'R13',p=>{p[3]=` 当前${suite.modules}模块串行${suite.counts.pass}／${suite.counts.tests}通过，失败／取消／跳过／todo均0，${suite.sources.length}执行来源无漂移；WATER12四场限定实战通过，FIRE经典另批待验 `;p[5]=` [本批${suite.counts.tests}项与WATER实战](validation/${stem}.md)；`+p[5].trim().replace('[本批4339项与FIRE窗口]','[前批4339项与FIRE窗口]').replace('[本批4207项与场景实跑]','[前批4207项与场景实跑]')+' ';});
 }
 return {file,text};
});
// Every terminal/acceptance/archive/identity assertion and plan anchor above must
// pass before any document is written. The source checkpoint is never written.
fs.writeFileSync(`${validation}/${stem}.json`,json(result),{flag:'wx'});
fs.writeFileSync(`${validation}/${stem}.md`,md,{flag:'wx'});
for(const p of planWrites)fs.writeFileSync(p.file,p.text);
for(const[p,h]of checkpointPins)assert.equal(sha(fs.readFileSync(p)),h,'historical checkpoint still unchanged');
console.log(json({written:[`${validation}/${stem}.json`,`${validation}/${stem}.md`,...planWrites.map(p=>p.file)],actualRuns:runs.length,attempts:attempts.length,tests:suite.counts.tests,globalHdComplete:false}));
