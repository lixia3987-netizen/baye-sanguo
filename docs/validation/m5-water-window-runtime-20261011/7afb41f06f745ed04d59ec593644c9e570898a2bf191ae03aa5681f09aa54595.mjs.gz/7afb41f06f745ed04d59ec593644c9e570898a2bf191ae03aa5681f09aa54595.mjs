// Dormant evidence writer. Root executes only after every attempted run ends.
// Never traverses browser profiles and never changes the source checkpoint.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import assert from 'node:assert/strict';

const base='build/water-window-runtime-20261011',stem='m5-water-window-runtime-20261011';
const target='docs/validation/'+stem,indexPath='docs/validation/'+stem+'-archive.json';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const normalize=p=>p.replaceAll('\\','/');
const files=new Set(),evidenceExtension=/\.(json|jsonl|ndjson|log|mjs|ps1|txt)$/i;
const checkpointPins=[
 ['docs/validation/m5-water-window-20261011.md','a720046e5bac6bd49e43ab6dcb3be8ad9cc33330d96ddd2f64cdebe00a6fb1db'],
 ['docs/validation/m5-water-window-20261011.json','038c8c478a35d4edfc2f9af5a5bf4b0e8fb94b190419a6596c6e078655cbd5dd'],
 ['docs/validation/m5-water-window-20261011-archive.json','30a2f403f0b0e2575dd9f481dbc93678790f1ca03dff915ef89496ae32369188']
];
assert.equal(fs.existsSync(indexPath),false,'new runtime archive must not overwrite an existing record');
for(const[p,hash]of checkpointPins){assert.equal(sha(fs.readFileSync(p)),hash,'preserve old checkpoint bytes: '+p);files.add(p);}
for(const p of ['build/water-window-20261011/water12-product-final-freeze-v1.json',
 'build/water-window-20261011/water12-product-forward-inverse-delta-v1.json',
 'build/water-window-20261011/water12-product-pure-gates-v1.json',
 'build/water-window-20261011/frontend-tests-freeze-v1.json'])files.add(p);
const productFreeze=read('build/water-window-20261011/water12-product-final-freeze-v1.json');
for(const f of productFreeze.products){const raw=fs.readFileSync(f.path);assert.equal(raw.length,f.bytes,f.path);assert.equal(sha(raw),f.sha256,f.path);files.add(f.path);}

function contained(root,relative){
 assert.equal(typeof relative,'string');
 const absolute=path.resolve(root,relative),prefix=path.resolve(root)+path.sep;
 assert.ok(absolute.startsWith(prefix),'captured file must remain inside its run: '+relative);
 assert.equal(fs.lstatSync(absolute).isSymbolicLink(),false,'no evidence symlinks');return absolute;
}
function addSmallFiles(directory){
 for(const name of fs.readdirSync(directory)){
  const p=path.join(directory,name),s=fs.lstatSync(p);assert.equal(s.isSymbolicLink(),false,'no evidence symlinks');
  if(s.isFile()&&evidenceExtension.test(name))files.add(p);
 }
}
function addFrozen(directory){
 for(const name of fs.readdirSync(directory)){
  const p=path.join(directory,name),s=fs.lstatSync(p);assert.equal(s.isSymbolicLink(),false,'no frozen-source symlinks');
  assert.equal(s.isDirectory(),false,'frozen-sources is a flat immutable collection');if(s.isFile())files.add(p);
 }
}
addSmallFiles(base);
for(const name of fs.readdirSync(base)){
 const directory=path.join(base,name),s=fs.lstatSync(directory);assert.equal(s.isSymbolicLink(),false,'no base symlinks');
 if(!s.isDirectory())continue;
 // No generic recursive traversal: a profile directory can never be evidence.
 if(!/^(?:pc-[a-z0-9-]+|preflight-[a-z0-9-]+|final-suite(?:-[a-z0-9-]+)?|independent-review|frozen-sources)$/i.test(name))continue;
 if(name==='frozen-sources'){addFrozen(directory);continue;}
 addSmallFiles(directory);
 const result=path.join(directory,'result.json');
 if(/^(?:pc-|preflight-)/.test(name))assert.ok(fs.existsSync(result),'attempt lacks terminal result: '+name);
 if(fs.existsSync(result)){
  const r=read(result);assert.ok(Number.isFinite(Date.parse(r.finishedAt)),'attempt/suite must be terminal: '+name);
  assert.ok(Date.parse(r.finishedAt)>=Date.parse(r.startedAt),'ordered terminal timestamps: '+name);
  const captures=r.skillCaptures||[],movie=captures.filter(c=>c.spe?.active&&c.spe.id===36&&c.spe.skillId===12),
   numeric=captures.filter(c=>c.result?.active&&c.result.speId===36&&c.result.skillId===12&&c.result.phase==='numbers'),
   hold=captures.filter(c=>c.result?.active&&c.result.speId===36&&c.result.skillId===12&&c.result.phase==='hold');
  for(const c of [movie[0],movie.at(-1),numeric[0],hold.at(-1)].filter(Boolean))for(const key of ['nativeFile','hdFile']){
   const saved=c[key];if(!saved)continue;const absolute=contained(directory,saved.file),raw=fs.readFileSync(absolute);
   assert.equal(raw.length,saved.bytes,'selected PNG size');assert.equal(sha(raw),saved.sha256,'selected PNG hash');
   files.add(path.relative(process.cwd(),absolute));
  }
  for(const png of fs.readdirSync(directory).filter(n=>/\.png$/i.test(n)&&/(?:failure|retired)/i.test(n)))files.add(path.join(directory,png));
 }
 const frozen=path.join(directory,'frozen-sources');if(fs.existsSync(frozen))addFrozen(frozen);
}
fs.mkdirSync(target,{recursive:true});const entries=[];
for(const source of [...new Set([...files].map(normalize))].sort()){
 const raw=fs.readFileSync(source),hash=sha(raw),name=hash+path.extname(source)+'.gz',destination=path.join(target,name);
 if(!fs.existsSync(destination))fs.writeFileSync(destination,zlib.gzipSync(raw,{level:9}),{flag:'wx'});
 const compressed=fs.readFileSync(destination),restored=zlib.gunzipSync(compressed);
 assert.equal(restored.length,raw.length,source);assert.equal(sha(restored),hash,source);
 entries.push({source,file:stem+'/'+name,rawBytes:raw.length,rawSha256:hash,bytes:compressed.length,sha256:sha(compressed)});
}
const record={schemaVersion:1,createdAt:new Date().toISOString(),scope:'Original WATER12 runtime evidence, all terminal attempts/preflight/failures, full JSON/JSONL/NDJSON/log and executed tools, immutable frozen sources and root isolation/suite proofs. Selected first/last captured movie, NUM/HOLD and failure/retired PNGs only. Source checkpoint preserved byte-exact; other raw screenshots and private profiles remain local. No claim of every physical frame or colored HD-window pixel equivalence.',entries};
fs.writeFileSync(indexPath,JSON.stringify(record,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({index:indexPath,files:entries.length,unique:new Set(entries.map(e=>e.file)).size,rawBytes:entries.reduce((n,e)=>n+e.rawBytes,0),bytes:entries.reduce((n,e)=>n+e.bytes,0)}));
