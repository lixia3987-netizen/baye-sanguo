import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const base='build/water-window-runtime-20261011',read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const commands=[
 {name:'preflight-v1',flags:['--recruit','--preflight-only'],exitCode:0},
 {name:'pc-1080-v1',flags:['--recruit'],exitCode:1},
 {name:'preflight-v2',flags:['--recruit','--preflight-only'],exitCode:0},
 {name:'pc-1080-v2',flags:['--recruit'],exitCode:0},
 {name:'pc-720-v1',flags:['--recruit','--720'],exitCode:0},
 {name:'pc-missing-v1',flags:['--recruit','--missing-assets'],exitCode:0},
 {name:'pc-classic-v1',flags:['--recruit','--classic'],exitCode:0}
].map(c=>{
 const file=base+'/'+c.name+'/result.json',raw=fs.readFileSync(file),r=read(file);
 assert.ok(r.finishedAt);assert.equal(r.ok,c.exitCode===0);assert.equal(r.sourceVerification.ok,true);
 return {...c,command:['node','scripts/test-hd-water-runtime.mjs',...c.flags,'--artifact-dir',base+'/'+c.name],startedAt:r.startedAt,finishedAt:r.finishedAt,result:{file,bytes:raw.length,sha256:sha(raw)},actualCastAccepted:r.actualCastAccepted,hdAccepted:r.hdAccepted,fallbackAccepted:r.fallbackAccepted};
});
const suite=read(base+'/final-suite/result.json');assert.equal(suite.exitCode,0);assert.equal(suite.counts.pass,4404);
const cleanup=read(base+'/cleanup-verification.json');assert.equal(cleanup.ok,true);assert.equal(cleanup.attemptCount,7);assert.equal(cleanup.recordedCount,72);
const proof={schemaVersion:1,recordedAt:new Date().toISOString(),recordType:'root tool terminal receipts and saved evidence provenance',
 boundary:'Exit codes are from the root exec/write_stdin terminal results. This is a receipt, not a substitute for the per-run raw result, observer or source evidence. No new game execution is performed by this script.',
 commands,allRuntimeHandlesTerminal:true,finalDefaultSuite:{exitCode:0,modules:suite.modules,counts:suite.counts,sourceCount:suite.sources.length,sourceDrift:suite.sourceDrift},
 externalCleanup:{file:base+'/cleanup-verification.json',sampledAt:cleanup.sampledAt,attemptCount:cleanup.attemptCount,recordedCount:cleanup.recordedCount,ok:true,userUnchanged:true},
 historicalSupportFailure:{validAcceptance:false,script:base+'/verify-cleanup-before-utf8-fix.ps1',output:base+'/cleanup-verification-after-v1.json',reason:'An explicit legacy powershell.exe invocation read UTF8 without an encoding and ConvertFrom-Json raised nonterminating errors. The superficially ok output parsed only preflight (one attempt, zero identities) and was not used as cleanup acceptance. Full legacy shell stderr was not separately saved; the invalid JSON and executed helper remain.',correction:'Explicit UTF8 read plus ErrorActionPreference Stop; use the current root PowerShell. The subsequent final proof includes all seven attempt records and 72 historical identities.'},
 visualReview:{method:'root view_image of saved, SHA-pinned exports',files:[
 'pc-1080-v2/water-000-movie-hd.png','pc-1080-v2/water-023-hold-hd.png','pc-missing-v1/water-022-hold-hd.png','pc-classic-v1/water-023-hold-hd.png'
 ].map(relative=>{const p=base+'/'+relative,b=fs.readFileSync(p);return {file:p,bytes:b.length,sha256:sha(b)};}),notes:'HD movie and400 numeric readback checked. Fallback exports retain alpha; black-background preview hides original black ink. Frozen CSS supplies a light canvas background. This does not establish a held full-page composite screenshot or computed style, which were not captured.'},
 nextScope:'WATER12 four desktop scenarios accepted. FIRE classic, WOOD actual level preparation and other skills, mobile/device, performance and full campaign remain outside this batch.'};
fs.writeFileSync(base+'/root-terminal-and-visual-receipts-v1.json',JSON.stringify(proof,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({attempts:commands.length,acceptedActual:commands.filter(c=>c.actualCastAccepted).length,tests:suite.counts.pass,identities:cleanup.recordedCount}));
