$batchRoot = (Resolve-Path -LiteralPath 'build/water-window-runtime-20261011').Path
$attempts = @(Get-ChildItem -LiteralPath $batchRoot -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'result.json') } | ForEach-Object {
    Get-Content -LiteralPath (Join-Path $_.FullName 'result.json') -Raw | ConvertFrom-Json
} | Where-Object { $_.PSObject.Properties.Name -contains 'historicalRecordedIdentities' })
$recorded = @($attempts | ForEach-Object historicalRecordedIdentities | Where-Object { $_ } | ForEach-Object {
    $recordBirth=$_.CreationDate
    $canonicalBirth=if($recordBirth -is [DateTime]){$recordBirth.ToUniversalTime().ToString('o')}else{[DateTime]::Parse($recordBirth,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind).ToUniversalTime().ToString('o')}
    [pscustomobject]@{ ProcessId=$_.ProcessId; CreationDate=$canonicalBirth; ExecutablePath=$_.ExecutablePath }
} | Sort-Object ProcessId,CreationDate -Unique)
$current = @(Get-CimInstance Win32_Process | ForEach-Object { [pscustomobject]@{
    ProcessId=$_.ProcessId; CreationDate=$_.CreationDate.ToUniversalTime().ToString('o'); ExecutablePath=$_.ExecutablePath
}})
$survivors = @($recorded | Where-Object {
    $old=$_; @($current | Where-Object { $_.ProcessId -eq $old.ProcessId -and $_.CreationDate -eq $old.CreationDate }).Count -gt 0
})
$ports = @($attempts | ForEach-Object { $_.httpPort; $_.debugPort; $_.isolation.httpPort; $_.isolation.debugPort } | Where-Object { $_ } | Sort-Object -Unique)
$listeners = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $_.LocalPort -in $ports } | Select-Object LocalPort,OwningProcess)
$userService = @($current | Where-Object ProcessId -eq 57860)[0]
$response = Invoke-WebRequest -Uri 'http://localhost:8080/' -UseBasicParsing -TimeoutSec 10
$userListener = @(Get-NetTCPConnection -State Listen -LocalPort 8080 -ErrorAction SilentlyContinue | ForEach-Object OwningProcess)
$userUnchanged = $userService.CreationDate -eq '2026-10-10T11:26:04.2797180Z' -and $userService.ExecutablePath -eq 'C:\Program Files\nodejs\node.exe' -and $userListener.Count -eq 1 -and $userListener[0] -eq 57860 -and $response.StatusCode -eq 200
$result = [pscustomobject]@{ sampledAt=[DateTime]::UtcNow.ToString('o'); attemptCount=$attempts.Count; recordedCount=$recorded.Count; survivors=$survivors; privatePorts=$ports; privateListeners=$listeners; userService=$userService; userHttpStatus=$response.StatusCode; userUnchanged=$userUnchanged; ok=($survivors.Count -eq 0 -and $listeners.Count -eq 0 -and $userUnchanged) }
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $batchRoot 'cleanup-verification.json') -Encoding utf8
$result | Select-Object sampledAt,attemptCount,recordedCount,ok,userUnchanged | ConvertTo-Json -Compress
if(-not $result.ok){exit 1}

