import fs from 'node:fs';
const base='build/water-window-runtime-20261011';
for(const name of fs.readdirSync(base)){
 const file=base+'/'+name+'/result.json';if(!fs.existsSync(file))continue;
 const r=JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));
 const {verified,...oracle}=r.nativePixelOracle||{};
 const captures=r.skillCaptures||[],movie=captures.filter(c=>c.spe?.active&&c.spe.id===36&&c.spe.skillId===12),num=captures.filter(c=>c.result?.active&&c.result.skillId===12&&c.result.phase==='numbers'),hold=captures.filter(c=>c.result?.active&&c.result.skillId===12&&c.result.phase==='hold');
 const sample=c=>c&&({index:captures.indexOf(c),stage:c.stage,frame:c.spe?.display?.frameIndex,phase:c.result?.phase,nativeFile:c.nativeFile,hdFile:c.hdFile});
 console.log(JSON.stringify({name,ok:r.ok,accepted:r.accepted,preflight:r.preflightOnly,error:r.error?.split('\n')[0],viewport:r.viewport,actualCastAccepted:r.actualCastAccepted,hdAccepted:r.hdAccepted,fallbackAccepted:r.fallbackAccepted,actualDamage:r.actualDamage,oracle,verified:verified?.length,phases:r.phases?.length,attempts:r.waterAttempts?.map(a=>({actor:a.actor.name,actorId:a.actor.id,target:a.target.name,targetId:a.target.id,bout:a.before.fight.bout,mpBefore:a.actor.mp,mpAfter:a.after.units.find(u=>u.id===a.actor.id)?.mp,armsBefore:a.target.arms,armsAfter:a.after.units.find(u=>u.id===a.target.id)?.arms,succeeded:a.succeeded,event:a.movieEvents})),sourceOk:r.sourceVerification?.ok,sources:r.sourceVerification?.count,cleanup:r.cleanup?.treeExited,profileRetained:r.profileRetained,samples:[movie[0],movie.at(-1),num[0],hold.at(-1)].filter(Boolean).map(sample)}));
}
