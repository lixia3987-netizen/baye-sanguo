import fs from 'node:fs';import assert from 'node:assert/strict';
const p='build/r16-fix-qimen-search-picker.mjs',s=fs.readFileSync(p,'utf8'),marker='const helpers=String.raw`',start=s.indexOf(marker),end=s.indexOf('\n`;\nreplace(',start);
assert.ok(start>=0&&end>start);
const body=s.slice(start+marker.length,end).replaceAll('\\`','`').replaceAll('\\${','${');
fs.writeFileSync('build/r16-qimen-native-picker-fragment.mjs',body.replace(/^\n/,'')+'\n');
fs.writeFileSync(p,s.slice(0,start)+"const helpers=fs.readFileSync('build/r16-qimen-native-picker-fragment.mjs','utf8');"+s.slice(end+3));
