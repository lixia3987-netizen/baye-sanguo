import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import path from 'node:path';
const dir='build/r16-qimen-hd-installed-v6',sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const file=p=>{const b=fs.readFileSync(p);return{path:p,bytes:b.length,sha256:sha(b)};};
const r=JSON.parse(fs.readFileSync(dir+'/result.json')),v=JSON.parse(fs.readFileSync(dir+'/source-verification.json'));
const person=(w,id)=>w.observed.find(p=>p.personIndex===id),epoch=d=>d.year*12+d.month;
assert.equal(r.ok,true);assert.equal(r.hdAccepted,true);assert.equal(r.isolation.cleaned,true);
assert.equal(v.ok,true);assert.equal(v.count,1149);assert.equal(v.runnerMatch,true);assert.deepEqual(v.drift,[]);assert.deepEqual(v.added,[]);
assert.equal(r.exceptions.length,0);assert.equal(r.dialogs.length,0);assert.equal(r.observerErrors.length,0);
assert.equal(r.actualLib.sha256,'3bd20146084054163d045c90987c756a6a210664e78253cc56bc4a274727903e');
assert.equal(r.actualLib.sha256,r.sources['libs/dat-mod.lib'].sha256);
assert.deepEqual(r.actualLibObservations.map(x=>x.stage),['startup','strategy-map','post-search-actual-standard-LIB']);
for(const m of Object.values(r.sources)){const b=fs.readFileSync(m.source);assert.equal(b.length,m.bytes,'source bytes '+m.source);assert.equal(sha(b),m.sha256,'source SHA '+m.source);}
const backup=file('build/r16-qimen-runtime-executed-v6-1530b29d.mjs');
assert.equal(backup.sha256,r.tool.sha256);assert.equal(backup.bytes,124471);
assert.equal(r.searchOrderRecords.length,80);assert.equal(r.searchMonthRecords.length,10);assert.equal(r.actualAcquisition.month,10);
assert.equal(r.actualAcquisition.caster.belong,13);assert.equal(r.actualAcquisition.caster.devotion,81);
let arrowKeys=0;
const orders=r.searchOrderRecords.map(o=>{
  assert.equal(o.actual.belong,13);assert.ok(o.actual.thew>=8);assert.ok(o.before.queue.includes(o.personIndex));
  assert.equal(o.before.money,o.after.money);assert.equal(o.before.food,o.after.food);assert.equal(o.before.reserve,o.after.reserve);assert.deepEqual(o.before.date,o.after.date);
  assert.equal(person(o.after,o.personIndex).thew,o.actual.thew-8);assert.deepEqual(o.after.queue,o.before.queue.filter(id=>id!==o.personIndex));
  assert.equal(o.selection.mode,'native-lcd');assert.equal(o.selection.owner.active,1);assert.equal(o.selection.owner.context,1);assert.equal(o.selection.owner.kind,3);assert.equal(o.selection.owner.idsValid,true);
  assert.deepEqual(o.selection.confirmationKeys.map(k=>k.code),[0x27]);assert.equal(o.selection.confirmedOwner.menu.ids[o.selection.confirmedOwner.menu.index],o.personIndex);
  for(const m of o.selection.moves){assert.equal(Math.abs(m.afterIndex-m.beforeIndex),1);assert.deepEqual(m.keys.map(k=>k.code),[m.code]);assert.ok([0x22,0x23].includes(m.code));arrowKeys++;}
  const actual=o.after.orders.find(p=>p.OrderId===3&&p.Person===o.personIndex&&p.City===26);assert.ok(actual);assert.equal(actual.TimeCount,0);
  return{month:o.month,number:o.number,personIndex:o.personIndex,name:o.actual.name,thewBefore:o.actual.thew,thewAfter:person(o.after,o.personIndex).thew,order:actual,arrowKeys:o.selection.moves.length,ownerSeq:o.selection.owner.seq};
});
const months=r.searchMonthRecords.map(m=>{
  assert.equal(epoch(m.after.date)-epoch(m.before.date),1);assert.equal(m.orders.length,8);assert.equal(m.functionOwner.active,1);assert.equal(m.functionOwner.context,2);assert.equal(m.functionOwner.names[0],'策略结束');
  assert.equal(m.after.orders.length,0);assert.equal(m.after.cityBelong,13);
  for(const o of m.orders){assert.ok(m.after.queue.includes(o.personIndex));assert.equal(person(m.after,o.personIndex).belong,13);}
  assert.equal(person(m.after,171).belong,m.month===10?13:0);assert.equal(m.owned,m.month===10);
  return{month:m.month,dateBefore:m.before.date,dateAfter:m.after.date,searchPeople:m.orders.map(o=>o.personIndex),casterBelong:person(m.after,171).belong,moneyAfter:m.after.money,foodAfter:m.after.food};
});
assert.equal(r.systemModeChanges.length,10);for(const m of r.systemModeChanges){assert.equal(m.after.pref,'hd');assert.deepEqual(m.keys,[]);assert.deepEqual(m.worldBefore,m.worldAfter);}
for(const p of r.campaignReports){assert.deepEqual(p.keys.map(k=>k.code),[0x27]);}
const rec=r.recruitment,recruitWorld=w=>({money:w.money,reserve:w.reserve,date:w.date,personQueue:w.personQueue,caster:w.persons.find(p=>p.personIndex===171)});
assert.equal(rec.requestedArms,800);assert.equal(rec.before.money,6279);assert.equal(rec.enlisted.money,6199);assert.equal(rec.enlisted.reserve,800);assert.equal(rec.equipped.reserve,100);assert.equal(rec.equipped.persons.find(p=>p.personIndex===171).arms,800);
assert.deepEqual(rec.confirmation.nativeKeys.map(k=>k.code),[0x27]);assert.deepEqual(rec.distributionConfirmation.nativeKeys.map(k=>k.code),[0x27]);assert.deepEqual(rec.before.date,rec.equipped.date);
assert.deepEqual(r.marchPersonIds,[171,115]);assert.equal(r.marchOrderReceipt.ok,1);assert.equal(r.marchOrderReceipt.city,26);assert.equal(r.marchOrderReceipt.obj,20);assert.equal(r.marchOrderReceipt.selected,2);
assert.equal(r.qimenAttempts.length,1);const a=r.qimenAttempts[0];assert.equal(a.succeeded,true);assert.equal(a.actor.id,172);assert.equal(a.actor.personIndex,171);assert.equal(a.target.id,116);assert.equal(a.target.personIndex,115);
assert.equal(a.skill.id,20);assert.equal(a.skill.speId,39);assert.equal(a.skill.state,4);assert.equal(a.skill.power,0);assert.equal(a.skill.destroy,0);assert.equal(a.skill.useMp,20);
assert.equal(a.proof.casterId,172);assert.equal(a.proof.targetId,116);assert.equal(a.proof.casterMp,82);assert.equal(a.proof.casterActive,0);assert.equal(a.proof.casterState,0);assert.equal(a.proof.casterTerrain,1);assert.equal(a.proof.terrain,1);
const px=(a.proof.x-a.proof.originX)&255,py=(a.proof.y-a.proof.originY)&255;assert.ok(px<a.proof.size&&py<a.proof.size);assert.equal(a.proof.values[py*a.proof.size+px],1);
assert.equal(a.before.fight.cityIndex,20);assert.equal(a.confirmation.ok,true);assert.equal(a.confirmation.kind,5);
const beforeCaster=a.before.units.find(u=>u.id===172),afterCaster=a.after.units.find(u=>u.id===172),beforeTarget=a.before.units.find(u=>u.id===116),afterTarget=a.after.units.find(u=>u.id===116);
assert.equal(beforeCaster.mp-afterCaster.mp,20);assert.equal(afterCaster.mp,62);assert.equal(beforeTarget.state,0);assert.equal(afterTarget.state,4);assert.equal(afterTarget.arms,beforeTarget.arms);assert.equal(afterTarget.move,beforeTarget.move);
assert.deepEqual(a.before.food,a.after.food);assert.equal(a.reports.length,1);assert.equal(a.reports[0].body,'刘琦 陷入了 奇门 状态');assert.equal(a.reports[0].spe.active,0);assert.equal(a.reports[0].result.active,false);
assert.equal(r.skillCaptures.length,11);const movies=r.skillCaptures.filter(c=>c.spe.active&&c.spe.id===39),retired=r.skillCaptures.filter(c=>!c.spe.active);
assert.equal(movies.length,8);assert.equal(retired.length,3);assert.equal(r.nativePixelOracle.actualLcdCallbacks,8);assert.equal(r.nativePixelOracle.hdReadbacks,8);assert.equal(r.nativePixelOracle.events,1);
const movieEvidence=movies.map((c,i)=>{
  assert.equal(c.rawSource,'lcd-callback-image-data');assert.equal(c.spe.display.frameIndex,i);assert.equal(c.spe.display.commitSeq,i+1);assert.equal(c.spe.keyflag,0);assert.equal(c.spe.skipEligible,false);assert.equal(c.ui.source,'hd-assets');
  assert.deepEqual(c.callbackBefore,c.callbackAfter);assert.deepEqual(c.before,c.after);
  const bits=[];for(let n=0;n<256;n++)if(c.spe.display.visibleFrames[n>>3]&(1<<(n&7)))bits.push(n);assert.deepEqual(c.ui.displayedFrames,bits);
  const oracle=r.nativePixelOracle.verified.find(o=>o.eventId===c.spe.display.eventId&&o.commitSeq===c.spe.display.commitSeq);assert.ok(oracle);const actualRgba=Buffer.from(c.nativeRgba,'base64');assert.equal(actualRgba.length,160*96*4);assert.equal(sha(actualRgba),oracle.nativeRgbaSha256);assert.equal(oracle.nativeRgbaSha256,oracle.independentExpectedSha256);
  const native=file(dir+'/'+c.nativeFile.file),hd=file(dir+'/'+c.hdFile.file);assert.equal(native.sha256,c.nativeFile.sha256);assert.equal(native.bytes,c.nativeFile.bytes);assert.equal(hd.sha256,c.hdFile.sha256);assert.equal(hd.bytes,c.hdFile.bytes);
  return{frame:i,commit:i+1,generation:c.spe.display.generation,eventId:c.spe.display.eventId,visibleFrames:bits,source:c.ui.source,native,hd,nativeRgbaSha256:sha(actualRgba),runnerIndependentExpectedSha256:oracle.independentExpectedSha256};
});
for(const c of r.skillCaptures){assert.ok(!['numbers','hold'].includes(c.result?.phase),'State-only skill does not enter NUM/hold');}
for(const c of retired){assert.equal(c.ui.source,'lcd');assert.deepEqual(c.callbackBefore,c.callbackAfter);assert.deepEqual(c.before,c.after);const p=file(dir+'/'+c.nativeFile.file);assert.equal(p.sha256,c.nativeFile.sha256);}
const movieInputKeys=r.engineInputs.filter(k=>k.at>=movies[0].at&&k.at<=movies.at(-1).at);assert.deepEqual(movieInputKeys,[]);
const end=r.phases.at(-1);assert.equal(end.name,'qimen20-native-owner-retired-no-number-wait');assert.equal(end.spe.active,0);assert.equal(end.menu.active,0);assert.equal(end.dialog.open,false);
const pngs=fs.readdirSync(dir).filter(p=>p.endsWith('.png')).map(p=>file(dir+'/'+p));
const output={version:6,createdAt:new Date().toISOString(),status:'PASS-actual-search-owned-recruit-dispatch-QIMEN20-FENG39',runner:{...backup,backupTiming:'Post-run byte-exact executed source backup; runtime runnerMatch:true'},
  rawFiles:['result.json','source-verification.json','engine-inputs.json','browser-console.json','spe-observations.json','native-skill-captures.json','observer-errors.json'].map(n=>file(dir+'/'+n)),console:file('build/r16-qimen-hd-installed-v6-console.log'),
  counts:{checkpoints:r.phases.length,uiInputs:r.inputs.length,nativePushKeys:r.engineInputs.length,searchOrders:orders.length,searchArrowACKPairs:arrowKeys,executedMonths:months.length,campaignReports:r.campaignReports.length,systemModeClicks:r.systemModeChanges.length,modeChangeNativeKeys:0,attempts:1,allSkillCaptureCallbacks:11,activeFeng39Callbacks:8,hdMovieReadbacks:8,retiredLcdCallbacks:3,nativeInputDuringMovie:0,sourceRecords:v.count,physicalSources:new Set(Object.values(r.sources).map(m=>path.resolve(m.source).toLowerCase())).size,originalPngs:pngs.length,exceptions:0,dialogs:0,observerErrors:0},
  actualSearchOrders:orders,actualMonths:months,actualAcquisition:{month:r.actualAcquisition.month,caster:r.actualAcquisition.caster},actualRecruitment:{requestedArms:800,before:recruitWorld(rec.before),enlisted:recruitWorld(rec.enlisted),equipped:recruitWorld(rec.equipped),quantity:rec.quantity.atConfirmation,distributionQty:rec.distribution.atConfirmation},actualDispatch:{people:r.marchPersonIds,receipt:r.marchOrderReceipt},
  actualCast:{actor:a.actor,target:a.target,skill:a.skill,selectedAim:{generation:a.proof.generation,size:a.proof.size,originX:a.proof.originX,originY:a.proof.originY,x:a.proof.x,y:a.proof.y,raw:1,weather:a.proof.weather,casterTerrain:1,targetTerrain:1},confirmation:a.confirmation,casterMP:{before:beforeCaster.mp,after:afterCaster.mp},targetState:{before:beforeTarget.state,after:afterTarget.state},targetArms:{before:beforeTarget.arms,after:afterTarget.arms},targetMove:{before:beforeTarget.move,after:afterTarget.move},report:a.reports[0].body,reportOwner:a.reports[0].owner,afterReportSpeActive:0,afterReportResultActive:false,noDamageProvNumericHold:true},
  movieEvidence,retiredEvidence:retired.map(c=>({source:c.ui.source,native:file(dir+'/'+c.nativeFile.file),nativeOwnerInactive:true})),
  sourceVerification:{ok:v.ok,count:v.count,runnerMatch:v.runnerMatch,drift:v.drift,added:v.added,currentSourceFilesIndependentlyMatched:true,actualLibrary:r.actualLib,native128Count:r.nativeSourceCheck.count,native128Aggregate:r.nativeSourceCheck.aggregate},
  isolation:r.isolation,cleanupIndependentlyObserved:{privatePorts:[6365,6366],privateListeners:0,chrome176884:false,node176868:false,profileExists:false,user8080PID:105848,user8080HTTP:200},
  visualReview:{method:'view_image original saved PNGs without edits',files:['qimen-000-movie-hd.png','qimen-001-movie-hd.png','qimen-000-movie-lcd.png','qimen-007-movie-lcd.png','actual-report-1.png','qimen20-real-state4-report.png','qimen20-native-owner-retired-no-number-wait.png'].map(p=>file(dir+'/'+p)),observations:['Both HD poses have intact headwear, hands and foot boundaries; the second pose has extended hands matching the intended frame change','Native saved images are actual160x96 LCD callback pixels, independently distinct from HD canvas outputs','The full actual-report-1 screenshot visibly reads 刘琦 陷入了 奇门 状态 with an accessible confirmation button','The state/report checkpoints after acknowledgement show the actual battle board; their filenames alone are not proof that a dialog was still open','The effect and report are retired at the final battle checkpoint; no damage-number wait/hold is used for this state-only skill'],quality:'No new material clipping, occlusion or text-readability issue observed in these selected original images'},
  pngInventory:pngs,scope:{accepted:'One real1920x1080 standard-LIB fresh game, genuine SEARCH acquisition and paid bounded recruitment, actual two-person26→20 campaign, one friendly20 cast/state4/original report, eight native+HD FENG39 callbacks and retirement.',notRun:['No720p run in this acceptance','No new unknown/Mod FENG runtime','No mobile-device or performance acceptance','No save import/reuse or synthetic acquisition'],priorFailures:'All v1..v5 originals and separate executed-source tuples remain preserved. No failed run is represented as a cast/HD pass.'},productionEdited:false,automaticRetry:false};
fs.writeFileSync(dir+'/runtime-validation-audit.json',JSON.stringify(output,null,2)+'\n');console.log(JSON.stringify({audit:file(dir+'/runtime-validation-audit.json'),runner:backup,counts:output.counts,cast:{mp:output.actualCast.casterMP,state:output.actualCast.targetState,report:output.actualCast.report}}));
