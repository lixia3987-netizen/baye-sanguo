import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';

const dir='build/r16-qimen-hd-installed-v3';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const file=p=>{const b=fs.readFileSync(p);return{path:p,bytes:b.length,sha256:sha(b)};};
const r=JSON.parse(fs.readFileSync(dir+'/result.json'));
const v=JSON.parse(fs.readFileSync(dir+'/source-verification.json'));
const person=(w,id)=>w.observed.find(p=>p.personIndex===id);
const epoch=d=>d.year*12+d.month;
assert.equal(r.ok,false);
assert.match(r.error,/Natural SEARCH budget ended before actual XuShu acquisition/);
assert.equal(r.isolation.cleaned,true);
assert.equal(v.ok,true);assert.equal(v.count,1149);assert.equal(v.runnerMatch,true);
assert.deepEqual(v.drift,[]);assert.deepEqual(v.added,[]);
assert.equal(r.searchOrderRecords.length,96);assert.equal(r.searchMonthRecords.length,12);
assert.equal(r.systemModeChanges.length,12);assert.equal(r.skillCaptures.length,0);
assert.equal(r.hdAccepted,false);
assert.equal(r.speObservations.filter(o=>o.spe?.active&&o.spe.id===39).length,0);
assert.equal(r.exceptions.length,0);assert.equal(r.dialogs.length,0);assert.equal(r.observerErrors.length,0);
assert.equal(r.actualLib.sha256,r.sources['libs/dat-mod.lib'].sha256);
assert.equal(r.actualLib.sha256,'3bd20146084054163d045c90987c756a6a210664e78253cc56bc4a274727903e');
for(const m of Object.values(r.sources)) {
  const b=fs.readFileSync(m.source);
  assert.equal(b.length,m.bytes,'source bytes '+m.source);
  assert.equal(sha(b),m.sha256,'source hash '+m.source);
}
const backup=file('build/r16-qimen-runtime-executed-v3-fb6eef14.mjs');
assert.equal(backup.sha256,r.tool.sha256);
assert.equal(backup.bytes,124067);
let arrowKeys=0;
const orders=r.searchOrderRecords.map(o=>{
  assert.equal(o.actual.belong,13);assert.ok(o.actual.thew>=8);
  assert.ok(o.before.queue.includes(o.personIndex));
  assert.equal(o.before.money,o.after.money);
  assert.equal(o.before.food,o.after.food);assert.equal(o.before.reserve,o.after.reserve);
  assert.deepEqual(o.before.date,o.after.date);
  assert.equal(person(o.after,o.personIndex).thew,o.actual.thew-8);
  assert.deepEqual(o.after.queue,o.before.queue.filter(id=>id!==o.personIndex));
  assert.equal(o.selection.mode,'native-lcd');
  assert.equal(o.selection.owner.active,1);assert.equal(o.selection.owner.context,1);assert.equal(o.selection.owner.kind,3);
  assert.equal(o.selection.owner.idsValid,true);
  assert.deepEqual(o.selection.confirmationKeys.map(k=>k.code),[0x27]);
  assert.equal(o.selection.confirmedOwner.menu.ids[o.selection.confirmedOwner.menu.index],o.personIndex);
  for(const move of o.selection.moves){
    assert.equal(Math.abs(move.afterIndex-move.beforeIndex),1);
    assert.deepEqual(move.keys.map(k=>k.code),[move.code]);
    assert.ok([0x22,0x23].includes(move.code));arrowKeys++;
  }
  const actual=o.after.orders.find(p=>p.OrderId===3&&p.Person===o.personIndex&&p.City===26);
  assert.ok(actual);assert.equal(actual.TimeCount,0);
  return{month:o.month,number:o.number,personIndex:o.personIndex,nativeId:o.nativeId,name:o.actual.name,IQ:o.actual.iq,thewBefore:o.actual.thew,thewAfter:person(o.after,o.personIndex).thew,order:actual,arrowKeys:o.selection.moves.length,ownerSeq:o.selection.owner.seq};
});
const months=r.searchMonthRecords.map(m=>{
  assert.equal(epoch(m.after.date)-epoch(m.before.date),1);
  assert.equal(m.orders.length,8);
  assert.equal(m.functionOwner.active,1);assert.equal(m.functionOwner.context,2);assert.equal(m.functionOwner.kind,1);
  assert.equal(m.functionOwner.names[0],'策略结束');
  assert.equal(m.after.orders.length,0);assert.equal(m.after.cityBelong,13);
  for(const o of m.orders){assert.ok(m.after.queue.includes(o.personIndex));assert.equal(person(m.after,o.personIndex).belong,13);}
  assert.equal(person(m.after,171).belong,0);assert.equal(m.owned,false);
  return{month:m.month,dateBefore:m.before.date,dateAfter:m.after.date,searchPeople:m.orders.map(o=>o.personIndex),actualXuShuBelong:person(m.after,171).belong,moneyAfter:m.after.money,foodAfter:m.after.food,orderCountAfter:m.after.orders.length};
});
for(const m of r.systemModeChanges){assert.equal(m.after.pref,'hd');assert.deepEqual(m.keys,[]);assert.deepEqual(m.worldBefore,m.worldAfter);}
for(const p of r.campaignReports){assert.deepEqual(p.keys.map(k=>k.code),[0x27]);}
const world=r.campaignObservations.at(-1).world;
const initial=r.searchBudget.initial;
const acquired=world.observed.filter(p=>p.belong===13&&person(initial,p.personIndex)?.belong===0).map(p=>({personIndex:p.personIndex,name:p.name,belong:p.belong}));
assert.equal(person(world,171).belong,0);
const pngs=fs.readdirSync(dir).filter(p=>p.endsWith('.png')).map(p=>file(dir+'/'+p));
const output={version:3,createdAt:new Date().toISOString(),status:'FAIL-preserved-natural-SEARCH-acquisition-budget',runner:{...backup,backupTiming:'Post-run byte-exact executed source backup; sourceVerification runnerMatch was true'},
  files:['result.json','source-verification.json','engine-inputs.json','browser-console.json','spe-observations.json','native-skill-captures.json','observer-errors.json','failure.png'].map(n=>file(dir+'/'+n)),console:file('build/r16-qimen-hd-installed-v3-console.log'),
  counts:{checkpoints:r.phases.length,uiInputs:r.inputs.length,nativePushKeys:r.engineInputs.length,searchOrders:orders.length,executedMonths:months.length,searchArrowKeys:arrowKeys,nativeReports:r.campaignReports.length,systemModeClicks:r.systemModeChanges.length,systemModeNativeKeys:0,skillCaptures:0,active39Observations:0,exceptions:0,dialogs:0,observerErrors:0,sources:v.count,originalPngs:pngs.length},
  actualSearchOrders:orders,actualMonths:months,actualAcquiredOtherPeople:acquired,
  lastWorld:{money:world.money,food:world.food,reserve:world.reserve,date:world.date,cityBelong:world.cityBelong,queue:world.queue,orders:world.orders,caster:person(world,171)},actualLibrary:r.actualLib,
  sourceVerification:{ok:v.ok,count:v.count,runnerMatch:v.runnerMatch,drift:v.drift,added:v.added,currentFilesIndependentlyMatched:true,native128Count:r.nativeSourceCheck.count,native128Aggregate:r.nativeSourceCheck.aggregate},isolation:r.isolation,
  cleanupIndependentlyObserved:{privatePorts:[14198,14199],privateListenerCount:0,privateChromePid:164368,privateChromeAlive:false,privateProfileExists:false,user8080PID:105848,user8080HTTP:200},
  visualReview:{method:'view_image original1920x1080',files:[file(dir+'/failure.png'),file(dir+'/search-month-12-original-world.png')],observations:['Both original screenshots show normal strategy map dated199年1月 with 刘表 as lord','HD界面 toolbar is selected; no active search/person/system dialog remains','There is no FENG39 movie, target state report or numeric result']},
  pngInventory:pngs,
  failure:{message:r.error,cause:'All12 original strategy months and96 real SEARCH orders executed. Actual XuShu remained Belong0 in every post-month capture. Discovery reports do not establish acquisition; the driver correctly failed before dispatch/cast.'},
  acceptedBoundary:'Real SEARCH actor LCD input/IDs/owner ACKs, zero-money Thew8 orders, original strategy month execution and natural other-person acquisition are validated. The specified XuShu prerequisite failed naturally.',
  notAccepted:['Owned XuShu acquisition','Two-person dispatch to宛城','Friendly skill20 cast or state4 report','FENG39 HD runtime pixels or noNUM retirement'],productionEdited:false,automaticRetry:false,observerPhaseAnnotation:'Inherited spe observation phase label battle is not proof of a battle; actual native fight remained outside the unstarted campaign.'};
fs.writeFileSync(dir+'/runtime-validation-audit.json',JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({audit:file(dir+'/runtime-validation-audit.json'),runner:backup,counts:output.counts,lastWorld:output.lastWorld,acquired}));
