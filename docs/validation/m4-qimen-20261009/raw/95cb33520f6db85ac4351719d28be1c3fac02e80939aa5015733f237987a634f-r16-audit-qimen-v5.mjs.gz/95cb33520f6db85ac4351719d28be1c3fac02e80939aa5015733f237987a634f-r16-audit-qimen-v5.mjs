import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';

const dir='build/r16-qimen-hd-installed-v5';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const file=p=>{const b=fs.readFileSync(p);return{path:p,bytes:b.length,sha256:sha(b)};};
const r=JSON.parse(fs.readFileSync(dir+'/result.json'));
const v=JSON.parse(fs.readFileSync(dir+'/source-verification.json'));
const person=(w,id)=>w.observed.find(p=>p.personIndex===id);
const epoch=d=>d.year*12+d.month;
assert.equal(r.ok,false);
assert.match(r.error,/undefined !== 115/);
assert.equal(r.isolation.cleaned,true);
assert.equal(v.ok,true);assert.equal(v.count,1149);assert.equal(v.runnerMatch,true);
assert.deepEqual(v.drift,[]);assert.deepEqual(v.added,[]);
assert.equal(r.searchOrderRecords.length,56);assert.equal(r.searchMonthRecords.length,7);
assert.equal(r.systemModeChanges.length,7);assert.equal(r.skillCaptures.length,0);
assert.equal(r.hdAccepted,false);
assert.equal(r.speObservations.filter(o=>o.spe?.active&&o.spe.id===39).length,0);
assert.equal(r.exceptions.length,0);assert.equal(r.dialogs.length,0);assert.equal(r.observerErrors.length,0);
assert.equal(r.actualLib.sha256,r.sources['libs/dat-mod.lib'].sha256);
assert.equal(r.actualLib.sha256,'3bd20146084054163d045c90987c756a6a210664e78253cc56bc4a274727903e');
for(const m of Object.values(r.sources)) {
  const b=fs.readFileSync(m.source);
  assert.equal(b.length,m.bytes,'source bytes '+m.source);
  assert.equal(sha(b),m.sha256,'source hash '+m.source);
}
const backup=file('build/r16-qimen-runtime-executed-v5-3522e81e.mjs');
assert.equal(backup.sha256,r.tool.sha256);
assert.equal(backup.bytes,124058);
let arrowKeys=0;
const orders=r.searchOrderRecords.map(o=>{
  assert.equal(o.actual.belong,13);assert.ok(o.actual.thew>=8);
  assert.ok(o.before.queue.includes(o.personIndex));
  assert.equal(o.before.money,o.after.money);
  assert.equal(o.before.food,o.after.food);assert.equal(o.before.reserve,o.after.reserve);
  assert.deepEqual(o.before.date,o.after.date);
  assert.equal(person(o.after,o.personIndex).thew,o.actual.thew-8);
  assert.deepEqual(o.after.queue,o.before.queue.filter(id=>id!==o.personIndex));
  assert.equal(o.selection.mode,'native-lcd');
  assert.equal(o.selection.owner.active,1);assert.equal(o.selection.owner.context,1);assert.equal(o.selection.owner.kind,3);
  assert.equal(o.selection.owner.idsValid,true);
  assert.deepEqual(o.selection.confirmationKeys.map(k=>k.code),[0x27]);
  assert.equal(o.selection.confirmedOwner.menu.ids[o.selection.confirmedOwner.menu.index],o.personIndex);
  for(const move of o.selection.moves){
    assert.equal(Math.abs(move.afterIndex-move.beforeIndex),1);
    assert.deepEqual(move.keys.map(k=>k.code),[move.code]);
    assert.ok([0x22,0x23].includes(move.code));arrowKeys++;
  }
  const actual=o.after.orders.find(p=>p.OrderId===3&&p.Person===o.personIndex&&p.City===26);
  assert.ok(actual);assert.equal(actual.TimeCount,0);
  return{month:o.month,number:o.number,personIndex:o.personIndex,nativeId:o.nativeId,name:o.actual.name,IQ:o.actual.iq,thewBefore:o.actual.thew,thewAfter:person(o.after,o.personIndex).thew,order:actual,arrowKeys:o.selection.moves.length,ownerSeq:o.selection.owner.seq};
});
const months=r.searchMonthRecords.map(m=>{
  assert.equal(epoch(m.after.date)-epoch(m.before.date),1);
  assert.equal(m.orders.length,8);
  assert.equal(m.functionOwner.active,1);assert.equal(m.functionOwner.context,2);assert.equal(m.functionOwner.kind,1);
  assert.equal(m.functionOwner.names[0],'策略结束');
  assert.equal(m.after.orders.length,0);assert.equal(m.after.cityBelong,13);
  for(const o of m.orders){assert.ok(m.after.queue.includes(o.personIndex));assert.equal(person(m.after,o.personIndex).belong,13);}
  assert.equal(person(m.after,171).belong,m.month===7?13:0);assert.equal(m.owned,m.month===7);
  return{month:m.month,dateBefore:m.before.date,dateAfter:m.after.date,searchPeople:m.orders.map(o=>o.personIndex),actualXuShuBelong:person(m.after,171).belong,moneyAfter:m.after.money,foodAfter:m.after.food,orderCountAfter:m.after.orders.length};
});
for(const m of r.systemModeChanges){assert.equal(m.after.pref,'hd');assert.deepEqual(m.keys,[]);assert.deepEqual(m.worldBefore,m.worldAfter);}
for(const p of r.campaignReports){assert.deepEqual(p.keys.map(k=>k.code),[0x27]);}
const world=r.campaignObservations.at(-1).world;
const initial=r.searchBudget.initial;
const acquired=world.observed.filter(p=>p.belong===13&&person(initial,p.personIndex)?.belong===0).map(p=>({personIndex:p.personIndex,name:p.name,belong:p.belong}));
assert.equal(person(world,171).belong,13);assert.ok(world.queue.includes(171));assert.equal(r.actualAcquisition.month,7);assert.equal(r.actualAcquisition.caster.devotion,84);

const rec=r.recruitment,f=r.failureState;
assert.deepEqual(r.marchPersonIds,[171]);assert.equal(f.march.phase,1);assert.equal(f.march.origin,26);assert.equal(f.march.selected,1);assert.equal(f.march.ok,0);
assert.equal(f.menu.active,1);assert.equal(f.menu.context,1);assert.equal(f.menu.kind,3);assert.equal(f.menu.seq,204);assert.equal(f.menu.idsValid,true);assert.ok(f.menu.ids.includes(115));
assert.equal(f.city.deepMenuOwner,null);assert.deepEqual(f.city.deepItems,[]);assert.equal(f.city.deepLabel,'出征');assert.equal(f.city.sending,false);
assert.equal(rec.before.money,4524);assert.equal(rec.enlisted.money,4444);assert.equal(rec.enlisted.reserve,800);assert.equal(rec.equipped.money,4444);assert.equal(rec.equipped.reserve,100);
assert.equal(rec.equipped.persons.find(p=>p.personIndex===171).arms,800);
assert.deepEqual(rec.confirmation.nativeKeys.map(k=>k.code),[0x27]);assert.deepEqual(rec.distributionConfirmation.nativeKeys.map(k=>k.code),[0x27]);
assert.deepEqual(rec.before.date,rec.equipped.date);
assert.deepEqual(r.actualLibObservations.map(p=>p.stage),['startup','strategy-map','post-search-actual-standard-LIB']);
const recruitWorld=w=>({money:w.money,reserve:w.reserve,date:w.date,personQueue:w.personQueue,caster:w.persons.find(p=>p.personIndex===171)});

const pngs=fs.readdirSync(dir).filter(p=>p.endsWith('.png')).map(p=>file(dir+'/'+p));
const output={version:5,createdAt:new Date().toISOString(),status:'FAIL-preserved-harness-next-march-picker-ACK-race',runner:{...backup,backupTiming:'Post-run byte-exact executed source backup; sourceVerification runnerMatch was true'},
  files:['result.json','source-verification.json','engine-inputs.json','browser-console.json','spe-observations.json','native-skill-captures.json','observer-errors.json','failure.png'].map(n=>file(dir+'/'+n)),console:file('build/r16-qimen-hd-installed-v5-console.log'),
  counts:{checkpoints:r.phases.length,uiInputs:r.inputs.length,nativePushKeys:r.engineInputs.length,searchOrders:orders.length,executedMonths:months.length,searchArrowKeys:arrowKeys,nativeReports:r.campaignReports.length,systemModeClicks:r.systemModeChanges.length,systemModeNativeKeys:0,skillCaptures:0,active39Observations:0,exceptions:0,dialogs:0,observerErrors:0,sources:v.count,originalPngs:pngs.length},
  actualSearchOrders:orders,actualMonths:months,actualAcquiredPeople:acquired,actualAcquisition:{month:r.actualAcquisition.month,caster:r.actualAcquisition.caster,evidence:r.actualAcquisition.evidence},
  actualRecruitment:{requestedArms:rec.requestedArms,before:recruitWorld(rec.before),enlisted:recruitWorld(rec.enlisted),equipped:recruitWorld(rec.equipped),enlistQty:rec.quantity.atConfirmation,distributionQty:rec.distribution.atConfirmation,enlistConfirmationKeys:rec.confirmation.nativeKeys,distributionConfirmationKeys:rec.distributionConfirmation.nativeKeys},failedNextPicker:{nativeMenu:f.menu,city:{open:f.city.open,layer:f.city.layer,deepLabel:f.city.deepLabel,deepKind:f.city.deepKind,deepMenuOwner:f.city.deepMenuOwner,deepItems:f.city.deepItems,sending:f.city.sending},nativeMarch:f.march,confirmedMarchPeople:r.marchPersonIds},lastCampaignWorldBeforeRecruit:{money:world.money,food:world.food,reserve:world.reserve,date:world.date,cityBelong:world.cityBelong,queue:world.queue,orders:world.orders,caster:person(world,171)},actualLibrary:r.actualLib,
  sourceVerification:{ok:v.ok,count:v.count,runnerMatch:v.runnerMatch,drift:v.drift,added:v.added,currentFilesIndependentlyMatched:true,native128Count:r.nativeSourceCheck.count,native128Aggregate:r.nativeSourceCheck.aggregate},isolation:r.isolation,
  cleanupIndependentlyObserved:{privatePorts:[10617,10618],privateListenerCount:0,privateChromePid:174712,privateChromeAlive:false,privateProfileExists:false,user8080PID:105848,user8080HTTP:200},
  visualReview:{method:'view_image original1920x1080',files:[file(dir+'/06b-real-distributed-caster-troops.png'),file(dir+'/07-march-persons.png'),file(dir+'/failure.png')],observations:['The distributed-troops checkpoint shows actual 徐庶 selected in the person picker','First march screenshot shows zero generals selected before the actual selection gesture','Failure screenshot already shows one selected general and the remaining native list with 刘琦; the failure JSON was sampled earlier in the owner ACK gap and had empty deepItems/null deepMenuOwner','There is no FENG39 movie, combat or state report']},
  pngInventory:pngs,
  failure:{message:r.error,cause:'After7 months/56 real SEARCH orders, XuShu was owned. Strict post-search actual LIB verification and real800 recruitment/distribution completed. First XuShu march selection was acknowledged, but the driver read the next deepItems before the new native seq204 menu owner had been reflected in HD rows, producing undefined instead of115. The assertion prevented a wrong second selection.'},
  acceptedBoundary:'Real SEARCH/month/acquisition, post-search actual loaded LIB verification, bounded original800 enlistment/distribution and first XuShu march selection are validated. Second actor selection must wait for the actual new owner/complete rows; no AddFightOrder/cast or HD movie has been validated.',
  notAccepted:['Second LiuQi march selection','Two-person dispatch to宛城','Friendly skill20 cast or state4 report','FENG39 HD runtime pixels or noNUM retirement'],productionEdited:false,automaticRetry:false,observerPhaseAnnotation:'Inherited spe observation phase label battle is not proof of a battle; actual native fight remained outside the unstarted campaign.'};
fs.writeFileSync(dir+'/runtime-validation-audit.json',JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({audit:file(dir+'/runtime-validation-audit.json'),runner:backup,counts:output.counts,lastCampaignWorldBeforeRecruit:output.lastCampaignWorldBeforeRecruit,acquired}));
