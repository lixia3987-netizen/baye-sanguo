import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const basePath='scripts/test-hd-stone-runtime.mjs',out='build/r16-test-hd-qimen-runtime-candidate.mjs';
const bytes=fs.readFileSync(basePath),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
assert.equal(sha(bytes),'f1e11ec58838efbcc257d994a3f544fbaed6a2cda00b28ba9d6aaf0725dd095c');
const backup='build/r16-stone-source-f1e11ec5.mjs';
if(!fs.existsSync(backup))fs.writeFileSync(backup,bytes);else assert.equal(sha(fs.readFileSync(backup)),sha(bytes));
let s=bytes.toString('utf8').replaceAll('\r\n','\n');
const replace=(from,to)=>{assert.ok(s.includes(from),'Required original fragment '+from.slice(0,60));s=s.replaceAll(from,to);};
replace('STONE42','FENG39');replace('Stone42','Feng39');replace('Stone','Qimen');replace('stone','qimen');replace('skill23','skill20');replace('state6','state4');replace('STATE_SZ6','STATE_QM4');
replace('P4 LiuShan, BaJun31 to WuLing32.','P2 LiuBiao, genuine XuShu SEARCH acquisition, XiangYang26 to Wan20.');
replace('build/r13-qimen-runtime','build/r16-qimen-runtime');
replace("const baselineOnly=process.argv.includes('--baseline-only'),allowLcd=process.argv.includes('--allow-lcd'),recruit=process.argv.includes('--recruit');","const preflightOnly=process.argv.includes('--preflight-only'),baselineOnly=process.argv.includes('--baseline-only'),allowLcd=process.argv.includes('--allow-lcd'),recruit=process.argv.includes('--recruit');");
replace("const recruitArms=numberArg('--recruit-arms',800,65535),maxTurns=numberArg('--max-turns',4,20);","const recruitArms=numberArg('--recruit-arms',800,65535),maxTurns=numberArg('--max-turns',4,20),searchMonths=numberArg('--search-months',12,60),searchOrders=numberArg('--search-orders',8,12);");
replace('const period=4,originCity=31,destination=32,casterPerson=72,casterNativeId=73,skillId=23,speId=42,acceptedRange=[42,0,7];','const period=2,originCity=26,destination=20,casterPerson=171,casterNativeId=172,allyPerson=115,skillId=20,speId=39,acceptedRange=[39,0,7];');
replace('const report = { baselineOnly,allowLcd,recruit,recruitArms,period,originCity,destination,casterPerson,skillId,speId,maxTurns, staged,','const report = { preflightOnly,baselineOnly,allowLcd,recruit,recruitArms,searchMonths,searchOrders,period,originCity,destination,casterPerson,allyPerson,skillId,speId,maxTurns, staged,');
for(const from of ['e.speId===42','nativeMovie(42)','id:42','spe.id===42','result.speId===42','skill.speId,42','s.speId===42','[42,2,23','r.spe.id===42','c.spe.id===42'])if(s.includes(from))replace(from,from.replace('42','39'));
replace('fnv1a32:0e6f8d97:1084','fnv1a32:6b0ebc5a:1084');
replace('nativeItem(11,22),special=nativeItem(14,3)','nativeItem(11,19),special=nativeItem(14,1)');
replace('special.readUInt16LE(casterPerson*2),23','special.readUInt16LE(casterPerson*2),20');
replace('actualSkillName:{resourceId:11,itemIndex:22','actualSkillName:{resourceId:11,itemIndex:19');
replace('actualSpecialSkill:{resourceId:14,itemIndex:3,period:4,personIndex:72,elementBytes:2,offset:144,skillId:special.readUInt16LE(144)}','actualSpecialSkill:{resourceId:14,itemIndex:1,period:2,personIndex:171,elementBytes:2,offset:342,skillId:special.readUInt16LE(342)}');
replace('resource11/index22','resource11/index19');
replace("real period4 lord selection', 'Number(baye.data.g_PIdx)===4", "real period2 lord selection', 'Number(baye.data.g_PIdx)===2");
replace("k.id===1&&k.name==='刘禅'", "k.id===12&&k.name==='刘表'");
replace('Actual period4 contains LiuShan ID1','Actual period2 contains LiuBiao person12');
replace('assert.equal(report.selectedLord.id,1)','assert.equal(report.selectedLord.id,12)');
for(const [from,to] of [['巴郡','襄阳'],['武陵','宛城'],['LiuShan','LiuBiao'],['BaJun31','XiangYang26'],['WuLing32','Wan20']])if(s.includes(from))replace(from,to);
replace("c.i===31 && c.name==='襄阳'", "c.i===26 && c.name==='襄阳'");
replace('m.origin===31','m.origin===26');
replace('report.marchOrderReceipt.city,31','report.marchOrderReceipt.city,26');
replace('report.marchOrderReceipt.obj,32','report.marchOrderReceipt.obj,20');
replace('selectMarchTarget(32)','selectMarchTarget(20)');replace('selected.selected,32','selected.selected,20');replace('confirmMarchTarget(32)','confirmMarchTarget(20)');
replace('report.battleDestinationReceipt.cityIndex,32','report.battleDestinationReceipt.cityIndex,20');
replace('report.combatStart.fight.cityIndex,32','report.combatStart.fight.cityIndex,20');
replace('person72/native73','person171/native172');
replace('options.find(s=>s.id===23)','options.find(s=>s.id===20)');
replace('s.id===23&&s.speId===39','s.id===20&&s.speId===39');
replace('r.spe.skillId===23','r.spe.skillId===20');replace('c.spe.skillId===23','c.spe.skillId===20');
replace('[39,2,23','[39,2,20');replace('[s.generation,23,match.actor.i','[s.generation,20,match.actor.i');
replace('assert.equal(skill.state,6)','assert.equal(skill.state,4)');replace('assert.equal(skill.aim,0)','assert.equal(skill.aim,1)');
replace('assert.equal(victim.state,6','assert.equal(victim.state,4');replace('u.state===6','u.state===4');
replace("text('dFgtState0',6)","text('dFgtState0',4)");
// Replace the Stone enemy route with a same-side native skill20/state4 path.
const battleStart=s.indexOf('async function attemptQimen('),battleEnd=s.indexOf('\nfunction movieOracle(',battleStart);
assert.ok(battleStart>=0&&battleEnd>battleStart);
let attemptTemplate=s.slice(battleStart,s.indexOf('async function battleSmoke(cdp)',battleStart));
const changeAttempt=(from,to)=>{assert.ok(attemptTemplate.includes(from),'Original state template '+from.slice(0,60));attemptTemplate=attemptTemplate.replaceAll(from,to);};
changeAttempt('owner.skills.ids[skill.index],23','owner.skills.ids[skill.index],20');
changeAttempt('filter(id=>id===23)','filter(id=>id===20)');
changeAttempt('u.side===\'enemy\'&&u.state!==8&&u.state!==6&&u.arms>0',"u.side==='player'&&u.id===allyPerson+1&&u.state===0&&u.arms>0");
changeAttempt('proof.casterTerrain>=0&&proof.casterTerrain<8','proof.casterTerrain>=0&&proof.casterTerrain<7');
changeAttempt('proof.state!==8&&proof.state!==6','proof.state===0');
const moveAssertion="assert.equal(victim.move,before.units.find(u=>u.id===target.id&&u.i===target.i).move,'STONE6 does not use the STATE_DS3 movement-to1 branch');";
assert.ok(attemptTemplate.includes(moveAssertion));attemptTemplate=attemptTemplate.replace(moveAssertion,'');
attemptTemplate=attemptTemplate.replaceAll('qimen23','qimen20').replaceAll('id23','id20');
changeAttempt('assert.equal(proof.targetId,target.id);','assert.equal(proof.targetId,target.id);assert.equal(target.side,fresh.side);assert.equal(target.id,allyPerson+1);assert.equal(before.units.find(u=>u.id===target.id).belong,fresh.belong);');
const baselineBattle=`async function battleSmoke(cdp){
 report.combatStart=await evaluate(cdp,battleStateExpression);assert.equal(report.combatStart.fight.cityIndex,20);
 const map=await evaluate(cdp,'({id:Number(baye.data.g_FgtParam.MapId),width:Number(baye.data.g_MapWid),height:Number(baye.data.g_MapHgt)})');
 assert.deepEqual(map,{id:111,width:32,height:32});report.actualBattleMap=map;
 const caster=report.combatStart.units.find(u=>u.id===casterNativeId&&u.side==='player'),ally=report.combatStart.units.find(u=>u.id===allyPerson+1&&u.side==='player');
 assert.ok(caster&&caster.arms>0&&![8,1,2,6].includes(caster.state)&&caster.active===0);assert.ok(caster.mp>=20);
 assert.ok(ally&&ally.arms>0&&ally.state===0&&ally.belong===caster.belong);assert.equal(caster.belong,13);
 const selection=await chooseGeneral(cdp,caster);if(selection.inputKind===2){assert.equal((await action(cdp,'baseline-stay-real-caster-tile',\`BayeHdBattle.clickTile(\${caster.x},\${caster.y})\`)).ok,true);await waitBattle(cdp,3,'baseline actual action menu');}
 await menuChoice(cdp,await evaluate(cdp,'baye.hd.menuItems().names[1]'),4);
 const owner=await evaluate(cdp,'({fight:baye.hd.fight(),skills:baye.hd.skills(),generation:Number(baye.data.g_hdSpeGeneration)})'),options=await evaluate(cdp,skillOptionsExpression),skill=options.find(s=>s.id===20);
 assert.ok(skill);assert.equal(owner.skills.active,1);assert.equal(owner.skills.ids[skill.index],20);assert.equal(skill.name,report.qimenNativeResource.actualSkillName.name);
 assert.deepEqual([skill.speId,skill.aim,skill.state,skill.power,skill.destroy,skill.useMp],[39,1,4,0,0,20]);
 assert.equal(owner.fight.active,1);assert.equal(owner.fight.over,0);assert.equal(owner.fight.actorIndex,caster.i);assert.equal(owner.fight.inputKind,4);
 report.baseline={caster,ally,owner,options,skill,weather:report.combatStart.weather,note:'Actual SEARCH acquisition/current owned dispatch and native skill20 menu only. Availability is observed, not presumed. No AIM confirmation, spell, NUM/hold or HD acceptance.'};
 await checkpoint(cdp,'baseline-actual-caster-qimen-menu');await action(cdp,'baseline-cancel-uncommitted-skill','BayeHdBattle.cancel()');
 await waitBattle(cdp,3,'baseline skill menu retired');
 const cancelled=await evaluate(cdp,battleStateExpression);assert.equal(cancelled.units.find(u=>u.id===casterNativeId).mp,caster.mp);
 if(baselineOnly){await menuChoice(cdp,await evaluate(cdp,'baye.hd.menuItems().names[3]'),1);report.combatEnd=await evaluate(cdp,battleStateExpression);const after=report.combatEnd.units.find(u=>u.id===casterNativeId);assert.equal(after.mp,caster.mp);assert.equal(after.arms,caster.arms);report.hdAccepted=false;return;}
 let success=await attemptQimen(cdp,caster);
 if(!success&&await evaluate(cdp,'baye.hd.fight().inputKind===3'))await menuChoice(cdp,await evaluate(cdp,'baye.hd.menuItems().names[3]'),1);
 for(let step=0;step<maxTurns*20&&!success;step++){
  const current=await evaluate(cdp,battleStateExpression),actual=current.units.find(u=>u.id===casterNativeId);
  assert.ok(actual&&actual.arms>0&&actual.state!==8,'Natural caster death remains a failure');assert.ok(!current.fight.over);
  const available=current.units.filter(u=>u.side==='player'&&u.active===0&&u.arms>0&&![8,1,6].includes(u.state)),actor=available.find(u=>u.id===casterNativeId)||available[0];
  if(!actor){if((report.turns?.length||0)>=maxTurns)break;await endArmyTurn(cdp);continue;}
  const selected=await chooseGeneral(cdp,actor);
  if(actor.id!==casterNativeId||actor.state===2){if(actor.state===2){report.skippedCasts??=[];report.skippedCasts.push({actor,reason:'Current STATE_JZ2: rest legally rather than opening SKILL4'});}await restActor(cdp,actor,selected);continue;}
  assert.ok(actor.mp>=20,'Only actual current MP funds another natural cast attempt');
  if(selected.inputKind===2){assert.equal((await action(cdp,'qimen-stay-at-actual-current-caster-tile',\`BayeHdBattle.clickTile(\${actor.x},\${actor.y})\`)).ok,true);await waitBattle(cdp,3,'actual legal stay before spell');}
  success=await attemptQimen(cdp,actor);if(!success&&await evaluate(cdp,'baye.hd.fight().inputKind===3'))await menuChoice(cdp,await evaluate(cdp,'baye.hd.menuItems().names[3]'),1);
 }
 assert.ok(success,'A player-confirmed skill20 same-side state4 success must occur; an enemy event or natural failure does not complete acceptance');
 const evidence=await collectSpe(cdp);assert.deepEqual(evidence.keys.filter(k=>k.resultActive),[],'State-only native movie receives no skip or invented return key');
 report.combatEnd=await evaluate(cdp,battleStateExpression);assert.equal(await evaluate(cdp,'baye.hd.skillResult().active'),false);
 await checkpoint(cdp,'qimen20-native-owner-retired-no-number-wait');
}
`;
s=s.slice(0,battleStart)+attemptTemplate+baselineBattle+s.slice(battleEnd);
replace("selection<6","selection<2");replace("const index=selection===0?before.menu.ids.indexOf(casterPerson):0", "const index=before.menu.ids.indexOf(selection===0?casterPerson:allyPerson)");
replace("assert.equal(report.marchPersonIds[0],casterPerson,'Actual caster entered the native march queue');", "assert.deepEqual(report.marchPersonIds,[casterPerson,allyPerson],'Actual owned XuShu first and real LiuQi second; no static or unowned ID substitution');");
replace("    await checkpoint(cdp,'06-hd-city');\n    await click(cdp,'#hd-city-menu [data-hd-root=\"2\"]');", "    await checkpoint(cdp,'06-hd-city');\n    await retireSearchToMap(cdp,'initial-city-root');\n    await searchForActualCaster(cdp);\n    assert.ok(await action(cdp,'reopen-owned-city-after-real-search',`BayeHdOverworld.walkToCity(${originCity})`));\n    await waitFor(cdp,'actual acquired-caster city root',`BayeHdCityMenu.isOpen()&&BayeHdCityMenu.getLayer()==='root'&&baye.hd.menuItems().active`);\n    await click(cdp,'#hd-city-menu [data-hd-root=\"2\"]');");
replace("Actual P4 LiuBiao/XiangYang26/Wan20 entry and current caster72/skill20 menu only", "Actual P2 LiuBiao/XiangYang26 real XuShu SEARCH acquisition, owned dispatch to Wan20 and current caster171/skill20 menu only");
replace('P4 skill20 success','P2 skill20 success');
replace('state-only skill20 lifecycle/pixels passed','state-only skill20 lifecycle/pixels passed');

const fragment=fs.readFileSync('build/r16-qimen-search-runtime-fragment.mjs','utf8');
replace('async function marchSmoke(cdp) {',fragment+'\nasync function marchSmoke(cdp) {');
// The committed R14 product now retires an already-native-map pane by its normal
// Back button. The driver must observe that public gesture rather than silently
// close presentation through the former preparatory API workaround.
const water=fs.readFileSync('scripts/test-hd-water-runtime.mjs','utf8').replaceAll('\r\n','\n');
const oldReopenStart=s.indexOf('async function reopenMilitaryAfterPersonPicker('),oldReopenEnd=s.indexOf('\nasync function recruitSmoke(',oldReopenStart);
const publicReopenStart=water.indexOf('async function reopenMilitaryAfterPersonPicker('),publicReopenEnd=water.indexOf('\nasync function recruitSmoke(',publicReopenStart);
assert.ok(oldReopenStart>=0&&oldReopenEnd>oldReopenStart&&publicReopenStart>=0&&publicReopenEnd>publicReopenStart);
s=s.slice(0,oldReopenStart)+water.slice(publicReopenStart,publicReopenEnd)+s.slice(oldReopenEnd);
const preflight=`
 const routeBytes=freezeAsset('build/r16-next-skill-plan.json').data,contractBytes=freezeAsset('build/r16-qimen-search-contract.json').data;
 const route=JSON.parse(routeBytes),contract=JSON.parse(contractBytes);assert.equal(sha(contractBytes),'644af0beac307c852d4f8239cc477e006251bdcddb16641493e1ed7e24b5cba3');
 assert.equal(route.library.sha256,report.sources['libs/dat-mod.lib'].sha256);assert.equal(contract.library.sha256,route.library.sha256);
 const p=route.preferred,cities=nativeItem(57,1),people=nativeItem(61,1),queue=nativeItem(65,1),specialSkills=nativeItem(14,1),skill=nativeItem(10).subarray(19*34,20*34);
 assert.equal(cities.readUInt16LE(38*37),198);
 for(const [i,record] of [[26,p.origin.recordHex],[20,p.dispatch.cityRecordHex]].filter(v=>v[1]))assert.equal(cities.subarray(i*37,i*37+37).toString('hex'),record);
 for(const person of [p.lord,p.caster,p.casterPrerequisite.searcher,p.targetAlly])assert.equal(people.subarray(person.personIndex*19,person.personIndex*19+19).toString('hex'),person.recordHex);
 const c=cities.subarray(26*37,27*37),queueOffset=c.readUInt16LE(29),queueCount=c.readUInt16LE(31),actualQueue=Array.from({length:queueCount},(_,i)=>queue.readUInt16LE((queueOffset+i)*2));
 assert.deepEqual(actualQueue,p.origin.rawQueue);assert.ok(actualQueue.includes(171));assert.equal(people.readUInt16LE(171*19+2),0);assert.equal(people.readUInt16LE(115*19+2),13);
 assert.equal(specialSkills.readUInt16LE(342),20);assert.equal(skill.toString('hex'),p.skill.recordHex);assert.deepEqual(Array.from(skill.subarray(0,7)),[1,4,0,0,0,0,20]);
 const range=nativeItem(13).subarray(19*81,20*81);assert.equal(range.length,81);assert.equal(range.filter(v=>v===1).length,24);assert.equal(range[40],2);
 const condition=nativeItem(63,1).subarray(171*4,172*4);assert.equal(condition.toString('hex'),'b400001b');
 const thew=nativeItem(2,9)[3],money=nativeItem(2,10)[3];assert.equal(thew,8);assert.equal(money,0);
 const map=nativeItem(111);assert.equal(map.length,1040);assert.deepEqual([map[0],map[2]],[32,32]);assert.equal(map[16+29*32+16],1);assert.equal(map[16+30*32+16],1);
 const link=nativeItem(59).subarray(26*16,26*16+8);assert.deepEqual(Array.from(link),p.dispatch.originNativeLinks);assert.ok(link.includes(21));
 report.searchNativeCost={commandId:3,resourceId:2,thewItem:9,moneyItem:10,thew,money};
 report.inputPlans={route:{source:'build/r16-next-skill-plan.json',bytes:routeBytes.length,sha256:sha(routeBytes)},searchContract:{source:'build/r16-qimen-search-contract.json',bytes:contractBytes.length,sha256:sha(contractBytes)}};
 report.qimenRouteRomProof={period:2,year:198,lord:p.lord,caster:p.caster,rawQueue:actualQueue,alliedQueue:actualQueue.filter(id=>people.readUInt16LE(id*19+2)===13),special20:true,currentUnowned171:true,searchCondition:condition.toString('hex'),ally:p.targetAlly,dispatch:p.dispatch,mapId:111,width:32,height:32,nativeAim:Array.from(range),notClaimed:'Static ROM facts only. No true ownership, successful search, current MP/skill availability, dispatch, cast or HD acceptance is claimed.'};
`;
replace(" for(const name of ['baye.js','baye.wasm','baye.wasm.map'])",preflight+"\n for(const name of ['baye.js','baye.wasm','baye.wasm.map'])");
replace("        profile=fs.mkdtempSync(path.join(os.tmpdir(),'baye-skill-runtime-'));", "        if(preflightOnly){report.ok=true;report.scope={accepted:'Readonly actual standard-LIB FENG39/skill20/search/route metadata and source preflight',notRun:'No browser, SEARCH, campaign month, owned acquisition, dispatch, skill input or HD acceptance'};return;}\n        profile=fs.mkdtempSync(path.join(os.tmpdir(),'baye-skill-runtime-'));");
replace("if (report.ok) console.log(baselineOnly?'Actual Qimen route/menu baseline passed; no cast/HD claimed'", "if (report.ok) console.log(preflightOnly?'Readonly Qimen search/route preflight passed; no browser/ownership/cast/HD claimed':baselineOnly?'Actual Qimen search/owned/menu baseline passed; no cast/HD claimed'");
if(s.includes('Actual P4'))replace('Actual P4','Actual P2');
if(s.includes('caster72'))replace('caster72','caster171');
s=s.replace(/^#!\/usr\/bin\/env node\n\/\*\*[\s\S]*?\*\//,`#!/usr/bin/env node
/**
 * Ignored FENG39/skill20 preparation: real P2 LiuBiao26, SEARCH acquisition of XuShu171, allied LiuQi115, march26->20.
 * --preflight-only checks frozen actual ROM/source metadata and never starts Chrome.
 * --baseline-only stops after genuine acquisition/dispatch/current skill menu; default mode additionally casts the actual same-side state4 spell.
 * Strict mode accepts only authenticated FENG39 real timer frames, original state report and native scope retirement; no NUM/hold is invented.
 * --search-orders 8 and --search-months 12 are explicit private-game budgets, never new native rules or guaranteed recruitment.
 * Windows: node build/r16-test-hd-qimen-runtime-candidate.mjs --preflight-only --artifact-dir build/r16-qimen-preflight
 * Wait for the root source-freeze authorization before any browser run. No user8080/profile/save is reused.
 */`);
const remaining=s.split('\n').filter(l=>/(刘禅|巴郡|武陵|LiuShan|STONE|Stone|stone|caster72|person72|native73|origin===31|cityIndex,32|speId===42|spe\.id===42|skillId===23)/.test(l));
assert.deepEqual(remaining,[],'No old Stone route/actor/skill acceptance remains');
s=s.split('\n').map(line=>line.replace(/[\t ]+$/,'')).join('\n').replace(/\n*$/,'\n');
fs.writeFileSync(out,s);
console.log(JSON.stringify({path:out,bytes:Buffer.byteLength(s),sha256:sha(Buffer.from(s)),base:{path:basePath,bytes:bytes.length,sha256:sha(bytes)},fragmentSha256:sha(Buffer.from(fragment)),browserRun:false}));
