import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
const input='build/r16-qimen-runtime-executed-v2-8492b3eb.mjs',out='build/r16-test-hd-qimen-runtime-candidate-v3.mjs',sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const raw=fs.readFileSync(input);assert.equal(sha(raw),'8492b3eb31afc75171ab0c15abbcb43de299387977f0eb2b4135a9dbf4cc0295');let source=raw.toString('utf8');
const begin=source.indexOf('async function executeSearchMonth('),end=source.indexOf('\nasync function searchForActualCaster(',begin);assert.ok(begin>=0&&end>begin);
let fragment=source.slice(begin,end),old="    const start=await evaluate(cdp,'window.__speEngineKeys.length');\n    await key(cdp,'Escape');";
assert.ok(fragment.includes(old));
const added=[
"    // The original period/lord flow explicitly used classic System UI. Restore",
"    // HD through the visible player toolbar while the actual native map owns input.",
"    const modeInputStart=await evaluate(cdp,'window.__speEngineKeys.length'),modeBefore=await evaluate(cdp,'BayeHdSystemUi.debugSnapshot()');",
"    await click(cdp,'#baye-hd-toolbar [data-hd-system-ui=\"hd\"]');",
"    await waitFor(cdp,'explicit player HD System UI mode',\"BayeHdSystemUi.debugSnapshot().pref==='hd'\");",
"    const modeAfter=await observeCampaign(cdp,'search-month-'+month+'-after-Hd-interface-button'),modeKeys=await evaluate(cdp,`window.__speEngineKeys.slice(${modeInputStart})`);",
"    assert.deepEqual(modeKeys,[],'Interface mode selection emits no native key');",
"    for(const field of ['queue','observed','orders','money','food','reserve','date'])assert.deepEqual(modeAfter[field],before[field],'Player HD Interface selection cannot change '+field);",
"    assert.ok(!modeAfter.menu.active&&!modeAfter.qty.active&&!modeAfter.report.active&&modeAfter.march.pick===1&&modeAfter.march.phase===0&&modeAfter.march.battlePick===0);",
"    report.systemModeChanges??=[];report.systemModeChanges.push({month,before:modeBefore,after:await evaluate(cdp,'BayeHdSystemUi.debugSnapshot()'),worldBefore:before,worldAfter:modeAfter,keys:modeKeys});"
].join('\n')+'\n';
fragment=fragment.replace(old,added+old);source=source.slice(0,begin)+fragment+source.slice(end);
source=source.split('\n').map(l=>l.replace(/[\t ]+$/,'')).join('\n').replace(/\n*$/,'\n');
assert.equal(sha(Buffer.from(source.replace(added,''))),sha(raw),'Only the explicit UI toolbar mode preparation differs from the actual8492');
fs.writeFileSync(out,source);fs.writeFileSync('build/r16-qimen-system-mode-fragment.txt',added);
console.log(JSON.stringify({candidate:{path:out,bytes:Buffer.byteLength(source),sha256:sha(Buffer.from(source))},base:{path:input,bytes:raw.length,sha256:sha(raw)},browserStarted:false,productionEdited:false}));
