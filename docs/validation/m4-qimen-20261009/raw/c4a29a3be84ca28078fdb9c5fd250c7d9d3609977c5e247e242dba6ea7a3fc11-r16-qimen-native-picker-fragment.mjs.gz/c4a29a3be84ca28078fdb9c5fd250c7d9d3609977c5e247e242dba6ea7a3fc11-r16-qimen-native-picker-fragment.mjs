function searchMenuIdentity(picker) {
    const m=picker.menu;
    return {active:m.active,context:m.context,kind:m.kind,seq:m.seq,generation:m.generation,detailGeneration:m.detailGeneration,idsValid:m.idsValid,ids:m.ids,names:m.names};
}
async function currentSearchPicker(cdp) {
    return waitFor(cdp,'actual SEARCH native owner/IDs and visible input surface',`(() => {
        const s=BayeHdCityMenu.debugSnapshot(),m=baye.hd.menuItems(),d=baye.data,c=d.g_Cities[${originCity}],q=baye.hd.qty(),r=baye.hd.report();
        if(!s.open||s.layer!=='deep'||s.subKind!=='neizheng'||s.deepLabel!=='搜寻'||!m.active||m.context!==1||m.kind!==3||!m.idsValid||!m.ids.length||s.sending||s.queueLen||q.active||r.active)return false;
        if(m.generation!==Number(d.g_hdSpeGeneration)||m.detailGeneration!==Number(d.g_hdDetailGeneration)||!Number.isInteger(m.index)||m.index<0||m.index>=m.ids.length)return false;
        const actual=Array.from({length:Number(c.Persons)},(_,i)=>Number(d.g_PersonsQueue[Number(c.PersonQueue)+i])).filter(id=>Number(d.g_Persons[id].Belong)===Number(c.Belong));
        if(JSON.stringify(actual)!==JSON.stringify(m.ids))throw Error('Current SEARCH menu IDs differ from actual allied PersonQueue');
        const owner=s.deepMenuOwner,hd=owner&&owner.context===m.context&&owner.kind===m.kind&&owner.seq===m.seq&&owner.detailGeneration===m.detailGeneration&&m.ids.every((id,index)=>s.deepItems.some(item=>item.i===index&&item.pind===id));
        if(hd)return {mode:'hd',menu:m,city:s,personIds:actual};
        if(s.deepKind!=='lcd')return false;
        const lcd=document.getElementById('lcd');if(!lcd)return false;
        const rect=lcd.getBoundingClientRect(),style=getComputedStyle(lcd),container=getComputedStyle(lcd.parentElement),points=[[.2,.2],[.5,.5],[.8,.8]];
        if(!rect.width||!rect.height||style.visibility!=='visible'||style.display==='none'||container.visibility!=='visible'||container.display==='none'||rect.x<0||rect.y<0||rect.right>innerWidth+.5||rect.bottom>innerHeight+.5)return false;
        if(!points.every(p=>{const stack=document.elementsFromPoint(rect.x+rect.width*p[0],rect.y+rect.height*p[1]);return stack[0]===lcd;}))return false;
        return {mode:'native-lcd',menu:m,city:s,personIds:actual,lcd:{x:rect.x,y:rect.y,width:rect.width,height:rect.height,visible:true,stackOwned:true}};
    })()`);
}
async function selectActualSearchActor(cdp,picker,personIndex,month,number) {
    const identity=searchMenuIdentity(picker),index=picker.menu.ids.indexOf(personIndex);
    assert.ok(index>=0);const record={month,number,personIndex,nativeId:personIndex+1,mode:picker.mode,owner:identity,initialIndex:picker.menu.index,moves:[]};
    report.searchSelections??=[];report.searchSelections.push(record);
    if(picker.mode==='hd') {
        assert.equal(picker.city.deepItems.find(item=>item.i===index)?.pind,personIndex);
        await click(cdp,`#hd-city-menu [data-hd-deep="${index}"][data-hd-deep-pind="${personIndex}"]`);return record;
    }
    assert.equal(picker.mode,'native-lcd');
    let current=await currentSearchPicker(cdp);assert.deepEqual(searchMenuIdentity(current),identity);
    for(let step=0;current.menu.index!==index&&step<identity.ids.length;step++) {
        const before=await observeCampaign(cdp,`search-${month}-${number}-lcd-arrow-before`),old=current.menu.index,next=old+(index>old?1:-1),name=index>old?'ArrowDown':'ArrowUp',code=index>old?0x23:0x22,start=await evaluate(cdp,'window.__speEngineKeys.length');
        await key(cdp,name);
        await waitFor(cdp,'exact current SEARCH native highlight ACK',`(() => {const m=baye.hd.menuItems();return m.active&&m.context===1&&m.kind===3&&m.seq===${identity.seq}&&m.generation===${identity.generation}&&m.detailGeneration===${identity.detailGeneration}&&m.index===${next};})()`);
        current=await currentSearchPicker(cdp);assert.deepEqual(searchMenuIdentity(current),identity);assert.equal(current.menu.index,next);
        const after=await observeCampaign(cdp,`search-${month}-${number}-lcd-arrow-after`),keys=await evaluate(cdp,`window.__speEngineKeys.slice(${start})`);
        assert.deepEqual(keys.map(k=>k.code),[code],'Exactly one physical key belongs to this unchanged native SEARCH owner');
        for(const field of ['queue','observed','orders','money','food','reserve','date'])assert.deepEqual(after[field],before[field],'Native highlight alone cannot change '+field);
        record.moves.push({key:name,code,beforeIndex:old,afterIndex:next,keys});
    }
    assert.equal(current.menu.index,index);assert.equal(current.menu.ids[index],personIndex);assert.deepEqual(searchMenuIdentity(current),identity);
    record.confirmedOwner=current;record.inputStart=await evaluate(cdp,'window.__speEngineKeys.length');
    await checkpoint(cdp,`search-${month}-${number}-actual-lcd-person-${personIndex}`);
    const fresh=await currentSearchPicker(cdp);assert.deepEqual(searchMenuIdentity(fresh),identity);assert.equal(fresh.menu.index,index);assert.equal(fresh.menu.ids[index],personIndex);
    await key(cdp,'Enter');record.confirmationKeys=await evaluate(cdp,`window.__speEngineKeys.slice(${record.inputStart})`);
    assert.deepEqual(record.confirmationKeys.map(k=>k.code),[0x27],'One physical Enter selects the freshly highlighted native person ID');return record;
}
