import fs from 'node:fs';
import assert from 'node:assert/strict';
let src=fs.readFileSync('build/r16-audit-qimen-v3.mjs','utf8');
const changes=[
  ["const dir='build/r16-qimen-hd-installed-v3';","const dir='build/r16-qimen-hd-installed-v4';"],
  ["assert.match(r.error,/Natural SEARCH budget ended before actual XuShu acquisition/);","assert.match(r.error,/ReferenceError: assertActualLoadedLibrary is not defined/);"],
  ['assert.equal(r.searchOrderRecords.length,96);assert.equal(r.searchMonthRecords.length,12);','assert.equal(r.searchOrderRecords.length,72);assert.equal(r.searchMonthRecords.length,9);'],
  ['assert.equal(r.systemModeChanges.length,12);','assert.equal(r.systemModeChanges.length,9);'],
  ['build/r16-qimen-runtime-executed-v3-fb6eef14.mjs','build/r16-qimen-runtime-executed-v4-fb6eef14.mjs'],
  ['assert.equal(person(m.after,171).belong,0);assert.equal(m.owned,false);','assert.equal(person(m.after,171).belong,m.month===9?13:0);assert.equal(m.owned,m.month===9);'],
  ['assert.equal(person(world,171).belong,0);','assert.equal(person(world,171).belong,13);assert.ok(world.queue.includes(171));assert.equal(r.actualAcquisition.month,9);assert.equal(r.actualAcquisition.caster.devotion,89);'],
  ["version:3,createdAt:new Date().toISOString(),status:'FAIL-preserved-natural-SEARCH-acquisition-budget'","version:4,createdAt:new Date().toISOString(),status:'FAIL-preserved-harness-undefined-post-acquisition-helper'"],
  ['build/r16-qimen-hd-installed-v3-console.log','build/r16-qimen-hd-installed-v4-console.log'],
  ['privatePorts:[14198,14199],privateListenerCount:0,privateChromePid:164368','privatePorts:[4871,4872],privateListenerCount:0,privateChromePid:165996'],
  ["files:[file(dir+'/failure.png'),file(dir+'/search-month-12-original-world.png')],observations:['Both original screenshots show normal strategy map dated199年1月 with 刘表 as lord','HD界面 toolbar is selected; no active search/person/system dialog remains','There is no FENG39 movie, target state report or numeric result']", "files:[file(dir+'/search-report-151.png'),file(dir+'/search-report-152.png'),file(dir+'/failure.png')],observations:['Original report151 shows 徐晃 and 城中找到 徐庶 in both HD report and native LCD','Original report152 shows 徐庶 and 某愿效死忠。 in both HD report and native LCD','Failure screenshot shows normal strategy map dated198年10月, with no FENG39 movie or state report']"],
  ["cause:'All12 original strategy months and96 real SEARCH orders executed. Actual XuShu remained Belong0 in every post-month capture. Discovery reports do not establish acquisition; the driver correctly failed before dispatch/cast.'", "cause:'All9 original strategy months and72 real SEARCH orders executed. XuShu actually became Belong13/Devotion89 and entered the current allied city queue. The next driver call used undefined assertActualLoadedLibrary instead of the existing strict observeActualLib helper, throwing before dispatch/cast.'"],
  ["acceptedBoundary:'Real SEARCH actor LCD input/IDs/owner ACKs, zero-money Thew8 orders, original strategy month execution and natural other-person acquisition are validated. The specified XuShu prerequisite failed naturally.'", "acceptedBoundary:'Real SEARCH actor LCD input/IDs/owner ACKs, zero-money Thew8 orders, original strategy month execution and actual owned XuShu acquisition are validated. Dispatch/cast was blocked by the driver naming error, not by game or HD rendering.'"],
  ["notAccepted:['Owned XuShu acquisition','Two-person dispatch to宛城'", "notAccepted:['Post-search actual LIB revalidation (not executed)','Two-person dispatch to宛城'"],
];
for(const [before,after] of changes){assert.equal(src.split(before).length,2,'Unique derivation '+before);src=src.replace(before,after);}
src=src.replace('actualSearchOrders:orders,actualMonths:months,actualAcquiredOtherPeople:acquired,','actualSearchOrders:orders,actualMonths:months,actualAcquiredPeople:acquired,actualAcquisition:{month:r.actualAcquisition.month,caster:r.actualAcquisition.caster,evidence:r.actualAcquisition.evidence},');
fs.writeFileSync('build/r16-audit-qimen-v4.mjs',src);
