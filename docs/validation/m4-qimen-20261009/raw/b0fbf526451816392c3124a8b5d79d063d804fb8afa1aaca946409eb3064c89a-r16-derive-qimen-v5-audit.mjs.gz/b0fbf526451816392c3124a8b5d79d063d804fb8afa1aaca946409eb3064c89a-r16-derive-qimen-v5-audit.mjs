import fs from 'node:fs';
import assert from 'node:assert/strict';
let src=fs.readFileSync('build/r16-audit-qimen-v4.mjs','utf8');
const changes=[
  ["const dir='build/r16-qimen-hd-installed-v4';","const dir='build/r16-qimen-hd-installed-v5';"],
  ['assert.match(r.error,/ReferenceError: assertActualLoadedLibrary is not defined/);','assert.match(r.error,/undefined !== 115/);'],
  ['assert.equal(r.searchOrderRecords.length,72);assert.equal(r.searchMonthRecords.length,9);','assert.equal(r.searchOrderRecords.length,56);assert.equal(r.searchMonthRecords.length,7);'],
  ['assert.equal(r.systemModeChanges.length,9);','assert.equal(r.systemModeChanges.length,7);'],
  ['build/r16-qimen-runtime-executed-v4-fb6eef14.mjs','build/r16-qimen-runtime-executed-v5-3522e81e.mjs'],
  ['assert.equal(backup.bytes,124067);','assert.equal(backup.bytes,124058);'],
  ['m.month===9?13:0','m.month===7?13:0'],
  ['m.month===9);','m.month===7);'],
  ['assert.equal(r.actualAcquisition.month,9);assert.equal(r.actualAcquisition.caster.devotion,89);','assert.equal(r.actualAcquisition.month,7);assert.equal(r.actualAcquisition.caster.devotion,84);'],
  ["version:4,createdAt:new Date().toISOString(),status:'FAIL-preserved-harness-undefined-post-acquisition-helper'","version:5,createdAt:new Date().toISOString(),status:'FAIL-preserved-harness-next-march-picker-ACK-race'"],
  ['build/r16-qimen-hd-installed-v4-console.log','build/r16-qimen-hd-installed-v5-console.log'],
  ['privatePorts:[4871,4872],privateListenerCount:0,privateChromePid:165996','privatePorts:[10617,10618],privateListenerCount:0,privateChromePid:174712'],
  ["files:[file(dir+'/search-report-151.png'),file(dir+'/search-report-152.png'),file(dir+'/failure.png')],observations:['Original report151 shows 徐晃 and 城中找到 徐庶 in both HD report and native LCD','Original report152 shows 徐庶 and 某愿效死忠。 in both HD report and native LCD','Failure screenshot shows normal strategy map dated198年10月, with no FENG39 movie or state report']", "files:[file(dir+'/06b-real-distributed-caster-troops.png'),file(dir+'/07-march-persons.png'),file(dir+'/failure.png')],observations:['The distributed-troops checkpoint shows actual 徐庶 selected in the person picker','First march screenshot shows zero generals selected before the actual selection gesture','Failure screenshot already shows one selected general and the remaining native list with 刘琦; the failure JSON was sampled earlier in the owner ACK gap and had empty deepItems/null deepMenuOwner','There is no FENG39 movie, combat or state report']"],
  ["cause:'All9 original strategy months and72 real SEARCH orders executed. XuShu actually became Belong13/Devotion89 and entered the current allied city queue. The next driver call used undefined assertActualLoadedLibrary instead of the existing strict observeActualLib helper, throwing before dispatch/cast.'", "cause:'After7 months/56 real SEARCH orders, XuShu was owned. Strict post-search actual LIB verification and real800 recruitment/distribution completed. First XuShu march selection was acknowledged, but the driver read the next deepItems before the new native seq204 menu owner had been reflected in HD rows, producing undefined instead of115. The assertion prevented a wrong second selection.'"],
  ["acceptedBoundary:'Real SEARCH actor LCD input/IDs/owner ACKs, zero-money Thew8 orders, original strategy month execution and actual owned XuShu acquisition are validated. Dispatch/cast was blocked by the driver naming error, not by game or HD rendering.'", "acceptedBoundary:'Real SEARCH/month/acquisition, post-search actual loaded LIB verification, bounded original800 enlistment/distribution and first XuShu march selection are validated. Second actor selection must wait for the actual new owner/complete rows; no AddFightOrder/cast or HD movie has been validated.'"],
  ["notAccepted:['Post-search actual LIB revalidation (not executed)','Two-person dispatch to宛城'", "notAccepted:['Second LiuQi march selection','Two-person dispatch to宛城'"],
];
for(const [before,after] of changes){assert.equal(src.split(before).length,2,'Unique derivation '+before);src=src.replace(before,after);}
const extra=`
const rec=r.recruitment,f=r.failureState;
assert.deepEqual(r.marchPersonIds,[171]);assert.equal(f.march.phase,1);assert.equal(f.march.origin,26);assert.equal(f.march.selected,1);assert.equal(f.march.ok,0);
assert.equal(f.menu.active,1);assert.equal(f.menu.context,1);assert.equal(f.menu.kind,3);assert.equal(f.menu.seq,204);assert.equal(f.menu.idsValid,true);assert.ok(f.menu.ids.includes(115));
assert.equal(f.city.deepMenuOwner,null);assert.deepEqual(f.city.deepItems,[]);assert.equal(f.city.deepLabel,'出征');assert.equal(f.city.sending,false);
assert.equal(rec.before.money,4524);assert.equal(rec.enlisted.money,4444);assert.equal(rec.enlisted.reserve,800);assert.equal(rec.equipped.money,4444);assert.equal(rec.equipped.reserve,100);
assert.equal(rec.equipped.persons.find(p=>p.personIndex===171).arms,800);
assert.deepEqual(rec.confirmation.nativeKeys.map(k=>k.code),[0x27]);assert.deepEqual(rec.distributionConfirmation.nativeKeys.map(k=>k.code),[0x27]);
assert.deepEqual(rec.before.date,rec.equipped.date);
assert.deepEqual(r.actualLibObservations.map(p=>p.stage),['startup','strategy-map','post-search-actual-standard-LIB']);
const recruitWorld=w=>({money:w.money,reserve:w.reserve,date:w.date,personQueue:w.personQueue,caster:w.persons.find(p=>p.personIndex===171)});
`;
src=src.replace('const pngs=fs.readdirSync(dir)',extra+'\nconst pngs=fs.readdirSync(dir)');
src=src.replace('lastWorld:{money:world.money','actualRecruitment:{requestedArms:rec.requestedArms,before:recruitWorld(rec.before),enlisted:recruitWorld(rec.enlisted),equipped:recruitWorld(rec.equipped),enlistQty:rec.quantity.atConfirmation,distributionQty:rec.distribution.atConfirmation,enlistConfirmationKeys:rec.confirmation.nativeKeys,distributionConfirmationKeys:rec.distributionConfirmation.nativeKeys},failedNextPicker:{nativeMenu:f.menu,city:{open:f.city.open,layer:f.city.layer,deepLabel:f.city.deepLabel,deepKind:f.city.deepKind,deepMenuOwner:f.city.deepMenuOwner,deepItems:f.city.deepItems,sending:f.city.sending},nativeMarch:f.march,confirmedMarchPeople:r.marchPersonIds},lastWorld:{money:world.money');
src=src.replace('},lastWorld:{money:world.money','},lastCampaignWorldBeforeRecruit:{money:world.money');
src=src.replace('lastWorld:output.lastWorld','lastCampaignWorldBeforeRecruit:output.lastCampaignWorldBeforeRecruit');
fs.writeFileSync('build/r16-audit-qimen-v5.mjs',src);
