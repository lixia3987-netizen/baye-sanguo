// Embedded by the ignored candidate builder. All changes are genuine UI input.
function campaignWorldExpression() {
    return `(() => {
        const d=baye.data,c=d.g_Cities[${originCity}],count=baye.getPersonCount();
        const generationBefore=Number(d.g_hdSpeGeneration),keysBefore=window.__speEngineKeys.length;
        const queue=Array.from({length:Number(c.Persons)},(_,i)=>Number(d.g_PersonsQueue[Number(c.PersonQueue)+i]));
        const read=id=>{if(!Number.isInteger(id)||id<0||id>=count)throw Error('Invalid current person ID');const p=d.g_Persons[id];
            return {id,personIndex:id,nativeId:id+1,name:baye.getPersonName(id),belong:Number(p.Belong),oldBelong:Number(p.OldBelong),iq:Number(p.IQ),thew:Number(p.Thew),arms:Number(p.Arms),devotion:Number(p.Devotion),level:Number(p.Level),armType:baye.hd.personArmType(id),equip:[Number(p.Tool1),Number(p.Tool2)]};};
        const orders=Array.from({length:Number(d.g_OrderQueue.length)},(_,i)=>d.g_OrderQueue[i]).filter(o=>Number(o.OrderId)!==255)
            .map(o=>({OrderId:Number(o.OrderId),City:Number(o.City),Person:Number(o.Person),TimeCount:Number(o.TimeCount)}));
        const orderedPeople=orders.map(o=>o.Person).filter(id=>Number.isInteger(id)&&id>=0&&id<count);
        const resident=queue.map(read),observed=Array.from(new Set([...queue,...orderedPeople,${casterPerson},${allyPerson},110,12])).map(read);
        const cities=baye.hd.realm().cities.map(c=>({i:c.i,name:c.name,belong:c.belong,owned:c.owned}));
        return {generationBefore,generationAfter:Number(d.g_hdSpeGeneration),keysBefore,keysAfter:window.__speEngineKeys.length,
            city:${originCity},cityBelong:Number(c.Belong),playerKing:Number(d.g_PlayerKing),personQueueOffset:Number(c.PersonQueue),queue,resident,observed,orders,cities,
            money:Number(c.Money),food:Number(c.Food),reserve:Number(c.MothballArms),date:{year:Number(d.g_YearDate),month:Number(d.g_MonthDate)},
            enable16bitConsumeMoney:Number(d.g_engineConfig.enable16bitConsumeMoney),menu:baye.hd.menuItems(),march:baye.hd.march(),qty:baye.hd.qty(),report:baye.hd.report()};
    })()`;
}
async function observeCampaign(cdp,stage) {
    const world=await evaluate(cdp,campaignWorldExpression());
    assert.equal(world.generationAfter,world.generationBefore,'Current world read is one native generation');
    assert.equal(world.keysAfter,world.keysBefore,'Readonly campaign observation emits no native input');
    assert.equal(world.playerKing,12); assert.equal(world.cityBelong,13,'Current city must still be owned by real LiuBiao');
    assert.equal(world.enable16bitConsumeMoney,0,'Verified standard command-cost layout remains current');
    report.campaignObservations??=[];report.campaignObservations.push({stage,world});return world;
}
function isActualOwnedCaster(world) {
    const caster=world.observed.find(p=>p.personIndex===casterPerson);
    return !!(caster&&caster.belong===world.cityBelong&&world.queue.includes(casterPerson));
}
async function waitCampaignOutcome(cdp,label,predicate,timeout=120000) {
    const acknowledged=new Set(),deadline=Date.now()+timeout;
    while(Date.now()<deadline) {
        const s=await evaluate(cdp,'({fight:baye.hd.fight(),menu:baye.hd.menuItems(),report:baye.hd.report(),qty:baye.hd.qty(),march:baye.hd.march(),dialog:BayeHdDialog.debugSnapshot(),city:BayeHdCityMenu.debugSnapshot(),phase:BayeHdOverworld.debugSnapshot().phase})');
        assert.ok(!s.fight.active||s.fight.over,'Unexpected real campaign battle is preserved as failure; never auto-resolved by this search baseline');
        if(s.report.active) {
            const owner=s.dialog.reportOwner;
            if(s.dialog.open&&s.dialog.kind==='report'&&owner&&owner.seq===s.report.seq&&owner.inputSeq===s.report.inputSeq) {
                const token=JSON.stringify(owner);
                if(!acknowledged.has(token)) {
                    acknowledged.add(token);
                    const world=await observeCampaign(cdp,label+'-report-'+s.report.seq),start=await evaluate(cdp,'window.__speEngineKeys.length');
                    report.campaignReports??=[];const record={label,owner,native:s.report,body:s.dialog.body,world,inputStart:start};report.campaignReports.push(record);
                    await checkpoint(cdp,'search-report-'+report.campaignReports.length);
                    const fresh=await evaluate(cdp,'baye.hd.report()');assert.equal(fresh.active,1);assert.equal(fresh.seq,owner.seq);assert.equal(fresh.inputSeq,owner.inputSeq);
                    await click(cdp,'#hd-dialog [data-hd-dlg-ok]');
                    record.keys=await evaluate(cdp,`window.__speEngineKeys.slice(${start})`);
                    assert.deepEqual(record.keys.map(k=>k.code),[0x27],'Exactly one current native report confirmation');
                }
            }
        } else if(!s.qty.active&&!s.city.sending&&!s.city.queueLen&&predicate(s)) return s;
        await delay(100);
    }
    throw Error('Timeout: '+label+'; original reports/world retained, no automatic restart');
}
async function retireSearchToMap(cdp,label) {
    const before=await observeCampaign(cdp,label+'-before-back'),start=await evaluate(cdp,'window.__speEngineKeys.length');
    for(let step=0;step<4;step++) {
        const state=await waitCampaignOutcome(cdp,label+'-current-back-owner',s=>s.menu.active&&s.menu.context===1||!s.menu.active&&s.march.pick===1&&s.march.phase===0);
        if(!state.menu.active) break;
        const owner={generation:before.generationBefore,context:state.menu.context,kind:state.menu.kind,seq:state.menu.seq,detailGeneration:state.menu.detailGeneration};
        const fresh=await evaluate(cdp,'({menu:baye.hd.menuItems(),generation:Number(baye.data.g_hdSpeGeneration)})');
        assert.deepEqual({generation:fresh.generation,context:fresh.menu.context,kind:fresh.menu.kind,seq:fresh.menu.seq,detailGeneration:fresh.menu.detailGeneration},owner);
        const keyStart=await evaluate(cdp,'window.__speEngineKeys.length');await click(cdp,'#hd-city-menu [data-hd-menu-back]');
        await waitFor(cdp,label+' exact current menu owner retired',`!baye.hd.menuItems().active||baye.hd.menuItems().seq!==${owner.seq}`);
        const keys=await evaluate(cdp,`window.__speEngineKeys.slice(${keyStart})`);assert.deepEqual(keys.map(k=>k.code),[0x28]);
    }
    const map=await waitCampaignOutcome(cdp,label+' real map',s=>!s.menu.active&&s.march.pick===1&&s.march.phase===0&&s.march.battlePick===0&&s.phase==='map'&&!s.city.open);
    const after=await observeCampaign(cdp,label+'-after-back');
    for(const field of ['queue','observed','orders','money','food','reserve','date'])assert.deepEqual(after[field],before[field],label+' Back cannot change '+field);
    return {before,after,map,keys:await evaluate(cdp,`window.__speEngineKeys.slice(${start})`)};
}
async function enterSearchPicker(cdp,month) {
    const world=await observeCampaign(cdp,'search-month-'+month+'-before-city');
    assert.ok(await action(cdp,'open-actual-search-city',`BayeHdOverworld.walkToCity(${originCity})`));
    await waitFor(cdp,'current native city root',`(() => {const m=baye.hd.menuItems(),s=BayeHdCityMenu.debugSnapshot();return s.open&&s.layer==='root'&&s.cityIndex===${originCity}&&m.active&&m.context===1&&m.kind===1;})()`);
    const rootMenu=await evaluate(cdp,'baye.hd.menuItems()'),rootIndex=rootMenu.names.indexOf('内政');assert.ok(rootIndex>=0);
    await click(cdp,`#hd-city-menu [data-hd-root="${rootIndex}"]`);
    await waitFor(cdp,'real interior submenu',"BayeHdCityMenu.getLayer()==='sub'&&baye.hd.menuItems().active&&baye.hd.menuItems().context===1&&baye.hd.menuItems().kind===2");
    const sub=await evaluate(cdp,'baye.hd.menuItems()'),index=sub.names.indexOf('搜寻');assert.ok(index>=0,'Actual original menu contains SEARCH');
    await click(cdp,`#hd-city-menu [data-hd-sub="${index}"]`);
    const current=await currentPersonPicker(cdp,'搜寻',originCity);
    assert.deepEqual(current.menu.ids,world.resident.filter(p=>p.belong===world.cityBelong).map(p=>p.personIndex));
    assert.ok(!current.menu.ids.includes(casterPerson)||isActualOwnedCaster(world),'Unowned XuShu cannot be selected as a search actor');
    return current;
}
async function commitSearchOrder(cdp,personIndex,month,number) {
    const picker=await currentPersonPicker(cdp,'搜寻',originCity),before=await observeCampaign(cdp,`search-${month}-${number}-before`);
    const actual=before.resident.find(p=>p.personIndex===personIndex),index=picker.menu.ids.indexOf(personIndex);
    assert.ok(actual&&index>=0&&actual.belong===13&&actual.thew>=report.searchNativeCost.thew);
    assert.ok(personIndex!==casterPerson&&personIndex!==allyPerson&&personIndex!==12,'Search retains actual future caster/ally/lord');
    assert.equal(picker.city.deepItems.find(p=>p.i===index)?.pind,personIndex);
    const start=await evaluate(cdp,'window.__speEngineKeys.length');
    const fresh=await evaluate(cdp,'({menu:baye.hd.menuItems(),generation:Number(baye.data.g_hdSpeGeneration)})');
    assert.deepEqual(fresh.menu,picker.menu);assert.equal(fresh.generation,before.generationBefore);
    await click(cdp,`#hd-city-menu [data-hd-deep="${index}"][data-hd-deep-pind="${personIndex}"]`);
    const outcome=await waitCampaignOutcome(cdp,`search-${month}-${number}-original-speech-and-order`,s=>s.menu.active&&s.menu.context===1&&s.menu.kind===3&&s.city.deepLabel==='搜寻'||!s.menu.active&&s.march.pick===1&&s.march.phase===0);
    const after=await observeCampaign(cdp,`search-${month}-${number}-actual-queued`);
    assert.equal(after.money,before.money,'Standard SEARCH consumes zero actual money');
    assert.equal(after.observed.find(p=>p.personIndex===personIndex)?.thew,actual.thew-report.searchNativeCost.thew);
    assert.deepEqual(after.queue,before.queue.filter(id=>id!==personIndex),'Successful AddOrderHead removes only the actual searcher');
    const orders=after.orders.filter(o=>o.OrderId===3&&o.City===originCity&&o.Person===personIndex);
    assert.equal(orders.length,before.orders.filter(o=>o.OrderId===3&&o.City===originCity&&o.Person===personIndex).length+1);
    assert.equal(orders.at(-1).TimeCount,0);assert.deepEqual(after.date,before.date,'Queuing SEARCH does not execute it or advance time');
    assert.equal(after.observed.find(p=>p.personIndex===casterPerson).belong,before.observed.find(p=>p.personIndex===casterPerson).belong,'A search order is not fake acquisition');
    const record={month,number,personIndex,nativeId:personIndex+1,actual,before,after,outcome,owner:picker.menu,keys:await evaluate(cdp,`window.__speEngineKeys.slice(${start})`)};
    report.searchOrderRecords??=[];report.searchOrderRecords.push(record);return record;
}
async function executeSearchMonth(cdp,month,orders) {
    const retirement=await retireSearchToMap(cdp,'search-month-'+month),before=await observeCampaign(cdp,'search-month-'+month+'-before-strategy-end');
    assert.ok(!before.menu.active&&!before.qty.active&&!before.report.active&&before.march.pick===1&&before.march.battlePick===0);
    const start=await evaluate(cdp,'window.__speEngineKeys.length');
    await key(cdp,'Escape');
    const owner=await waitFor(cdp,'current original strategy menu',"(() => {const m=baye.hd.menuItems();return m.active&&m.context===2&&m.names[0]==='策略结束'&&BayeHdSystemUi.isOpen()&&BayeHdSystemUi.getScreen()==='insystem'&&m;})()");
    const fresh=await evaluate(cdp,'baye.hd.menuItems()');assert.deepEqual(fresh,owner);
    await click(cdp,'#hd-system-ui [data-hd-sys="0"][data-hd-sys-owner]');
    const serial=d=>d.year*12+d.month-1,expected=serial(before.date)+1;
    await waitCampaignOutcome(cdp,'search-month-'+month+' original ComputerTactic/PolicyExec/ConditionUpdate',s=>!s.menu.active&&s.march.pick===1&&s.march.battlePick===0&&s.phase==='map'&&!s.city.open&&s.march.mapInputSeq>before.march.mapInputSeq,180000);
    const after=await observeCampaign(cdp,'search-month-'+month+'-after-original-execution');
    assert.equal(serial(after.date),expected,'Exactly one genuine strategy month was executed');
    for(const order of orders) {
        assert.ok(after.queue.includes(order.personIndex),'Actual searcher returned via original AddPerson');
        assert.equal(after.observed.find(p=>p.personIndex===order.personIndex)?.belong,13);
        assert.equal(after.orders.filter(o=>o.OrderId===3&&o.City===originCity&&o.Person===order.personIndex).length,0,'Original search order was executed and deleted');
    }
    const keys=await evaluate(cdp,`window.__speEngineKeys.slice(${start})`);
    assert.equal(keys.filter(k=>k.code===0x28).length,1,'One native map EXIT opens FunctionMenu; no second EXIT is manufactured');
    const result={month,retirement,before,after,orders:orders.map(o=>({personIndex:o.personIndex,nativeId:o.nativeId})),functionOwner:owner,keys,owned:isActualOwnedCaster(after)};
    report.searchMonthRecords??=[];report.searchMonthRecords.push(result);await checkpoint(cdp,'search-month-'+month+'-original-world');return result;
}
async function searchForActualCaster(cdp) {
    const initial=await observeCampaign(cdp,'search-initial-original-city'),caster=initial.observed.find(p=>p.personIndex===casterPerson);
    assert.equal(caster.belong,0,'Original P2 XuShu starts unowned, never in an allied dispatch');
    assert.ok(initial.queue.includes(casterPerson));
    report.searchBudget={months:searchMonths,ordersPerMonth:searchOrders,initial,scope:'Actual SEARCH commands and original strategy execution; no diplomat Canvass on an unowned target, no direct call to SearchDrv/PolicyExec/ConditionUpdate or any world assignment.'};
    for(let month=1;month<=searchMonths;month++) {
        await enterSearchPicker(cdp,month);const orders=[];
        for(let number=1;number<=searchOrders;number++) {
            const world=await observeCampaign(cdp,`search-${month}-${number}-actual-candidates`);
            if(isActualOwnedCaster(world))break;
            const picker=await currentPersonPicker(cdp,'搜寻',originCity);
            const eligible=world.resident.filter(p=>p.belong===13&&picker.menu.ids.includes(p.personIndex)&&p.thew>=report.searchNativeCost.thew&&![12,allyPerson,casterPerson].includes(p.personIndex));
            eligible.sort((a,b)=>(a.personIndex===110?-1:b.personIndex===110?1:b.iq-a.iq)||a.personIndex-b.personIndex);
            if(!eligible.length){report.searchBudgetExhausted??=[];report.searchBudgetExhausted.push({month,number,reason:'No current owned resident has native search Thew',world});break;}
            orders.push(await commitSearchOrder(cdp,eligible[0].personIndex,month,number));
        }
        assert.ok(orders.length,'At least one genuine SEARCH order is required before ending this strategy month');
        const executed=await executeSearchMonth(cdp,month,orders);
        if(executed.owned) {
            report.actualAcquisition={month,world:executed.after,caster:executed.after.observed.find(p=>p.personIndex===casterPerson),evidence:'Actual Belong13 and current native queue only. Report text alone or static original placement cannot authorize ownership.'};
            break;
        }
    }
    const final=await observeCampaign(cdp,'search-budget-final');
    assert.ok(isActualOwnedCaster(final),'Natural SEARCH budget ended before actual XuShu acquisition; preserve this private game failure');
    await assertActualLoadedLibrary(cdp,'post-search-actual-standard-LIB');
    await checkpoint(cdp,'search-actual-owned-XuShu');
}
