const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),zlib=require('node:zlib'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),base='docs/validation/m4-qimen-20261009',sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const names=fs.readdirSync(path.join(root,'build'),{withFileTypes:true});
const files=names.filter(v=>v.isFile()&&v.name.startsWith('r16-')&&/\.(json|mjs|cjs|log|cmd|txt)$/.test(v.name)).map(v=>'build/'+v.name);
files.push('scripts/test-hd-qimen-runtime.mjs');
const dirs=names.filter(v=>v.isDirectory()&&v.name.startsWith('r16-qimen-')&&(/preflight|installed/.test(v.name)||v.name==='r16-qimen-native')).map(v=>'build/'+v.name);
for(const dir of dirs)for(const item of fs.readdirSync(path.join(root,dir),{withFileTypes:true}))if(item.isFile()&&/\.(json|png|log)$/.test(item.name))files.push(dir+'/'+item.name);
const selectedReports=new Map();
for(const dir of dirs.filter(d=>/installed-v[3-9]$/.test(d))){
 const r=JSON.parse(fs.readFileSync(path.join(root,dir,'result.json')));assert.ok(r.finishedAt&&r.isolation.cleaned,'Archive only after a terminal, cleaned private run');
 const keep=new Set(),groups=new Set(),reports=r.campaignReports||[];
 reports.forEach((record,i)=>{const m=/search-(?:month-)?(\d+)/.exec(record.label||''),group=m?m[1]+':'+((record.label||'').includes('ComputerTactic')?'execution':'order'):'other';if(!groups.has(group)||record.native?.person===171||/徐庶/.test(record.body||''))keep.add(i+1);groups.add(group);});
 if(reports.length)keep.add(reports.length);selectedReports.set(dir,keep);
}
const index={schemaVersion:1,scope:'Full original raw private attempt reports, inputs, worlds and frame telemetry plus explicitly selected original PNGs, native references, static reviews and tests. v1/v2 failure PNGs all kept; v3 onward retains each month first SEARCH actor and first order/execution report, every XuShu report, final report, every other checkpoint and all native/HD movie captures. Unselected repetitive SEARCH PNGs remain local with explicit original hashes.',raw:[],images:[],omittedImages:[]};
for(const sub of ['raw','images'])fs.mkdirSync(path.join(root,base,sub),{recursive:true});
for(const file of [...new Set(files)]){
 const data=fs.readFileSync(path.join(root,file)),hash=sha(data),png=path.extname(file)==='.png';
 const repeat=file.match(/^(build\/r16-qimen-hd-installed-v[3-9])\/(?:search-(\d+)-(\d+)-actual-lcd-person-\d+|search-report-(\d+))\.png$/);
 if(png&&repeat&&selectedReports.has(repeat[1])&&(repeat[3]?Number(repeat[3])!==1:!selectedReports.get(repeat[1]).has(Number(repeat[4])))){
  index.omittedImages.push({source:file,bytes:data.length,sha256:hash,reason:'Repetitive SEARCH screenshot not selected for the repository archive; original stays local build. Complete raw native menu/owner/world/order/report/key telemetry is archived. This PNG itself is not recoverable from the committed raw telemetry.'});continue;
 }
 const destination=base+'/'+(png?'images/'+hash+'.png':'raw/'+hash+'-'+path.basename(file)+'.gz'),output=path.join(root,destination);
 assert.ok(path.resolve(output).startsWith(path.resolve(root,base)+path.sep));const encoded=png?data:zlib.gzipSync(data,{level:9});
 if(fs.existsSync(output))assert.deepEqual(fs.readFileSync(output),encoded);else fs.writeFileSync(output,encoded);
 const recovered=fs.readFileSync(output);assert.deepEqual(png?recovered:zlib.gunzipSync(recovered),data);
 (png?index.images:index.raw).push({source:file,bytes:data.length,sha256:hash,archivedPath:destination,archivedBytes:recovered.length,archivedSha256:sha(recovered),byteExactVerified:true});
}
for(const name of fs.readdirSync(path.join(root,base,'raw'))){
 const archivedPath=base+'/raw/'+name;if(index.raw.some(r=>r.archivedPath===archivedPath))continue;
 const encoded=fs.readFileSync(path.join(root,archivedPath)),data=zlib.gunzipSync(encoded),original=index.raw.find(r=>r.sha256===sha(data));assert.ok(original,'Retained variants always have the same authenticated original bytes');
 index.raw.push({...original,archivedPath,archivedBytes:encoded.length,archivedSha256:sha(encoded),retainedVariant:true});
}
index.counts={logicalRaw:index.raw.length,physicalRaw:new Set(index.raw.map(r=>r.archivedPath)).size,logicalPng:index.images.length,physicalPng:new Set(index.images.map(r=>r.archivedPath)).size,omittedImages:index.omittedImages.length};
index.transformation='Raw reports/scripts/logs only gzip; original PNGs byte-exact copied. All archive roundtrips verified. No asset transformations or deletions.';
fs.writeFileSync(path.join(root,base,'runtime-index.json'),JSON.stringify(index,null,2)+'\n');console.log(JSON.stringify(index.counts));
