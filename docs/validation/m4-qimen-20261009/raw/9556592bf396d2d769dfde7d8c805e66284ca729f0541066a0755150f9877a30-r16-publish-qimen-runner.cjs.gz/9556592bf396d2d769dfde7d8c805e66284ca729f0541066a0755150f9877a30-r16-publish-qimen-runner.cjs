const fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const base='build/r16-test-hd-qimen-runtime-candidate.mjs',bytes=fs.readFileSync(base);assert.equal(sha(bytes),'639d427f16558350adef26a57752ddb9cf49ec78a07a472e5e9b6ee1a28b92da');
const dir='docs/validation/m4-qimen-20261009';fs.mkdirSync(dir,{recursive:true});
const moves=[['build/r16-next-skill-plan.json',dir+'/route-plan.json','fa797bb0fb181338eafdc7acc589e5c9ae9749575cecc490acb605f819d9a3df'],['build/r16-qimen-search-contract.json',dir+'/search-contract.json','644af0beac307c852d4f8239cc477e006251bdcddb16641493e1ed7e24b5cba3']];
let text=bytes.toString('utf8');for(const [src,dst,expected] of moves){const b=fs.readFileSync(src);assert.equal(sha(b),expected);assert.ok(!fs.existsSync(dst));fs.writeFileSync(dst,b);assert.ok(text.includes(src));text=text.replaceAll(src,dst);}
text=text.replace('Windows: node build/r16-test-hd-qimen-runtime-candidate.mjs','Windows: node scripts/test-hd-qimen-runtime.mjs');
text=text.replaceAll(/[^\S\r\n]+(?=\r?$)/gm,'');assert.ok(!fs.existsSync('scripts/test-hd-qimen-runtime.mjs'));
fs.writeFileSync('scripts/test-hd-qimen-runtime.mjs',text);
const packagePath='package.json',packageText=fs.readFileSync(packagePath,'utf8');assert.ok(packageText.includes('"test:water-runtime": "node scripts/test-hd-water-runtime.mjs"'));
fs.writeFileSync(packagePath,packageText.replace('"test:water-runtime": "node scripts/test-hd-water-runtime.mjs"','"test:water-runtime": "node scripts/test-hd-water-runtime.mjs",\n    "test:qimen-runtime": "node scripts/test-hd-qimen-runtime.mjs"'));
const result={candidate:{path:base,bytes:bytes.length,sha256:sha(bytes),executedBrowser:false},publication:{path:'scripts/test-hd-qimen-runtime.mjs',bytes:Buffer.byteLength(text),sha256:sha(Buffer.from(text))},changes:'Before any browser execution: required plan inputs relocated to tracked docs; CLI example points at published script; trailing spaces absent.',plans:moves.map(([src,dst])=>({source:src,target:dst,bytes:fs.statSync(dst).size,sha256:sha(fs.readFileSync(dst)),byteEqual:fs.readFileSync(src).equals(fs.readFileSync(dst))}))};
fs.writeFileSync('build/r16-qimen-publication-proof.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));

