const fs=require('node:fs'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const meta=p=>{const b=fs.readFileSync(p);return {path:p.replaceAll('\\','/'),bytes:b.length,sha256:sha(b)};};
const png=p=>{const b=fs.readFileSync(p);assert.equal(b.subarray(0,8).toString('hex'),'89504e470d0a1a0a');return {...meta(p),width:b.readUInt32BE(16),height:b.readUInt32BE(20),bitDepth:b[24],colorType:b[25]};};
const plan=JSON.parse(fs.readFileSync('build/r16-qimen-hd-wiring-plan.json'));
const oldBytes=fs.readFileSync('assets/hd-spe/manifest.json');assert.equal(sha(oldBytes),'9aa89592486210db467dfb7d3c714df7b8a1e19e09d1e87f497d13b9ac482ac0');
const manifest=JSON.parse(oldBytes);assert.equal(manifest.entries.length,42);assert.ok(!manifest.entries.some(e=>e.speId===39));
const native=plan.resource39;assert.equal(native.fingerprint,'fnv1a32:6b0ebc5a:1084');assert.ok(native.units.every(u=>u.cdelay===25&&u.ndelay===25));
const calls=[
 ['build/r16-qimen-picture0-prompt.json','exec-50a38a6b-839b-495c-a8bd-0f401c440bd6.png','rejected for picture0: raised extended arm'],
 ['build/r16-qimen-picture0-correction-prompt.json','exec-29b30bb5-71e1-4128-8639-11ebc2f6d80b.png','rejected for picture0: hand still chest/shoulder high'],
 ['build/r16-qimen-picture0-correction2-prompt.json','exec-2a96348a-8ccf-474f-8c6e-0ebdff30c660.png','selected picture0: low inward bent elbow at belt'],
 ['build/r16-qimen-picture1-prompt.json','exec-c30d84bc-ddaa-4a4e-95a3-5db01501825d.png','selected picture1: raised forward arm and other hand opened']
].map(([promptPath,name,selection],i)=>{
 const request=JSON.parse(fs.readFileSync(promptPath)),original='C:/Users/75112/.codex/generated_images/01a116e2-c940-7931-9e13-0a495970c85f/'+name;
 return {call:i+1,mode:'built-in image_gen',promptSource:meta(promptPath),request,referenceFiles:request.args.referenced_image_paths.map(meta),original:png(original),selection};
});
const dir='assets/hd-spe/qimen-39';assert.ok(!fs.existsSync(dir));fs.mkdirSync(dir,{recursive:true});
const pictures=[0,1].map(i=>{
 const src=dir+'/picture-'+i+'.png',prepared='build/r16-qimen-art/picture-'+i+'.png',original=calls[i+2].original.path;
 const data=fs.readFileSync(prepared);assert.ok(data.equals(fs.readFileSync(original)));fs.writeFileSync(src,data);
 const out=png(src);assert.equal(out.colorType,2);assert.equal(out.bitDepth,8);assert.equal(out.width,out.height);return {...out,picIndex:i,originalSource:original,byteEqualOriginal:true,noPostProcessing:true};
});
const entry=structuredClone(plan.manifest.entryTemplatePendingArt);for(const p of entry.pictures){const a=pictures[p.picIndex];p.width=a.width;p.height=a.height;}
assert.deepEqual(manifest.entries,JSON.parse(oldBytes).entries);manifest.entries.push(entry);
const record={schemaVersion:1,localDate:'2026-10-09',baseRevision:'dc0bf42aad72a3b9ad90fc968e2317244b3a7011',resourceId:39,itemIndex:0,nativeSkill:{id:20,name:'奇门',target:'Actual friendly AIM cell; true RNG success applies state4, cost20 MP; power0/destroy0 do not execute NUM15 or the numeric hold.',aim:1,state:4,power:0,destroy:0,mp:20},library:plan.library,native:{payloadSha256:native.sha256,fingerprint:native.fingerprint,header:{type:native.type,idx:native.headerIndex,count:native.count,picmax:native.picmax,startFrm:native.start,endFrm:native.end},units:native.units,pictures:native.pictures},imageGeneration:{mode:'built-in image_gen',calls:calls.length,transparentBackground:false,postProcessing:'None: selected original PNG bytes copied exactly; no crop, resize, recolor, reencode or compositing.',requests:calls},selectedPictures:pictures,manifestEntry:entry,visualReview:{scope:'Art/static only; runtime evidence is separately recorded in docs/validation/m4-qimen-20261009.',rejectedCandidates:2,accepted:'Single full standing figure, picture0 low inward bent arm, picture1 raised forward/opened arm; consistent character/material/scene, no visible UI, text or extra props.',nativeInterpretationBoundary:'Key pose differences and composition followed; painterly translation is not pixel-for-pixel native anatomy or a named spell narrative.'},artOnly:true,globalHdCompletion:false};
assert.ok(!fs.existsSync('assets/hd-spe/GENERATED-QIMEN.json'));fs.writeFileSync('assets/hd-spe/GENERATED-QIMEN.json',JSON.stringify(record,null,2)+'\n');
fs.writeFileSync('assets/hd-spe/GENERATED-QIMEN.md','# 奇门 FENG39 高清图片\n\n内置 image_gen 共四次调用；前两张动作不符的候选保留来源和提示词，最终采用两张原始 opaque PNG。图片0为低位屈肘，图片1为前伸抬手，保留单人全身构图、角色和材质连续性。原图按字节复制，没有缩放、裁剪、重编码或拼接。\n\n完整提示词、参考来源、原图路径、尺寸和哈希见 GENERATED-QIMEN.json。原生39为8单位、每单位25/25延时、两张64×64图交替。这里只记录美术与静态接入；真实搜寻、出征、奇门状态4结果及显示验收另见 docs/validation/m4-qimen-20261009。技能20没有伤害数字或数字等待，不能用NUM15元数据声称数字结果。共享39的其他技能实际施法不包含在此美术记录内。\n');
fs.writeFileSync('assets/hd-spe/manifest.json',JSON.stringify(manifest,null,2)+'\n');
const pc=fs.readFileSync('pc.html','utf8');assert.equal(pc.split('20261009v').length-1,4);fs.writeFileSync('pc.html',pc.replaceAll('20261009v','20261009w'));
const result={oldManifest:{bytes:oldBytes.length,sha256:sha(oldBytes),entries:42},manifest:meta('assets/hd-spe/manifest.json'),newEntries:43,old42DeepEqual:true,record:meta('assets/hd-spe/GENERATED-QIMEN.json'),pictures,pc:meta('pc.html'),lib:meta('libs/dat-mod.lib'),nativeOrFrontendChanged:false};
fs.writeFileSync('build/r16-qimen-install-proof.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));

