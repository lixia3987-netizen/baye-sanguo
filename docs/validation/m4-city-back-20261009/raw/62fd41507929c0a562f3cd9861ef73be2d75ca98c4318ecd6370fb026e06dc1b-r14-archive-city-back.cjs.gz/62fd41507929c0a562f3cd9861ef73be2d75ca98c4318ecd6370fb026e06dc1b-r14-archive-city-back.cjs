const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),zlib=require('node:zlib');
const root=path.resolve(__dirname,'..'),out=path.join(root,'docs/validation/m4-city-back-20261009');
const rel=p=>path.relative(root,p).replaceAll('\\','/'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const runDir=path.join(root,'build/r14-city-back-installed-v2'),resultFile=path.join(runDir,'result.json');
const result=JSON.parse(fs.readFileSync(resultFile));
if(!result.ok||!result.sourceVerification?.ok)throw Error('Actual run must pass with source verification');
fs.mkdirSync(path.join(out,'raw'),{recursive:true});fs.mkdirSync(path.join(out,'images'),{recursive:true});
const raw=[],images=[];
function archive(filename){
 const bytes=fs.readFileSync(filename),hash=sha(bytes),source=rel(filename);
 const png=filename.endsWith('.png'),folder=png?'images':'raw';
 const target=path.join(out,folder,hash+'-'+path.basename(filename)+(png?'':'.gz'));
 const stored=png?bytes:zlib.gzipSync(bytes,{level:9});
 fs.writeFileSync(target,stored);
 if(!fs.readFileSync(target).equals(stored)||(!png&&!zlib.gunzipSync(stored).equals(bytes)))throw Error('Archive bytes mismatch');
 const record={source,path:rel(target),bytes:bytes.length,sha256:hash,storedBytes:stored.length,storedSha256:sha(stored)};
 (png?images:raw).push(record);return record;
}
const runs=['build/r14-city-back-installed-v1','build/r14-city-back-installed-v2'];
for(const dir of runs)for(const file of fs.readdirSync(path.join(root,dir)).sort()){
 const full=path.join(root,dir,file);if(fs.statSync(full).isFile()&&/\.(json|log|png|mjs)$/.test(file))archive(full);
}
for(const filename of ['build/r14-city-back-focused.log','build/r14-all-tests.log','build/r14-city-back-owner-review.json',
 'build/r14-city-back-review.json','build/r13-retired-city-back-risk.json','build/r14-city-back-fix-plan.json',
 'build/r14-retired-map-owner-peer-plan.json','build/r14-city-back-promoted-preflight.json',
 'build/r14-city-back-review-v2.json','build/r14-city-back-focused-v2.log','build/r14-city-back-focused-v3.log',
 'build/r14-all-tests-v2.log','build/r14-all-tests-v3.log','build/r14-all-tests-v4.log','build/r14-spe-isolated.log',
 'build/r14-city-back-installed-v1-console.log','build/r14-city-back-installed-v2-console.log',
 'build/r14-city-back-source-audit.json','build/r14-city-back-source-audit.cjs','build/r14-archive-city-back.cjs']){
 const full=path.join(root,filename);if(fs.existsSync(full))archive(full);
}
const indexed=new Set([...raw,...images].map(r=>r.path));
const previousArchiveVariants=fs.readdirSync(path.join(out,'raw')).map(name=>path.join(out,'raw',name)).filter(f=>!indexed.has(rel(f))).map(f=>{
 const stored=fs.readFileSync(f),bytes=zlib.gunzipSync(stored),hash=sha(bytes);
 if(!path.basename(f).startsWith(hash+'-'))throw Error('Previous archive variant fingerprint mismatch');
 return {path:rel(f),bytes:bytes.length,sha256:hash,storedBytes:stored.length,storedSha256:sha(stored),scope:'Earlier archive-builder snapshot retained as original gzip; not a new runtime or test result.'};
});
const index={schemaVersion:1,date:'2026-10-09',scope:'Two distinct actual private P4 city-only attempts: initial ACK/UI failure and final success. All available original JSON and PNG are preserved byte exact; hashes record frozen served production, not an archive of every production source byte.',
 raw,images,previousArchiveVariants,counts:{raw:raw.length,png:images.length,physicalRaw:new Set(raw.map(r=>r.path)).size+previousArchiveVariants.length,physicalPng:new Set(images.map(r=>r.path)).size,distinctPngBytes:new Set(images.map(r=>r.sha256)).size},runs:runs.map(dir=>({directory:dir,raw:raw.filter(r=>r.source.startsWith(dir+'/')).length,png:images.filter(r=>r.source.startsWith(dir+'/')).length})),result:raw.find(r=>r.source==='build/r14-city-back-installed-v2/result.json'),
 byteVerification:'Every PNG copied unchanged; every gzip decompresses byte exactly to the source. No image transformation or invented missing capture.'};
fs.writeFileSync(path.join(out,'runtime-index.json'),JSON.stringify(index,null,2)+'\n');
const validation={schemaVersion:1,date:'2026-10-09',status:'passed',baseRevision:'0ff17b2df158d9febe08869ed8b65aea51680f19',
 problem:'After real conscription exhausts money, native input has returned to ordinary map but the HD person-quantity pane remains visible. Its former Back could deliver EXIT to GetCitySet and open FunctionMenu.',
 change:'Only a proven retired native map closes the shell silently. Live menu Back captures and rechecks ownership just before sending; reports, HELP, quantities and other overlays exclude menu EXIT. Stale or cancelled pointer gestures cannot act on a replacement owner.',
 tests:{focusedWithIdentity:{passed:65,failed:0,skipped:0},windowsFull:{passed:692,failed:0,skipped:0,concurrency:4},
  retainedFailures:['First actual game: old conscription Back zero keys passed, actual distribution Back one EXIT returned to native map but sub pane stayed open; fixed only the user Back ACK retirement.','First full v2 run: digest fixture could finish sixty event-loop rounds before actual digest completion; fixture now waits bounded actual completion.','Full v3 run: local Node24 VM process crashed in unchanged SPE test; isolated42 passed, bounded-concurrency4 full692 passed. No production SPE change or skipped test.'],
  actual:{ok:result.ok,phases:result.phases.length,returnChecks:result.returnChecks,initialCity:result.initialCity,
    recruitment:result.recruitment,finalCity:result.finalCity,sourceVerification:{ok:result.sourceVerification.ok,count:result.sourceVerification.count,drift:result.sourceVerification.drift,runnerMatch:result.sourceVerification.runnerMatch},
    nativeSourceCheck:result.nativeSourceCheck,actualLib:result.actualLib,exceptions:result.exceptions,dialogs:result.dialogs,scope:result.scope,tool:result.tool}},
 firstActualAttempt:{ok:false,result:raw.find(r=>r.source==='build/r14-city-back-installed-v1/result.json'),audit:raw.find(r=>r.source==='build/r14-city-back-installed-v1/runtime-failure-audit.json'),scope:'No second Back was run. Do not claim unobserved post-failure world equality.'},
 production:{cacheVersion:'20261009u',hdCityMenu:{path:'js/hd-city-menu.js',sha256:sha(fs.readFileSync(path.join(root,'js/hd-city-menu.js')))},
   pc:{path:'pc.html',sha256:sha(fs.readFileSync(path.join(root,'pc.html')))},manifest:{path:'assets/hd-spe/manifest.json',sha256:sha(fs.readFileSync(path.join(root,'assets/hd-spe/manifest.json')))},
   nativeBuild:'No native change or rebuild. Installed quartet and tracked native source are the same as the Stone milestone; original build revision and modified flag retained.'},
 manualReviews:{root:['07-exhausted-native-map-stale-conscription-before-back.png','11-active-person-picker-back-one-exit.png'].map(name=>{
  const filename=path.join(runDir,name),bytes=fs.readFileSync(filename);return{source:rel(filename),sha256:sha(bytes),width:bytes.readUInt32BE(16),height:bytes.readUInt32BE(20)};
 }),independent:'Six final originals and three initial failure originals recorded by actual runtime audits; overlapping views do not add distinct images.'},
 originalRiskEvidence:raw.find(r=>r.source==='build/r13-retired-city-back-risk.json'),archive:'m4-city-back-20261009/runtime-index.json',archiveCounts:index.counts,
 limitations:['One P4 LiuShan/巴郡 desktop player flow, not all periods/Mod/mobile/performance.','No battle, skill, RNG or world-state injection.','One EXIT alone can open FunctionMenu; it does not itself advance strategy.','Stone/ordinary attack artwork and prior archives remain separate and unchanged.']};
fs.writeFileSync(path.join(root,'docs/validation/m4-city-back-20261009.json'),JSON.stringify(validation,null,2)+'\n');
console.log(JSON.stringify({status:'archived',...index.counts,phases:result.phases.length,checks:result.returnChecks?.length}));
