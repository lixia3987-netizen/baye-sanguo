const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim();
const protectedPaths=['assets','libs','vendor/iBaye','js/baye.js','js/baye.wasm','js/baye.wasm.map','js/baye.build.json','js/bridge.js','js/hd-spe.js','scripts/test-hd-stone-runtime.mjs','docs/validation/m4-stone-20261009.json','docs/validation/m4-stone-20261009'];
const changes=git('diff','--name-only','HEAD','--',...protectedPaths);
if(changes)throw Error('Protected Stone baseline changed: '+changes);
const quartet=['baye.js','baye.wasm','baye.wasm.map','baye.build.json'].map(name=>{
 const installed=fs.readFileSync(path.join(root,'js',name)),staged=fs.readFileSync(path.join(root,'build/wasm/src',name));
 if(!installed.equals(staged))throw Error('Quartet drift '+name);
 return {name,bytes:installed.length,sha256:sha(installed),stageEqualsInstalled:true};
});
const actual=JSON.parse(fs.readFileSync(path.join(root,'build/r14-city-back-installed-v2/result.json')));
if(!actual.ok||!actual.sourceVerification.ok||actual.nativeSourceCheck.aggregate!=='56b01e4becf3c06e6b4cc154dfa6585e37a2c9aa91cd3ada744420c72228e02f')throw Error('Actual source proof does not match baseline');
const result={ok:true,baseRevision:git('rev-parse','HEAD'),scope:'Git protected-path equality plus original bytes for quartet, manifest and actual frozen-source/native-source proof.',
 protectedPaths,protectedGitChanges:[],quartet,nativeSourceCheck:actual.nativeSourceCheck,
 manifest:{bytes:fs.statSync(path.join(root,'assets/hd-spe/manifest.json')).size,sha256:sha(fs.readFileSync(path.join(root,'assets/hd-spe/manifest.json'))),entries:JSON.parse(fs.readFileSync(path.join(root,'assets/hd-spe/manifest.json'))).entries.length},
 product:{cityMenu:sha(fs.readFileSync(path.join(root,'js/hd-city-menu.js'))),pc:sha(fs.readFileSync(path.join(root,'pc.html'))),runner:sha(fs.readFileSync(path.join(root,'scripts/test-hd-city-back-runtime.mjs')))},
 actualSourceVerification:{ok:actual.sourceVerification.ok,count:actual.sourceVerification.count,drift:actual.sourceVerification.drift,added:actual.sourceVerification.added,runnerMatch:actual.sourceVerification.runnerMatch}};
fs.writeFileSync(path.join(root,'build/r14-city-back-source-audit.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({ok:result.ok,manifestEntries:result.manifest.entries,sourceCount:result.actualSourceVerification.count}));
