import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
const mode=process.argv[2];assert.ok(['bridge','missing'].includes(mode));
const file='scripts/test-hd-overworld-runtime.mjs',dir='build/r24-overworld-original-entry-'+mode+'-v1';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const ref=p=>{const b=fs.readFileSync(p);return {path:p,bytes:b.length,sha256:sha(b)};};
assert.equal(ref(file).sha256,'d8c4db269f589af9fa4158e89f34e814cc3fbfbfdc053c404264fce59d96cdd5');
assert.equal(ref('assets/hd-overworld/roads/bridge-crossing-v1.png').sha256,'110a48d457f5af9be4f51d156f2841eab1dc7e524232d5592ab7bbe1c64f1e88');
assert.ok(!fs.existsSync(dir));
const args=[file,...(mode==='bridge'?['--bridge-art']:['--missing-bridge-asset','--bridge-only']),'--artifact-dir',dir];
const proof={startedAt:new Date().toISOString(),mode,runner:ref(file),wrapper:ref('build/r24-run-overworld-root-v1.mjs'),command:[process.execPath,...args],operatesUserBrowser:false,productionAssets:['assets/hd-overworld/manifest.json','assets/hd-overworld/GENERATED-BRIDGE.json','assets/hd-overworld/roads/bridge-crossing-v1.png','js/hd-overworld.js','js/original-game.js','js/lcd.js','pc.html','index.html'].map(ref)};
const log=fs.openSync(dir+'.log','wx'),child=spawn(process.execPath,args,{env:{...process.env,CHROME:'C:/Program Files/Google/Chrome/Application/chrome.exe'},stdio:['ignore',log,log],windowsHide:true});proof.runnerPid=child.pid;console.log(JSON.stringify({mode,runnerPid:child.pid,log:dir+'.log'}));
function sample(){
 const source=`$r23Chrome=@(Get-CimInstance Win32_Process | Where-Object { $_.ParentProcessId -eq ${child.pid} -and $_.Name -eq 'chrome.exe' -and $_.CommandLine -like '*baye-overworld-runtime-*' } | Select-Object ProcessId,ParentProcessId,CommandLine);$r23Ids=@(${child.pid})+@($r23Chrome.ProcessId);$r23Ports=@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $_.OwningProcess -in $r23Ids -or $_.LocalPort -eq 8080 } | Select-Object LocalPort,OwningProcess);[ordered]@{atUtc=(Get-Date).ToUniversalTime().ToString('o');chrome=$r23Chrome;ports=$r23Ports;user8080HttpStatus=(Invoke-WebRequest -UseBasicParsing http://localhost:8080/pc).StatusCode}|ConvertTo-Json -Depth 6`;
 return JSON.parse(execFileSync('powershell',['-NoProfile','-Command',source],{encoding:'utf8',windowsHide:true}));
}
const timer=setTimeout(()=>{try{proof.live=sample();fs.writeFileSync(dir+'-isolation-root.json',JSON.stringify(proof,null,2)+'\n');}catch(e){proof.liveError=String(e);}},1800);
const done=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));});
clearTimeout(timer);fs.closeSync(log);Object.assign(proof,{exitCode:done.code,signal:done.signal,finishedAt:new Date().toISOString(),log:ref(dir+'.log')});try{proof.after=sample();}catch(e){proof.afterError=String(e);}
if(fs.existsSync(dir+'/result.json')){proof.result=ref(dir+'/result.json');const r=JSON.parse(fs.readFileSync(dir+'/result.json'));proof.runtime={ok:r.ok,isolation:r.isolation,coverage:r.coverage,sourceDrift:r.sourceDrift};}
fs.writeFileSync(dir+'-isolation-root.json',JSON.stringify(proof,null,2)+'\n');console.log(JSON.stringify({exitCode:done.code,mode,result:proof.runtime?.ok,coverage:proof.runtime?.coverage,user8080:proof.after?.user8080HttpStatus}));process.exitCode=done.code??1;
