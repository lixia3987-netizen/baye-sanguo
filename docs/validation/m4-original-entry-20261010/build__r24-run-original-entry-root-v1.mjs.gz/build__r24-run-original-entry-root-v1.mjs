import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
const file='scripts/test-original-game-runtime.mjs',dir='build/r24-original-entry-actual-v1';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const ref=p=>{const b=fs.readFileSync(p);return {path:p,bytes:b.length,sha256:sha(b)};};
assert.equal(ref(file).sha256,process.argv[2]);assert.ok(!fs.existsSync(dir));
const proof={startedAt:new Date().toISOString(),runner:ref(file),wrapper:ref('build/r24-run-original-entry-root-v1.mjs'),operatesUserBrowser:false};
function sample(pid){
 const command=`$entryChrome=@(Get-CimInstance Win32_Process | Where-Object { $_.ParentProcessId -eq ${pid} -and $_.Name -eq 'chrome.exe' -and $_.CommandLine -like '*baye-original-runtime-*' } | Select-Object ProcessId,ParentProcessId,CommandLine);$entryIds=@(${pid})+@($entryChrome.ProcessId);$entryPorts=@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $_.OwningProcess -in $entryIds -or $_.LocalPort -eq 8080 } | Select-Object LocalPort,OwningProcess);[ordered]@{atUtc=(Get-Date).ToUniversalTime().ToString('o');chrome=$entryChrome;ports=$entryPorts;user8080HttpStatus=(Invoke-WebRequest -UseBasicParsing http://localhost:8080/pc).StatusCode}|ConvertTo-Json -Depth 6`;
 return JSON.parse(execFileSync('powershell',['-NoProfile','-Command',command],{encoding:'utf8',windowsHide:true}));
}
proof.before=sample(0);assert.equal(proof.before.user8080HttpStatus,200);
const args=[file,'--artifact-dir',dir];proof.command=[process.execPath,...args];
const log=fs.openSync(dir+'.log','wx'),child=spawn(process.execPath,args,{env:{...process.env,CHROME:'C:/Program Files/Google/Chrome/Application/chrome.exe'},stdio:['ignore',log,log],windowsHide:true});proof.runnerPid=child.pid;
console.log(JSON.stringify({runnerPid:child.pid,log:dir+'.log'}));
const timer=setTimeout(()=>{try{proof.live=sample(child.pid);fs.writeFileSync(dir+'-isolation-root.json',JSON.stringify(proof,null,2)+'\n');}catch(e){proof.liveError=String(e);}},1800);
const done=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));});clearTimeout(timer);fs.closeSync(log);
Object.assign(proof,{exitCode:done.code,signal:done.signal,finishedAt:new Date().toISOString(),log:ref(dir+'.log'),after:sample(child.pid)});
if(fs.existsSync(dir+'/result.json')){proof.result=ref(dir+'/result.json');const r=JSON.parse(fs.readFileSync(dir+'/result.json'));proof.runtime={ok:r.ok,cases:r.cases.map(x=>x.name),isolation:r.isolation,sourceDrift:r.sourceDrift};}
assert.equal(proof.after.user8080HttpStatus,200);assert.deepEqual(proof.after.ports.filter(x=>x.LocalPort===8080),proof.before.ports.filter(x=>x.LocalPort===8080));
fs.writeFileSync(dir+'-isolation-root.json',JSON.stringify(proof,null,2)+'\n');console.log(JSON.stringify({exitCode:done.code,...proof.runtime,user8080:proof.after.user8080HttpStatus}));process.exitCode=done.code??1;
