import fs from 'node:fs';
import assert from 'node:assert/strict';
const p=JSON.parse(fs.readFileSync('package.json'));
assert.ok(!p.scripts.test.includes('test-hd-liuyan-bridge.mjs'));
p.scripts.test+=' scripts/test-hd-liuyan-bridge.mjs';
assert.equal(p.scripts['test:liuyan'],undefined);
p.scripts['test:liuyan']='node --test scripts/test-hd-liuyan-bridge.mjs scripts/test-hd-spe.mjs';
p.scripts['generate:liuyan-manifest']='node scripts/generate-hd-spe-liuyan-entry.mjs';
fs.writeFileSync('package.json',JSON.stringify(p,null,2)+'\n');
