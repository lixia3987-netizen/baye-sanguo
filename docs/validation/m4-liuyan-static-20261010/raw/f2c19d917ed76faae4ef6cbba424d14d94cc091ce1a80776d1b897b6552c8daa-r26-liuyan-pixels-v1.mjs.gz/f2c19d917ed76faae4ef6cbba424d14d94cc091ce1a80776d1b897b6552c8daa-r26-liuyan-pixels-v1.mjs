/** R26 pure original LIB/PNG/timer decoding; no browser or engine interaction. */
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {inflateSync} from 'node:zlib';
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const W = 160, H = 96, SIZE = W * H * 4;
const bits = b => { assert.ok(Array.isArray(b) && b.length === 32 && b.every(n => Number.isInteger(n) && n >= 0 && n <= 255), 'Complete byte bitset'); return Array.from({ length: 256 }, (_, i) => i).filter(i => b[i >> 3] & 1 << (i & 7)); };
const normalized = b => { const out = Buffer.from(b); for (let i = 0; i < out.length; i += 4) if (out[i + 3] === 0) out.fill(0, i, i + 4); return out; };
function item(lib, id, index = 0) {
    assert.ok(Buffer.isBuffer(lib) && lib.length > id * 4); const a = lib.readUInt32LE((id - 1) * 4);
    assert.ok(a > 0 && a + 14 <= lib.length); const length = lib.readUInt32LE(a), count = lib.readUInt16LE(a + 6), fixed = lib.readUInt32LE(a + 8);
    assert.equal(lib.readUInt16LE(a + 4), id); assert.equal(lib[a + 12], 0); assert.ok(index >= 0 && index < count && a + length <= lib.length);
    const offset = fixed ? 14 + index * fixed : count === 1 ? 14 : lib.readUInt32LE(a + 14 + index * 8);
    const size = fixed || (count === 1 ? length - 14 : lib.readUInt32LE(a + 18 + index * 8));
    assert.ok(offset >= 14 && size > 0 && offset + size <= length); return lib.subarray(a + offset, a + offset + size);
}
function fnv(b) { let h = 2166136261; for (const n of b) h = Math.imul(h ^ n, 16777619) >>> 0; return 'fnv1a32:' + h.toString(16).padStart(8, '0') + ':' + b.length; }
function picture(b, offset = 0, all = false) {
    assert.ok(offset + 7 <= b.length); const width = b.readUInt16LE(offset), height = b.readUInt16LE(offset + 2), count = b.readUInt16LE(offset + 4), mask = b[offset + 6], rowBytes = Math.ceil(width / 8), planeBytes = rowBytes * height;
    assert.ok(width && height && count && mask <= 1); const length = 7 + planeBytes * (mask + 1) * (all ? count : 1); assert.ok(offset + length <= b.length);
    return { width, height, count, mask, rowBytes, planeBytes, length, data: b.subarray(offset + 7, offset + length) };
}
function movie(lib) {
    const payload = item(lib, 40), count = payload[2], picmax = payload[3];
    assert.deepEqual([count, picmax, payload[4], payload[5], payload.length, fnv(payload)], [8, 2, 0, 7, 1084, 'fnv1a32:bd0140e0:1084']);
    const units = Array.from({ length: count }, (_, i) => { const o = 6 + i * 5; return { x: payload[o], y: payload[o + 1], cdelay: payload[o + 2], ndelay: payload[o + 3], picIndex: payload[o + 4] }; });
    assert.deepEqual(units, Array.from({ length: 8 }, (_, i) => ({ x: 0, y: 0, cdelay: 20, ndelay: 20, picIndex: i % 2 })));
    let offset = 46; const pictures = Array.from({ length: 2 }, () => { const p = picture(payload, offset); offset += p.length; return p; });
    assert.equal(offset, payload.length); assert.deepEqual(pictures.map(p => [p.width, p.height, p.count, p.mask]), [[64, 64, 1, 0], [64, 64, 1, 0]]);
    return { units, pictures, fingerprint: fnv(payload), length: payload.length };
}
function paint(out, p, x, y, slot = 0) {
    const data = p.data.subarray(slot * p.planeBytes * (p.mask + 1));
    for (let row = 0; row < p.height; row++) for (let col = 0; col < p.width; col++) {
        const dx = x + col, dy = y + row; assert.ok(dx >= 0 && dx < W && dy >= 0 && dy < H);
        const o = row * p.rowBytes + (col >> 3), bit = 128 >> (col & 7), at = dy * W + dx;
        out[at] = p.mask ? (data[o] & bit ? out[at] : 0) | (data[p.planeBytes + o] & bit ? 255 : 0) : data[o] & bit ? 255 : 0;
    }
}
function counter(m, end) {
    const pixels = Buffer.alloc(W * H), spec = m.units.slice(0, end + 1).map(u => u.cdelay), next = m.units.slice(0, end + 1).map(u => u.ndelay), clears = Buffer.alloc(32), records = [];
    let introduced = 0, previous = 0, cls = true, show = true, width = 0;
    for (let loop = 0; loop < 100000; loop++) {
        for (let i = 0; i <= introduced; i++) {
            if (spec[i] === 1) { const p = m.pictures[m.units[i].picIndex]; for (let y = 16; y < 80; y++) pixels.fill(0, y * W + 48, y * W + 48 + p.width); width = Math.max(width, p.width); clears[i >> 3] |= 1 << (i & 7); cls = true; }
            if (spec[i]) spec[i] = spec[i] - 1 & 255;
        }
        const draw = i => { const p = m.pictures[m.units[i].picIndex]; paint(pixels, p, 48, 16); width = Math.max(width, p.width); };
        if (cls) for (let i = 0; i <= previous; i++) if (spec[i]) draw(i);
        if (show) { for (let i = previous + 1; i <= introduced; i++) if (spec[i]) draw(i); previous = introduced; }
        if (cls || show) { const visible = Buffer.alloc(32); for (let i = 0; i <= introduced; i++) if (spec[i]) visible[i >> 3] |= 1 << (i & 7); records.push({ frame: introduced, visible, clears: Buffer.from(clears), pixels: Buffer.from(pixels), width }); cls = show = false; }
        if (next[introduced]) next[introduced]--; while (next[introduced] <= 1 && introduced < end) { introduced++; show = true; }
        if (introduced === end && spec.slice(0, introduced + 1).every(n => n <= 1)) return records;
    }
    throw Error('Independent native timer bound exceeded');
}
function crc32(b) { let crc = 0xffffffff; for (const n of b) { crc ^= n; for (let bit = 0; bit < 8; bit++) crc = crc >>> 1 ^ (crc & 1 ? 0xedb88320 : 0); } return (crc ^ 0xffffffff) >>> 0; }
function png(b) {
    assert.deepEqual(b.subarray(0, 8), Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])); let at = 8, width, height, channels; const chunks = [];
    while (at < b.length) { const n = b.readUInt32BE(at), type = b.toString('ascii', at + 4, at + 8); assert.ok(at + 12 + n <= b.length); const data = b.subarray(at + 8, at + 8 + n); assert.equal(crc32(b.subarray(at + 4, at + 8 + n)), b.readUInt32BE(at + 8 + n), 'Original PNG CRC');
        if (type === 'IHDR') { width = data.readUInt32BE(0); height = data.readUInt32BE(4); assert.deepEqual([data[8], data[10], data[11], data[12]], [8, 0, 0, 0]); assert.ok([2, 6].includes(data[9])); channels = data[9] === 6 ? 4 : 3; }
        if (type === 'IDAT') chunks.push(data); at += n + 12; if (type === 'IEND') break;
    }
    assert.equal(at, b.length); assert.ok(width && height && channels); const raw = inflateSync(Buffer.concat(chunks)), stride = width * channels; assert.equal(raw.length, (stride + 1) * height); const decoded = Buffer.alloc(stride * height);
    const paeth = (a, b, c) => { const p = a + b - c, aa = Math.abs(p - a), bb = Math.abs(p - b), cc = Math.abs(p - c); return aa <= bb && aa <= cc ? a : bb <= cc ? b : c; };
    for (let y = 0; y < height; y++) { const filter = raw[y * (stride + 1)]; assert.ok(filter <= 4); for (let x = 0; x < stride; x++) { const left = x >= channels ? decoded[y * stride + x - channels] : 0, up = y ? decoded[(y - 1) * stride + x] : 0, ul = y && x >= channels ? decoded[(y - 1) * stride + x - channels] : 0; decoded[y * stride + x] = raw[y * (stride + 1) + x + 1] + (filter === 1 ? left : filter === 2 ? up : filter === 3 ? (left + up) >> 1 : filter === 4 ? paeth(left, up, ul) : 0) & 255; } }
    const rgba = Buffer.alloc(width * height * 4); for (let i = 0; i < width * height; i++) { rgba[i * 4] = decoded[i * channels]; rgba[i * 4 + 1] = decoded[i * channels + 1]; rgba[i * 4 + 2] = decoded[i * channels + 2]; rgba[i * 4 + 3] = channels === 4 ? decoded[i * channels + 3] : 255; }
    return { width, height, rgba };
}
function imageBytes(c, type, artifactDir) {
    assert.ok(['native', 'hd', 'lcd'].includes(type));
    const url = c[type === 'native' ? 'nativeUrl' : type === 'lcd' ? 'nativeCanvasUrl' : 'hdUrl'], record = c[type === 'native' ? 'nativeFile' : type === 'lcd' ? 'lcdFile' : 'hdFile']; let bytes;
    if (url) { assert.ok(url.startsWith('data:image/png;base64,')); bytes = Buffer.from(url.split(',')[1], 'base64'); }
    else { assert.ok(record && artifactDir, 'Raw PNG or retained file and artifactDir required'); const f = path.resolve(artifactDir, record.file); assert.ok(f.startsWith(path.resolve(artifactDir) + path.sep)); bytes = fs.readFileSync(f); }
    if (record) { assert.equal(bytes.length, record.bytes); assert.equal(sha(bytes), record.sha256); } return bytes;
}
function asset(assets, name) { const a = assets instanceof Map ? assets.get(name) : assets && assets[name]; assert.ok(a && Buffer.isBuffer(a.data || a), 'Frozen asset bytes: ' + name); return a.data || a; }
function verifyClassicCapture(c, raw, artifactDir) {
    assert.equal(c.mode, 'classic'); assert.equal(c.hidden, false); assert.equal(c.ui.open, false); assert.equal(c.ui.source, 'lcd'); assert.equal(c.ui.skipVisible, false); assert.equal(c.ui.hdRegion, null);
    assert.equal(c.hdLogicalRgba, null); assert.ok(!c.hdUrl && !c.hdFile, 'Classic evidence cannot substitute an old HD canvas');
    const d = c.lcdDom; assert.ok(d && d.visible === true && d.inViewport === true, 'Actual classic LCD is visible and inside viewport');
    assert.ok(Array.isArray(d.chain) && d.chain.length && d.chain[0].id === 'lcd' && d.chain.every(v => v.display !== 'none' && v.visibility !== 'hidden' && v.visibility !== 'collapse' && Number(v.opacity) > 0));
    assert.ok([d.x, d.y, d.width, d.height, d.viewport?.width, d.viewport?.height].every(Number.isFinite));
    assert.ok(d.x >= 0 && d.y >= 0 && d.width > 0 && d.height > 0 && d.x + d.width <= d.viewport.width + .5 && d.y + d.height <= d.viewport.height + .5);
    assert.ok(Array.isArray(d.points) && d.points.length === 3 && d.points.every(p => p.canvasAtFront === true && p.top && p.top.id === 'lcd' && p.x >= d.x && p.x <= d.x + d.width && p.y >= d.y && p.y <= d.y + d.height), 'Three actual classic LCD points are in front of overlays');
    assert.deepEqual([c.nativeCanvasWidth, c.nativeCanvasHeight], [W, H]);
    const actual = Buffer.from(c.nativeCanvasRgba, 'base64'); assert.equal(actual.length, SIZE); assert.deepEqual(actual, normalized(raw), 'Visible LCD canvas is exactly actual callback RGBA after native Canvas transparent-RGB normalization');
    const image = png(imageBytes(c, 'lcd', artifactDir)); assert.deepEqual([image.width, image.height], [W, H]); assert.deepEqual(image.rgba, actual, 'Original visible LCD PNG is the actual LCD readback, not an offscreen callback copy');
    assert.ok(Array.isArray(c.drawLog) && !c.drawLog.some(op => op.type === 'fillRect' || op.type === 'fillText' || op.type === 'drawImage' && op.src), 'Classic does not paint replacement artwork or typography');
}


export {sha,W,H,SIZE,bits,normalized,item,fnv,picture,movie,paint,counter,png,imageBytes,asset,verifyClassicCapture};
