import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
const input='build/r22-aid-runtime-oracle-v5.mjs',source=fs.readFileSync(input,'utf8');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
assert.equal(sha(source),'23726974ac1fa582e329b1ceeb45c926a52d52d6cd03bf6a162519e77d00f8fc');
const slice=(start,end)=>{const a=source.indexOf(start),b=source.indexOf(end,a+start.length);assert.ok(a>=0&&b>a);return source.slice(a,b);};
const pure=slice('const sha =','function nativeLabel(')+slice('function verifyClassicCapture(','/** Throws on missing/invalid evidence.');
let pixels=`/** R26 pure original LIB/PNG/timer decoding; no browser or engine interaction. */\nimport assert from 'node:assert/strict';\nimport crypto from 'node:crypto';\nimport fs from 'node:fs';\nimport path from 'node:path';\nimport {inflateSync} from 'node:zlib';\n`+pure;
const old=slice('function movie(lib) {','function paint(');
const next=old.replace('item(lib, 41)','item(lib, 40)').replace('fnv1a32:1d4637e9:1084','fnv1a32:bd0140e0:1084');
assert.notEqual(next,old);pixels=pixels.replace(old,next);
pixels+='\nexport {sha,W,H,SIZE,bits,normalized,item,fnv,picture,movie,paint,counter,png,imageBytes,asset,verifyClassicCapture};\n';
fs.writeFileSync('build/r26-liuyan-pixels-v1.mjs',pixels,{flag:'wx'});
let observer=slice('export const aidObserverSource =','const sha =');
for(const [a,b] of [['aidObserverSource','liuyanObserverSource'],['__aid','__liuyan'],['lastAid','lastLiuyan'],['Bounded aid','Bounded liuyan'],['aid capture:','liuyan capture:']])observer=observer.replaceAll(a,b);
observer=observer.replaceAll('spe.id === 41 && spe.kind === 2 && [17, 29].includes(spe.skillId)','spe.id === 40 && spe.kind === 2 && spe.skillId === 16');
observer=observer.replaceAll('result.speId === 41 && [17, 29].includes(result.skillId)','result.speId === 40 && result.skillId === 16');
const holdStart=observer.indexOf('            const holdKey ='),holdEnd=observer.indexOf('            if ((stage',holdStart);assert.ok(holdStart>0&&holdEnd>holdStart);
observer=observer.slice(0,holdStart)+'            const readback = false; // State-only movie has no numeric HOLD/readback.\n'+observer.slice(holdEnd);
observer=observer.replace('const held = new Set(), wrappedApis = new WeakSet();','const wrappedApis = new WeakSet();');
observer=observer.replace('const captures = [], samples = [], keys = [], errors = [];','const captures = [], samples = [], keys = [], errors = [], reports = [];\n    window.__liuyanReportObservations = reports;');
observer=observer.replace('fight: baye.hd.fight() });','fight: baye.hd.fight(), report: baye.hd.report(), attack: baye.hd.attack() });');
observer=observer.replace('ui });','ui, nativeReport:s.report });');
const tail=`
    // Observe the actual native notification before/after the production UI.
    // This wrapper forwards once and never sends a key, modifies timing or data.
    let dialog = null; const dialogs = new WeakSet();
    Object.defineProperty(window, 'BayeHdDialog', {configurable:true,get(){return dialog;},set(value){
        dialog=value; if(!value||dialogs.has(value))return;dialogs.add(value);
        const original=value.onEngineReport;if(typeof original!=='function')throw Error('Missing actual report observer callback');
        value.onEngineReport=function(){const before=snap();const result=original.apply(this,arguments);const after=snap();
            try{reports.push({at:performance.now(),stage:'native-report-callback',before,after,report:after&&after.report});if(reports.length>10000)throw Error('Bounded report observation capacity');}catch(e){errors.push(String(e));}return result;};
    }});
`;
const end="}.toString() + ')();';";assert.ok(observer.includes(end));observer=observer.replace(end,tail+end);
fs.writeFileSync('build/r26-liuyan-observer-v1.mjs','/** Read-only forwarding observer; injection is done only by an independently authorized future driver. */\n'+observer,{flag:'wx'});
const proof={scope:'Static extraction/adaptation only; no browser or actual Liuyan evidence',input:{path:input,sha256:sha(source)},pixels:{path:'build/r26-liuyan-pixels-v1.mjs',bytes:Buffer.byteLength(pixels),sha256:sha(pixels)},observer:{path:'build/r26-liuyan-observer-v1.mjs',bytes:fs.statSync('build/r26-liuyan-observer-v1.mjs').size,sha256:sha(fs.readFileSync('build/r26-liuyan-observer-v1.mjs'))},delta:['Exact pure decoder/counter/png/classic functions copied; movie resource/fingerprint41→40 only','Single forwarding observer retargeted40/16; HOLD branch removed','Adds read-only original report callback observation; preserves all raw callback RGBA/draw/keys/stamps']};
fs.writeFileSync('build/r26-liuyan-helper-extraction-proof-v1.json',JSON.stringify(proof,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(proof));
