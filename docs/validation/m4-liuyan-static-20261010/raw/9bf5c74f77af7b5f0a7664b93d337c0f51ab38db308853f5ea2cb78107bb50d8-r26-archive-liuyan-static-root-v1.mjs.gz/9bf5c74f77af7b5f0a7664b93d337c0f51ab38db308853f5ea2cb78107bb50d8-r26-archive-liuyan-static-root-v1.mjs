import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import zlib from 'node:zlib';
import {execFileSync} from 'node:child_process';
const dir='docs/validation/m4-liuyan-static-20261010';
const canonical=dir+'.json';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const ref=p=>{const b=fs.readFileSync(p);return {path:p.replaceAll('\\','/'),bytes:b.length,sha256:sha(b)};};
const write=(p,o)=>fs.writeFileSync(p,JSON.stringify(o,null,2)+'\n',{flag:'wx'});
assert.equal(fs.existsSync(canonical),false);
assert.equal(fs.existsSync(dir),false);
const full=JSON.parse(fs.readFileSync('build/r26-liuyan-full-source-tests-v1-execution.json'));
assert.equal(full.exitCode,0);assert.equal(full.summary.tests,full.summary.pass);assert.equal(full.summary.fail,0);assert.equal(full.summary.skipped,0);
assert.equal(full.sources.drift.length,0);assert.equal(full.sources.added.length,0);
const head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
assert.equal(head,'d241d7ba5abe3d853a22fb3ed0a9230836701527');
const spec=JSON.parse(fs.readFileSync('scripts/specs/hd-spe-liuyan.json'));
const publication=JSON.parse(fs.readFileSync('build/r26-liuyan-manifest-publication-root-v1.json'));
const previous=JSON.parse(execFileSync('git',['show','HEAD:assets/hd-spe/manifest.json'],{encoding:'utf8',maxBuffer:4e6}));
const manifest=JSON.parse(fs.readFileSync('assets/hd-spe/manifest.json'));
assert.equal(manifest.entries.length,50);assert.deepEqual(manifest.entries.slice(0,49),previous.entries);
const {entries:oldEntries,...oldTop}=previous,{entries:newEntries,...newTop}=manifest;assert.deepEqual(oldTop,newTop);
assert.equal(ref('assets/hd-spe/manifest.json').sha256,publication.after.sha256);
const provenance=ref('assets/hd-spe/GENERATED-LIUYAN.json');
const sources=['js/bridge.js','js/hd-spe.js','scripts/test-hd-spe.mjs','scripts/test-hd-liuyan-bridge.mjs','scripts/generate-hd-spe-liuyan-entry.mjs','scripts/specs/hd-spe-liuyan.json','scripts/hd-aid-native-test-fixture.mjs','package.json','pc.html','m.html','m-old.html','m-ges.html','m-ktouch.html','designer.html','hd-portrait-dump.html'];
const quad=['js/baye.js','js/baye.wasm','js/baye.wasm.map','js/baye.build.json'];
for(const p of quad)assert.deepEqual(fs.readFileSync(p),execFileSync('git',['show','HEAD:'+p],{maxBuffer:8e6}));
const pre=JSON.parse(fs.readFileSync(full.sources.pre.path));
for(const p of pre)assert.deepEqual(ref(p.path),p,'source changed after full regression: '+p.path);
const raw=[
 'build/r26-run-source-tests-root-v1.mjs',
 'build/r26-liuyan-full-source-tests-v1-execution.json','build/r26-liuyan-full-source-tests-v1.log',
 'build/r26-liuyan-full-source-tests-v1-sources-pre.json','build/r26-liuyan-full-source-tests-v1-sources-post.json',
 'build/r26-liuyan-focused-root-v1.log','build/r26-liuyan-bridge-focused-v1.log','build/r26-liuyan-bridge-focused-v2.log',
 'build/r26-liuyan-bridge-focused-v3.log','build/r26-liuyan-bridge-focused-v4.log','build/r26-liuyan-bridge-plus-existing-v1.log',
 'build/r26-liuyan-bridge-test-freeze-v1.json','build/r26-liuyan-render-contract-v1.json',
 'build/r26-liuyan-root-source-independent-review-v1.json','build/r26-liuyan-root-source-independent-review-v2.json',
 'build/r26-liuyan-manifest-before-v1.json','build/r26-liuyan-manifest-candidate-v1.json','build/r26-liuyan-manifest-publication-root-v1.json',
 'build/r26-publish-liuyan-manifest-root-v1.mjs','build/r26-register-liuyan-tests-root-v1.mjs',
 'build/r26-liuyan-runtime-plan-v1.json','build/r26-liuyan-runtime-plan-builder-v1.mjs',
 'build/r26-liuyan-runtime-draft-freeze-v1.json','build/r26-liuyan-pixels-v1.mjs','build/r26-liuyan-observer-v1.mjs',
 'build/r26-liuyan-runtime-oracle-v1.mjs','build/r26-liuyan-cast-fragment-v1.mjs',
 'build/r26-liuyan-helper-extraction-proof-v1.json','build/r26-make-liuyan-helpers-v1.mjs',
 'build/r26-copy-liuyan-chain-root-v1.mjs','build/r26-liuyan-chain-copy-proof-root-v1.json','build/r26-publish-liuyan-provenance-root-v1.mjs',
 'build/r26-archive-liuyan-static-root-v1.mjs',...sources,'assets/hd-spe/manifest.json',
 'build/r26-liuyan-art-chain-independent-audit-v1.json'
];
assert.equal(new Set(raw).size,raw.length);raw.forEach(p=>assert.ok(fs.existsSync(p),p));
fs.mkdirSync(dir+'/raw',{recursive:true});
const artifacts=raw.map(p=>{const bytes=fs.readFileSync(p),source=ref(p),target=dir+'/raw/'+source.sha256+'-'+path.basename(p)+'.gz';
 fs.writeFileSync(target,zlib.gzipSync(bytes,{level:9}),{flag:'wx'});assert.deepEqual(zlib.gunzipSync(fs.readFileSync(target)),bytes);
 return {source,archive:ref(target),encoding:'gzip',roundTripByteEqual:true};});
const index={schemaVersion:1,recordedAt:new Date().toISOString(),scope:'Bounded original LIUYAN static integration evidence. No browser execution. Runtime components are incomplete build-only drafts, not an executable or accepted player-cast driver.',
 sourceBaselineRevision:head,artifacts,roundTripVerified:true,originalFailureLogsPreserved:['build/r26-liuyan-bridge-focused-v1.log','build/r26-liuyan-bridge-focused-v2.log','build/r26-liuyan-bridge-focused-v3.log'],
 failureScope:'The first three offline bridge runs failed because of test expectations for inactive/numeric owner shapes; original failed logs remain unchanged. Final corrected fixture expectations passed. These are not browser failures or passes.',
 portableRuntimeReplayPackage:false,notIncluded:'Historical AID actual browser observations/save pairs referenced by runtime planning remain in their prior archive or local build paths. No claim of a self-contained executable runtime package.'};
write(dir+'/runtime-index.json',index);
const focusedLog=fs.readFileSync('build/r26-liuyan-focused-root-v1.log','utf8');assert.match(focusedLog,/^# tests 141$/m);assert.match(focusedLog,/^# pass 141$/m);assert.match(focusedLog,/^# fail 0$/m);
const record={schemaVersion:1,recordedAt:new Date().toISOString(),status:'static-integrated-player-cast-pending',sourceBaselineRevision:head,
 accepted:false,actualCastAccepted:false,hdAccepted:false,wholeHdAccepted:false,sourceChecksPassed:true,staticArtworkReviewed:true,browserExecuted:false,
 scope:'Original game only: state-only skill16 LIUYAN40 bridge, renderer, exact original selected artwork and cache updates. Offline VM and existing compiled-C full regression passed. No new native build or real skill16 casting was executed.',
 skill:{id:16,name:'流言',aim:0,target:'enemy',mp:20,state:1,armsPower:0,destroy:0},
 resource:{speId:40,resourceIndex:0,kind:2,bytes:1084,fingerprint:spec.nativeFingerprint,startFrm:0,endFrm:7,count:8,picmax:2,origin:[48,16],window:[64,64],lcd:[160,96],keyflag:0,compositionMode:2},
 movieResultContract:'A transient native SKILL scope exists during the movie. The zero-arms result has no NUM15 numeric postlude or hold; absence of digits does not imply absence of the movie result scope.',
 renderer:'Only the certified copied64 square is replaced; current/display tickets, real skill16 context, original LIB and resource identity, established coverage and no future bits are required. Outside pixels retain the current full LCD. Invalid/unknown/missing/classic paths retain the full160x96 LCD. Battle prewarm is gated by the exact valid LIUYAN entry.',
 manifest:{entries:50,previousEntries:49,allPreviousObjectsDeepEqual:true,topFieldsUnchanged:true,current:ref('assets/hd-spe/manifest.json'),publicationProof:ref('build/r26-liuyan-manifest-publication-root-v1.json')},
 artwork:{provenance,pictures:spec.pictureSources.map((p,i)=>{const r=ref(p);assert.equal(r.sha256,spec.pictureSha256[i]);return r;}),selectedAreExactRawOutputs:true,postprocessed:false,
 textReview:'Visual transcription of tiny native bubbles: 在那? and 河北. Native font exact-match attempt did not establish matching glyphs; no exact-font or semantic-script proof is claimed. Both rejected first-attempt PNGs and all prompts/requests/tool outputs/ordered references are retained in the artwork chain.'},
 sourceFiles:sources.map(ref),lineEndings:{scope:'sourceFiles and full-regression inventories hash the exact executed working bytes, retained in gzip for changed sources. Git may normalize text line endings. Stored-byte references below distinguish that representation; no runtime test is relabelled as executing those normalized bytes.',
  repositoryStoredSources:sources.map(p=>{const b=execFileSync('git',['show',':'+p],{maxBuffer:4e6});return {path:p,bytes:b.length,sha256:sha(b),byteEqualWorking:b.equals(fs.readFileSync(p))};})},
 installedEngine:{changed:false,rebuilt:false,files:quad.map(ref),build:JSON.parse(fs.readFileSync('js/baye.build.json')),scope:'Existing installed engine retained byte-for-byte from baseline; provenance sourceRevision/engineSourceModified are unchanged.'},
 cache:{engineAndWasmAndMap:'20261010c',bridgeSevenEntrances:'20261010d',pcHdSpe:'20261010d'},
 regression:{full:{execution:ref('build/r26-liuyan-full-source-tests-v1-execution.json'),...full.summary,modules:51,sourceCount:full.sources.count,sourceDrift:0,sourceAdded:0,executedOnce:true,scope:full.scope},
 focused:{log:ref('build/r26-liuyan-focused-root-v1.log'),tests:141,pass:141,fail:0,skipped:0,scope:'Offline controlled bridge/consumer VM. No separate source pre/post drift assertion was captured for this focused run.'},
 newTests:{bridge:47,consumer:12},oldFamilyCheck:{log:ref('build/r26-liuyan-bridge-plus-existing-v1.log'),tests:107,pass:107,scope:'47 LIUYAN + 38 AID + 22 WOOD bridge cases; offline VM only.'}},
 independentSourceReview:ref('build/r26-liuyan-root-source-independent-review-v2.json'),independentArtworkReview:ref('build/r26-liuyan-art-chain-independent-audit-v1.json'),
 runtimeDraft:{freeze:ref('build/r26-liuyan-runtime-draft-freeze-v1.json'),executableDriverAssembled:false,syntaxChecksOnly:4,offlineOracleSelfTestsExecuted:false,observerCompiled:false,finalTuplePreflightExecuted:false,browserExecuted:false,accepted:false},
 pending:['Real player enemy AIM and natural success','Actual MP20 decrement and state0 to confusion1','Native movie0..7 full-LCD oracle, HD64 square and exact outside pixels','One real confusion report and input ownership retirement','1080p/720p HD, classic, exact404, visibility and resize','WOOD6/7 actual casting and all other remaining full-HD scope'],
 archive:{index:ref(dir+'/runtime-index.json'),logicalOriginalArtifacts:artifacts.length,gzipRoundTripsVerified:true,portableClosedRuntimeArchive:false},
 evidenceBoundary:'Source/artwork/offline regression success is separate from player casting and browser HD acceptance. Prior AID and WOOD records retain their historical results and byte references. User game service and browser were not used or changed in this phase.'};
write(canonical,record);
console.log(JSON.stringify({record:ref(canonical),index:ref(dir+'/runtime-index.json'),artifacts:artifacts.length,full:record.regression.full}));
