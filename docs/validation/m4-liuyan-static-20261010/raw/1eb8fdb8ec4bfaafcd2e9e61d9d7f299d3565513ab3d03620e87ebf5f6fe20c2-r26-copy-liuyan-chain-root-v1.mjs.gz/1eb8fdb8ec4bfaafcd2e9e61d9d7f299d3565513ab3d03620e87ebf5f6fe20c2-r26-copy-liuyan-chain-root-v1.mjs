import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const mapping=[['build/r25-liuyan-40-art-v1','assets/hd-spe/liuyan-40/generation-v1'],['build/r25-liuyan-40-art-v2','assets/hd-spe/liuyan-40/generation-v2'],['build/r25-native-liuyan-40','assets/hd-spe/liuyan-40/native-source']];
const copied=[];
for(const [source,target] of mapping){
 assert.equal(fs.existsSync(target),false,'Do not overwrite earlier publication');fs.mkdirSync(target,{recursive:true});
 for(const entry of fs.readdirSync(source,{withFileTypes:true})){
  assert.equal(entry.isFile(),true);const src=path.posix.join(source,entry.name),dst=path.posix.join(target,entry.name),bytes=fs.readFileSync(src);
  fs.writeFileSync(dst,bytes,{flag:'wx'});assert.deepEqual(fs.readFileSync(dst),bytes);
  copied.push({source:src,target:dst,bytes:bytes.length,sha256:sha(bytes),byteEqual:true});
 }
}
for(let i=0;i<2;i++)assert.deepEqual(fs.readFileSync('assets/hd-spe/liuyan-40/picture-'+i+'.png'),fs.readFileSync('assets/hd-spe/liuyan-40/generation-v2/picture-'+i+'.png'));
const report={schemaVersion:1,recordedAt:new Date().toISOString(),scope:'Exact original artifact copies only, no raster editing/reencoding or runtime acceptance',mapping,copied,selectedExactlyEqualGenerationV2:true,allCopiesByteEqual:true};
fs.writeFileSync('build/r26-liuyan-chain-copy-proof-root-v1.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({copied:copied.length,bytes:copied.reduce((n,x)=>n+x.bytes,0),selectedByteEqual:true}));
