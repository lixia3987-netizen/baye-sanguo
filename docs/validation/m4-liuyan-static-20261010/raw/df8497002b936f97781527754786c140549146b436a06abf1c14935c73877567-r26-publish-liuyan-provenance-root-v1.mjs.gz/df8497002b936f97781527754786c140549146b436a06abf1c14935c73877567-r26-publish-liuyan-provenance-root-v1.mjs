import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const ref=p=>{const b=fs.readFileSync(p);return {path:p,bytes:b.length,sha256:sha(b)};};
const proof=JSON.parse(fs.readFileSync('build/r26-liuyan-chain-copy-proof-root-v1.json'));
assert.equal(proof.copied.length,30);const remap=new Map(proof.copied.map(p=>[p.source,p.target]));
for(const p of proof.copied){assert.deepEqual(fs.readFileSync(p.source),fs.readFileSync(p.target));assert.equal(ref(p.target).sha256,p.sha256);}
const read=p=>JSON.parse(fs.readFileSync(p));
const attempts=[];
for(const version of [1,2])for(const frame of [0,1]){
 const original='build/r25-liuyan-40-art-v'+version+'/',published='assets/hd-spe/liuyan-40/generation-v'+version+'/',request=read(original+'frame-'+frame+'-request.json');
 const orderedReferences=request.references.map((r,order)=>{const target=remap.get(r.path)||r.path,actual=ref(target);assert.equal(actual.bytes,r.bytes);assert.equal(actual.sha256,r.sha256);return {order,role:r.role,originalRequestPath:r.path,retained:actual};});
 assert.equal(request.request.referenced_image_paths.length,orderedReferences.length);
 attempts.push({version,frame,disposition:version===1?'rejected-text-qa-fail':'selected-static-artwork',
  image:ref(published+'picture-'+frame+'.png'),prompt:ref(published+'frame-'+frame+'-prompt.txt'),request:ref(published+'frame-'+frame+'-request.json'),
  toolResultAndReview:ref(published+'frame-'+frame+'-tool-result-and-review.json'),orderedReferences});
}
const native=read('build/r25-native-liuyan-40/metadata.json');
const selected=[0,1].map(frame=>{const file=ref('assets/hd-spe/liuyan-40/picture-'+frame+'.png'),source=ref('assets/hd-spe/liuyan-40/generation-v2/picture-'+frame+'.png');assert.deepEqual(fs.readFileSync(file.path),fs.readFileSync(source.path));return {frame,selected:file,rawGenerationOutput:source,byteEqual:true,width:1254,height:1254,colorType:2,opaque:true};});
const record={schemaVersion:1,recordedAt:new Date().toISOString(),scope:'Original LIUYAN40 static artwork generation and exact-copy provenance only. Source integration and offline tests are documented separately. Actual player casting/browser HD remain pending.',
 generator:{name:'Codex builtin image_gen.imagegen',skill:'C:/Users/75112/.codex/skills/.system/imagegen/SKILL.md',completedCalls:4,versions:2,callsPerVersion:2,selectedFinalOutputs:2,retainedRejectedOutputs:2,automaticRetries:false,paidCliOrExternalGenerator:false,postprocessing:'None. All PNG and original prompt/request/tool/review/native files copied byte-for-byte.'},
 library:native.library,resource:native.resource,nativeEvidence:ref('assets/hd-spe/liuyan-40/native-source/metadata.json'),
 selected,attempts,reviews:[ref('assets/hd-spe/liuyan-40/generation-v1/review.json'),ref('assets/hd-spe/liuyan-40/generation-v2/review.json')],
 originalArtifacts:proof.copied.map(p=>({originalBuildPath:p.source,retained:ref(p.target),byteEqual:true})),
 originalMetadataPreserved:'Retained original JSON/TXT files have not been rewritten. Historical absolute/build paths and review-time productionIntegrated=false fields remain their original historical values. originalArtifacts and orderedReferences above map these to retained repository paths.',
 textReview:{frames:['在那?','河北'],authority:'Root actual visual transcription of the tiny original reference, followed by actual visual review of the selected outputs.',fontMatchProven:false,
  exactFontComparison:ref('assets/hd-spe/liuyan-40/generation-v1/native-font-exact-comparison.json'),
  rejectedVersion1:['Frame0 bubble remained blank','Frame1 contained incorrect !!'],limits:'No claim of exact bitmap font matches, pixel-identical outside-bubble edits, or a newly recovered original script.'},
 staticArtworkAccepted:true,selectedByteEqualRawOriginals:true,actualCastAccepted:false,actualHdAccepted:false,wholeHdAccepted:false,
 nativeResultScope:'Skill16 has a transient SKILL movie scope but zero arms damage and no NUM15 numeric postlude/hold. This static art record does not validate actual MP/state/report or timing.',
 generationChainRetained:true,referenceHashesVerified:true,browserExecuted:false};
const target='assets/hd-spe/GENERATED-LIUYAN.json';fs.writeFileSync(target,JSON.stringify(record,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({provenance:ref(target),copied:proof.copied.length,attempts:attempts.length,selected:selected.length}));
