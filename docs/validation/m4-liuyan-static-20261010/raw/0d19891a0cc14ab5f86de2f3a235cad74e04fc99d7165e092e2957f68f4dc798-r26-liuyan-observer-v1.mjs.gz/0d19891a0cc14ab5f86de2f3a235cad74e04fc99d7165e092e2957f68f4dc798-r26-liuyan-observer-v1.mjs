/** Read-only forwarding observer; injection is done only by an independently authorized future driver. */
export const liuyanObserverSource = '(' + function () {
    const captures = [], samples = [], keys = [], errors = [], reports = [];
    window.__liuyanReportObservations = reports;
    window.__liuyanCaptures = window.__skillCaptures = captures;
    window.__liuyanSamples = window.__speSamples = samples;
    window.__liuyanEngineKeys = window.__speEngineKeys = keys;
    window.__liuyanObserverErrors = window.__speObserverErrors = errors;
    window.__spePhase = 'opening';
    let api = null, keyInstalled = false, last = null, drawLog = [];
    const wrappedApis = new WeakSet();
    const copy = v => JSON.parse(JSON.stringify(v));
    const b64 = bytes => { let s = ''; for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]); return btoa(s); };
    const snap = () => {
        try {
            if (!window.baye || !baye.hd || !baye.hd.ready()) return null;
            return copy({ spe: baye.hd.spe(), result: baye.hd.skillResult(), top: baye.hd.resultOwner(), fight: baye.hd.fight(), report: baye.hd.report(), attack: baye.hd.attack() });
        } catch (e) { errors.push('native snapshot: ' + String(e)); return null; }
    };
    for (const name of ['clearRect', 'drawImage', 'fillRect', 'fillText', 'rect', 'clip']) {
        const original = CanvasRenderingContext2D.prototype[name];
        CanvasRenderingContext2D.prototype[name] = function () {
            const result = original.apply(this, arguments);
            try {
                if (this.canvas && this.canvas.id === 'hd-spe-canvas') {
                    const args = Array.from(arguments);
                    if (name === 'clearRect' && args[0] === 0 && args[1] === 0 && args[2] === this.canvas.width && args[3] === this.canvas.height) drawLog = [];
                    const op = { type: name, args, fillStyle: this.fillStyle, font: this.font, globalAlpha: this.globalAlpha, composite: this.globalCompositeOperation };
                    if (name === 'drawImage') {
                        const source = args.shift(); op.src = source.src ? new URL(source.src, location.href).pathname.replace(/^\//, '') : null;
                        op.sourceKind = source.tagName || 'canvas'; op.sourceId = source.id || null;
                        op.naturalWidth = source.naturalWidth || source.width; op.naturalHeight = source.naturalHeight || source.height;
                    }
                    if (name === 'fillText') op.text = String(args.shift());
                    drawLog.push(op);
                }
            } catch (e) { errors.push('draw observer: ' + String(e)); }
            return result;
        };
    }
    function record(stage, img, width, height, callbackBefore, callbackAfter, rgbaBefore, rgbaAfter) {
        try {
            const s = snap(); if (!s) return;
            const spe = s.spe, result = s.result, ui = api && api.debugSnapshot(), now = performance.now();
            samples.push({ stage, at: now, phase: window.__spePhase, spe, result, top: s.top, fight: s.fight, ui, nativeReport:s.report });
            if (spe.active === 1 && spe.id === 40 && spe.kind === 2 && spe.skillId === 16) last = { generation: spe.generation, eventId: spe.eventId, skillId: spe.skillId, actorIndex: spe.actorIndex, targetIndex: spe.targetIndex };
            const nativeOwner = result.active === true && result.speId === 40 && result.skillId === 16;
            const readback = false; // State-only movie has no numeric HOLD/readback.
            if ((stage === 'lcd-flush' || readback) && img && (nativeOwner || last)) {
                const before = snap(), d = baye.data, native = document.createElement('canvas'), hd = document.getElementById('hd-spe-canvas'), lcd = document.getElementById('lcd');
                native.width = width || img.width; native.height = height || img.height;
                const raw = new Uint8ClampedArray(img.data); native.getContext('2d').putImageData(new ImageData(raw, native.width, native.height), 0, 0);
                const paletteReadback = Array.from({ length: 256 }, (_, i) => Number(d.g_paintPalette[i]) >>> 0), inverse = new Map();
                paletteReadback.forEach((v, i) => { const k = String(v); inverse.set(k, inverse.has(k) ? -1 : i); });
                const nativeIndices = [], ambiguousPixelCount = { value: 0 };
                for (let i = 0; i < raw.length; i += 4) {
                    const color = (raw[i] | raw[i + 1] << 8 | raw[i + 2] << 16 | raw[i + 3] << 24) >>> 0;
                    const index = inverse.has(String(color)) ? inverse.get(String(color)) : -1;
                    nativeIndices.push(index); if (index < 0) ambiguousPixelCount.value++;
                }
                const rect = ui && ui.sourceRect; let hdLogicalRgba = null;
                if (hd && ui.open && rect && hd.width === rect.width * ui.scale && hd.height === rect.height * ui.scale) {
                    const pixels = hd.getContext('2d').getImageData(0, 0, hd.width, hd.height).data, logical = [];
                    for (let y = 0; y < rect.height; y++) for (let x = 0; x < rect.width; x++) {
                        const p = (Math.floor((y + .5) * ui.scale) * hd.width + Math.floor((x + .5) * ui.scale)) * 4;
                        for (let ch = 0; ch < 4; ch++) logical.push(pixels[p + ch]);
                    }
                    hdLogicalRgba = b64(logical);
                }
                const node = document.getElementById('hd-spe'), r = hd && hd.getBoundingClientRect(), style = hd && getComputedStyle(hd), rootStyle = node && getComputedStyle(node);
                const top = r && document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2);
                const dom = r && { x: r.x, y: r.y, width: r.width, height: r.height, visible: !!(r.width && r.height && style.visibility === 'visible' && style.display !== 'none' && rootStyle.visibility === 'visible' && rootStyle.display !== 'none'), inViewport: r.x >= 0 && r.y >= 0 && r.right <= innerWidth + .5 && r.bottom <= innerHeight + .5, stackOwned: !!(top && node.contains(top)), cssBackground: style.backgroundColor, top: top && { id: top.id, className: top.className } };
                let lcdDom = null, nativeCanvasRgba = null, nativeCanvasUrl = null, nativeCanvasWidth = null, nativeCanvasHeight = null;
                if (lcd) {
                    const lr = lcd.getBoundingClientRect(), chain = []; let ancestor = lcd;
                    while (ancestor) { const cs = getComputedStyle(ancestor); chain.push({ id: ancestor.id, tag: ancestor.tagName, display: cs.display, visibility: cs.visibility, opacity: cs.opacity, cssBackground: cs.backgroundColor }); ancestor = ancestor.parentElement; }
                    const points = [[.5, .5], [.25, .35], [.75, .65]].map(([px, py]) => { const x = lr.x + lr.width * px, y = lr.y + lr.height * py, front = document.elementFromPoint(x, y); return { x, y, top: front && { id: front.id, tag: front.tagName, className: front.className }, canvasAtFront: front === lcd }; });
                    lcdDom = { x: lr.x, y: lr.y, width: lr.width, height: lr.height, viewport: { width: innerWidth, height: innerHeight }, chain, points, visible: !!(lr.width && lr.height && chain.every(v => v.display !== 'none' && v.visibility !== 'hidden' && v.visibility !== 'collapse' && Number(v.opacity) > 0)), inViewport: lr.x >= 0 && lr.y >= 0 && lr.right <= innerWidth + .5 && lr.bottom <= innerHeight + .5 };
                    nativeCanvasWidth = lcd.width; nativeCanvasHeight = lcd.height;
                    nativeCanvasRgba = b64(lcd.getContext('2d').getImageData(0, 0, lcd.width, lcd.height).data); nativeCanvasUrl = lcd.toDataURL('image/png');
                }
                const count = baye.getPersonCount(), units = Array.from({ length: 20 }, (_, i) => {
                    const id = Number(d.g_FgtParam.GenArray[i]); if (!id) return { i, id: 0 };
                    if (id < 1 || id > count) throw Error('Actual battle ID outside native count');
                    const p = d.g_Persons[id - 1], pos = d.g_GenPos[i];
                    return { i, id, personIndex: id - 1, x: Number(pos.x), y: Number(pos.y), state: Number(pos.state), hp: Number(pos.hp), mp: Number(pos.mp), active: Number(pos.active), arms: Number(p.Arms), level: Number(p.Level), experience: Number(p.Experience), iq: Number(p.IQ), armType: baye.hd.personArmType(id - 1) };
                });
                const nativeUrl = native.toDataURL('image/png'), hdUrl = hd && ui.open ? hd.toDataURL('image/png') : null, after = snap();
                captures.push({ stage: readback ? 'held-lcd-readback' : 'lcd-flush', rawSource: readback ? 'canvas-readback-normalized' : 'lcd-callback-image-data', at: now, phase: window.__spePhase, callbackBefore, callbackAfter, callbackRgbaBefore: rgbaBefore, callbackRgbaAfter: rgbaAfter, before, after, spe, result, top: s.top, fight: s.fight, ui, dom, lcdDom, nativeCanvasRgba, nativeCanvasUrl, nativeCanvasWidth, nativeCanvasHeight, lastLiuyan: last, units, hidden: document.hidden, mode: window.BayeHdBattle && BayeHdBattle.getMode(), drawing: { scale: Number(d.g_scale), flip: Number(d.g_FlipDrawing), paint: Number(d.g_paintColor), palette0: paletteReadback[0], palette255: paletteReadback[255] }, paletteReadback, nativeIndices, indexedSource: 'unique actual palette inverse of captured RGBA; -1 is ambiguous/unmapped, not a native surface read', ambiguousPixelCount: ambiguousPixelCount.value, nativeWidth: native.width, nativeHeight: native.height, nativeRgba: b64(raw), hdLogicalRgba, nativeUrl, hdUrl, drawLog: copy(drawLog) });
            }
            if (samples.length > 100000 || captures.length > 4000) throw Error('Bounded liuyan capture capacity exceeded');
        } catch (e) { errors.push('liuyan capture: ' + String(e)); }
    }
    Object.defineProperty(window, 'BayeHdSpe', { configurable: true, get() { return api; }, set(value) {
        api = value;
        if (!api || wrappedApis.has(api)) return;
        wrappedApis.add(api);
        for (const name of ['onEngineSpe', 'onLcdFlush']) {
            const original = api[name];
            api[name] = function () {
                const before = snap(), rgbaBefore = name === 'onLcdFlush' && arguments[0] ? b64(new Uint8ClampedArray(arguments[0].data)) : null;
                const result = original.apply(this, arguments);
                const after = snap(), rgbaAfter = name === 'onLcdFlush' && arguments[0] ? b64(new Uint8ClampedArray(arguments[0].data)) : null;
                record(name === 'onLcdFlush' ? 'lcd-flush' : 'lifecycle', name === 'onLcdFlush' ? arguments[0] : null, arguments[1], arguments[2], before, after, rgbaBefore, rgbaAfter);
                return result;
            };
        }
        if (!keyInstalled && typeof window.sendKey === 'function') {
            keyInstalled = true; const original = window.sendKey;
            window.sendKey = function (code) {
                const s = snap(); keys.push({ code, at: performance.now(), phase: window.__spePhase, generation: s && s.spe.generation, eventId: s && s.spe.eventId, kind: s && s.spe.kind, speId: s && s.spe.id, speActive: s && s.spe.active, resultActive: s && s.result.active, resultSession: s && s.result.session, resultPhase: s && s.result.phase, resultSpeId: s && s.result.speId });
                return original.apply(this, arguments);
            };
        }
    } });

    // Observe the actual native notification before/after the production UI.
    // This wrapper forwards once and never sends a key, modifies timing or data.
    let dialog = null; const dialogs = new WeakSet();
    Object.defineProperty(window, 'BayeHdDialog', {configurable:true,get(){return dialog;},set(value){
        dialog=value; if(!value||dialogs.has(value))return;dialogs.add(value);
        const original=value.onEngineReport;if(typeof original!=='function')throw Error('Missing actual report observer callback');
        value.onEngineReport=function(){const before=snap();const result=original.apply(this,arguments);const after=snap();
            try{reports.push({at:performance.now(),stage:'native-report-callback',before,after,report:after&&after.report});if(reports.length>10000)throw Error('Bounded report observation capacity');}catch(e){errors.push(String(e));}return result;};
    }});
}.toString() + ')();';

