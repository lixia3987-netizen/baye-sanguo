import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
const prefix='build/r26-liuyan-full-source-tests-v1';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const ref=p=>{const b=fs.readFileSync(p);return {path:p.replaceAll('\\','/'),bytes:b.length,sha256:sha(b)};};
const pkg=JSON.parse(fs.readFileSync('package.json')),modules=pkg.scripts.test.slice('node --test '.length).split(' ');
assert.ok(pkg.scripts.test.startsWith('node --test '));assert.equal(modules.length,51);assert.equal(new Set(modules).size,51);
const old=JSON.parse(fs.readFileSync('build/r21-route-actual-v19/source-verification.json'));
function paths(){const current=execFileSync('rg',['--files','scripts','js','css','assets/hd-overworld','assets/hd-spe'],{encoding:'utf8'}).trim().split(/\r?\n/);
return [...new Set([...old.sources.map(s=>s.source),...current,'package.json','index.html','pc.html','choose.html','loadlib.html','m.html','m-old.html','m-ges.html','m-ktouch.html','designer.html','hd-portrait-dump.html','online-save.html','build/r26-run-source-tests-root-v1.mjs'].map(p=>p.replaceAll('\\','/')))].sort();}
const files=paths(),pre=files.map(ref);fs.writeFileSync(prefix+'-sources-pre.json',JSON.stringify(pre,null,2)+'\n',{flag:'wx'});
const compiler='F:/project/baye-sanguo/build/toolchain/emsdk/upstream/bin/clang.exe';assert.ok(fs.existsSync(compiler));
const logPath=prefix+'.log',fd=fs.openSync(logPath,'wx'),command=[process.execPath,'--test','--test-reporter=tap','--test-concurrency=4',...modules],startedAt=new Date().toISOString();
const child=spawn(command[0],command.slice(1),{env:{...process.env,CC:compiler},stdio:['ignore',fd,fd],windowsHide:true});
const done=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('exit',(code,signal)=>resolve({code,signal}));});
fs.closeSync(fd);const finishedAt=new Date().toISOString(),postFiles=paths(),post=postFiles.map(ref);
fs.writeFileSync(prefix+'-sources-post.json',JSON.stringify(post,null,2)+'\n',{flag:'wx'});
const before=new Map(pre.map(p=>[p.path,p])),after=new Map(post.map(p=>[p.path,p])),drift=pre.filter(p=>JSON.stringify(p)!==JSON.stringify(after.get(p.path))),added=post.filter(p=>!before.has(p.path)),log=fs.readFileSync(logPath,'utf8'),summary={};
for(const key of ['tests','pass','fail','cancelled','skipped','todo']){const m=new RegExp('^# '+key+' (\\d+)\\s*$','m').exec(log);summary[key]=m?Number(m[1]):null;}
const report={schemaVersion:1,startedAt,finishedAt,command,node:process.version,compiler:ref(compiler),exitCode:done.code,signal:done.signal,summary,log:ref(logPath),sources:{count:pre.length,pre:ref(prefix+'-sources-pre.json'),post:ref(prefix+'-sources-post.json'),drift,added},executedOnce:true,scope:'Full current51-module regression after original state-only LIUYAN bridge/renderer, original selected art and cache changes. Offline VM and compiled C coverage only; actual skill16 player casting and browser HD remain separate and pending.'};
fs.writeFileSync(prefix+'-execution.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({exitCode:done.code,summary,sourceCount:pre.length,drift:drift.length,added:added.length,report:prefix+'-execution.json'}));
assert.equal(done.code,0);assert.equal(drift.length,0);assert.equal(added.length,0);assert.equal(summary.tests,summary.pass);assert.ok(summary.tests>1108);assert.equal(summary.fail,0);assert.equal(summary.skipped,0);
