/** Original skill16/SPE40 state-only oracle. Pure verification; never starts a browser or supplies inputs. */
import assert from 'node:assert/strict';
import {sha,W,H,SIZE,bits,normalized,item,fnv,movie,counter,png,imageBytes,asset,verifyClassicCapture} from './r26-liuyan-pixels-v1.mjs';
export {liuyanObserverSource} from './r26-liuyan-observer-v1.mjs';

export function liuyanSkill(library) {
 const row=item(library,10).subarray(15*34,16*34);
 const s={id:16,name:new TextDecoder('gbk',{fatal:true}).decode(item(library,11,15)),aim:row[0],state:row[1],power:row.readUInt16LE(2),destroy:row.readUInt16LE(4),useMp:row[6],weather:Array.from(row.subarray(7,12)),eland:Array.from(row.subarray(12,20)),oland:Array.from(row.subarray(20,28)),earm:Array.from(row.subarray(28,34)),recordHex:row.toString('hex')};
 assert.deepEqual([s.name,s.aim,s.state,s.power,s.destroy,s.useMp],['流言',0,1,0,0,20]);
 assert.deepEqual(s.weather,[100,100,100,100,0]);assert.deepEqual(s.oland,[100,100,100,100,100,100,100,0]);assert.ok(s.eland.every(x=>x===100));assert.ok(s.earm.every(x=>x===80));return s;
}
export function liuyanMessages(library,assets) {
 const header=asset(assets,'vendor/iBaye/src/data/pstring.h').toString('utf8').replace(/\/\*[\s\S]*?\*\//g,''), body=header.match(/enum\s*\{([\s\S]*?)\}/)[1], ids={};let next=0;
 for(const token of body.split(',')){const m=token.trim().match(/^(\w+)(?:\s*=\s*(\d+))?$/);if(m){next=m[2]?Number(m[2]):next+1;ids[m[1]]=next;}}
 const read=name=>{const raw=item(library,1,ids[name]-1),n=raw.indexOf(0),b=raw.subarray(0,n<0?raw.length:n);return {name,nativeItem:ids[name],bytes:Array.from(b),text:new TextDecoder('gbk',{fatal:true}).decode(b)};};
 const parts=[read('dFgtInSta'),read('dFgtState1'),read('dFgtState')];assert.deepEqual(parts.map(p=>p.text),[' 陷入了 ','混乱',' 状态']);return parts;
}
export function stateOnlyMetadata(r,actorIndex,targetIndex) {
 assert.ok(r && typeof r.active==='boolean');
 if(!r.active)return;
 assert.deepEqual([r.skillId,r.actorIndex,r.targetIndex,r.phase,r.resultKind,r.value,r.custom],[16,actorIndex,targetIndex,'movie',1,0,false],'State-only skill MOVIE/ARMS_LOSS/value0 metadata is not NUM or HOLD');
 assert.ok(Array.isArray(r.digits)&&r.digits.length===0);assert.ok(r.label&&!r.label.claimed&&!r.label.valid);
 assert.ok(r.display&&Array.isArray(r.display.digits)&&r.display.digits.length===0);assert.ok(r.display.label&&!r.display.label.claimed&&!r.display.label.valid);
}
export function validateAttempt(a,s) {
 assert.ok(a&&a.succeeded===true&&a.skill?.id===16&&a.actor&&a.target&&a.before&&a.after&&a.proof&&a.confirmation);
 const actor=a.actor.i,target=a.target.i,p=a.proof;
 assert.ok(Number.isInteger(actor)&&actor>=0&&actor<10&&Number.isInteger(target)&&target>=10&&target<20,'Actual player caster and actual opposite-side enemy');
 assert.equal(a.actor.id,189);assert.ok(a.target.id>0&&a.target.id<=200);
 assert.deepEqual(a.skill,s);
 assert.deepEqual([p.fight.active,p.fight.over,p.fight.wait,p.fight.inputKind,p.fight.aimType,p.fight.actorIndex],[1,0,1,5,1,actor]);
 assert.equal(a.confirmation.ok,true);assert.deepEqual([a.confirmation.kind,a.confirmation.inputSeq],[5,p.fight.inputSeq]);
 assert.deepEqual([p.casterId,p.targetId,p.x,p.y],[189,a.target.id,a.target.x,a.target.y]);
 assert.ok(p.weather>=1&&p.weather<=5&&s.weather[p.weather-1]>0);assert.ok(p.casterTerrain>=0&&p.casterTerrain<8&&s.oland[p.casterTerrain]>0);assert.ok(p.terrain>=0&&p.terrain<8&&s.eland[p.terrain]>0);assert.ok(p.arm>=0&&p.arm<6&&s.earm[p.arm]>0);
 assert.ok(p.state!==1&&p.state!==8,'Selected enemy must produce an observed new confusion state');
 assert.ok(Number.isInteger(p.size)&&p.size>0&&p.size<=15&&Array.isArray(p.values)&&p.values.length===p.size*p.size&&p.values.every(v=>Number.isInteger(v)&&v>=0&&v<=255));
 const x=(p.x-p.originX)&255,y=(p.y-p.originY)&255;assert.ok(x<p.size&&y<p.size);assert.equal(p.values[y*p.size+x],1);
 assert.ok(Array.isArray(a.keys));assert.equal(a.keys.filter(k=>k.code===39).length,1);assert.ok(a.keys.every(k=>[34,35,36,37,39].includes(k.code)));
 const ab=a.before.units.find(u=>u.i===actor),aa=a.after.units.find(u=>u.i===actor),tb=a.before.units.find(u=>u.i===target),ta=a.after.units.find(u=>u.i===target);
 assert.ok(ab&&aa&&tb&&ta);assert.deepEqual([ab.id,aa.id,tb.id,ta.id],[189,189,a.target.id,a.target.id]);assert.equal(aa.mp,ab.mp-20);assert.equal(tb.state,p.state);assert.equal(ta.state,1);assert.equal(ta.arms,tb.arms);assert.deepEqual(a.after.food,a.before.food,'No power/destroy mutation or enemy turn is hidden inside the cast');
 assert.ok(Array.isArray(a.movieEvents)&&a.movieEvents.length===1,'One successful single-target movie event');return {actorIndex:actor,targetIndex:target};
}
function draws(c,e,entry) {
 const scale=c.ui.scale, actual=c.drawLog.filter(o=>o.type==='fillRect'||o.type==='fillText'||o.type==='drawImage'&&o.src);
 assert.ok(actual.every(o=>o.type==='drawImage'),'No label, NUM or invented typography in state-only scene');
 const frames=bits(Array.from(e.visible));assert.equal(actual.length,frames.length);
 for(let i=0;i<frames.length;i++){const p=entry.pictures[frames[i]%2],o=actual[i];assert.equal(o.src,p.src);assert.deepEqual(o.args,[48*scale,16*scale,64*scale,64*scale]);assert.deepEqual([o.naturalWidth,o.naturalHeight],[p.width,p.height]);}
 assert.deepEqual(c.drawLog.filter(o=>o.type==='rect').map(o=>o.args),[[48*scale,16*scale,64*scale,64*scale]]);
 assert.deepEqual(c.drawLog.filter(o=>o.type==='clearRect').map(o=>o.args),[[0,0,W*scale,H*scale],[48*scale,16*scale,64*scale,64*scale],...bits(Array.from(e.clears)).map(()=>[48*scale,16*scale,64*scale,64*scale])]);
}
function artReadback(c,hdImage,art,expected) {
 const live=bits(Array.from(expected.visible));if(!live.length)return 0;const a=art[live.at(-1)%2],scale=c.ui.scale;let checked=0;
 for(const [fx,fy]of [[.2,.25],[.5,.5],[.8,.75]]){const x=48+Math.floor(64*fx),y=16+Math.floor(64*fy),dest=(Math.floor((y+.5)*scale)*hdImage.width+Math.floor((x+.5)*scale))*4,sx=(x-48+.5)*a.width/64-.5,sy=(y-16+.5)*a.height/64-.5;
  for(let ch=0;ch<3;ch++){const nearby=[];for(let yy=Math.floor(sy)-1;yy<=Math.floor(sy)+2;yy++)for(let xx=Math.floor(sx)-1;xx<=Math.floor(sx)+2;xx++)if(xx>=0&&yy>=0&&xx<a.width&&yy<a.height)nearby.push(a.rgba[(yy*a.width+xx)*4+ch]);const n=hdImage.rgba[dest+ch];assert.ok(n>=Math.min(...nearby)-3&&n<=Math.max(...nearby)+3,'Actual original opaque image source neighbourhood');}assert.equal(hdImage.rgba[dest+3],255);checked++;
 }return checked;
}
/** The positive path requires actual callbacks/owners/inputs/world/report evidence.
 * Offline counter/selftests cannot synthesize accepted real attempts. */
export function verifyLiuyanCaptures(report,{library,assets,artifactDir,allowLcd=false,expectClassic=false,expectMissing=false}={}) {
 assert.ok(!expectClassic&&!expectMissing||allowLcd);assert.ok(Buffer.isBuffer(library));assert.equal(sha(library),'3bd20146084054163d045c90987c756a6a210664e78253cc56bc4a274727903e');
 const skill=liuyanSkill(library),m=movie(library),records=counter(m,7),manifest=JSON.parse(asset(assets,'assets/hd-spe/manifest.json'));
 const entry=manifest.entries.find(e=>e.kind===2&&e.speId===40&&e.resourceIndex===0&&e.startFrm===0&&e.endFrm===7);
 assert.equal(manifest.libSha256,sha(library));assert.ok(entry);assert.deepEqual([entry.liuyanVersion,entry.opaqueCoverageVersion,entry.skillId,entry.count,entry.picmax],[1,1,16,8,2]);assert.equal(entry.skillIds,undefined);assert.equal(entry.skillResultVersion,undefined);assert.equal(entry.skillNumber,undefined);assert.equal(entry.resourceFingerprint,m.fingerprint);assert.equal(entry.resourceLength,m.length);
 assert.deepEqual(entry.units.map(u=>[u.frame,u.x,u.y,u.picIndex]),m.units.map((u,i)=>[i,u.x,u.y,u.picIndex]));
 const art=entry.pictures.map(p=>{assert.deepEqual([p.nativeWidth,p.nativeHeight,p.logicalWidth,p.logicalHeight,p.mask],[64,64,64,64,0]);const b=asset(assets,p.src),im=png(b);assert.deepEqual([im.width,im.height],[p.width,p.height]);for(let i=3;i<im.rgba.length;i+=4)assert.equal(im.rgba[i],255);return{...im,src:p.src,sha256:sha(b)};});assert.equal(art.length,2);
 const attempts=report.liuyanAttempts?.filter(a=>a.succeeded===true);assert.ok(attempts&&attempts.length);assert.deepEqual(report.observerErrors,[]);assert.ok(Array.isArray(report.engineInputs)&&Array.isArray(report.speObservations)&&Array.isArray(report.liuyanCaptures)&&report.liuyanCaptures.length);
 const verified=[],families=[];
 for(const a of attempts){const {actorIndex,targetIndex}=validateAttempt(a,skill),event=a.movieEvents[0],selected=report.liuyanCaptures.filter(c=>c.stage==='lcd-flush'&&c.spe?.active===1&&c.spe.id===40&&c.spe.kind===2&&c.spe.skillId===16&&c.spe.actorIndex===actorIndex&&c.spe.targetIndex===targetIndex&&c.spe.eventId===event&&c.spe.display?.frameValid);
  assert.ok(selected.length,'Actual selected native movie callback RGBA required');let outside=null,palette=null,hd=0;const commits=new Set(),frames=new Set();
  for(const c of selected){assert.deepEqual(c.before,c.after);assert.deepEqual(c.callbackBefore,c.callbackAfter);assert.equal(c.rawSource,'lcd-callback-image-data');assert.equal(c.callbackRgbaBefore,c.callbackRgbaAfter);assert.equal(c.nativeRgba,c.callbackRgbaBefore);assert.deepEqual([c.nativeWidth,c.nativeHeight],[W,H]);
   const s=c.spe,d=s.display,current=s,e=records[d.commitSeq-1],future=records[current.commitSeq-1];assert.ok(e&&future);assert.deepEqual([s.id,s.resourceIndex,s.count,s.picmax,s.startFrm,s.endFrm,s.x,s.y,s.keyflag,s.contextKnown,s.protocolValid],[40,0,8,2,0,7,48,16,0,true,true]);assert.equal(s.resourceFingerprint,m.fingerprint);assert.equal(s.resourceLength,m.length);assert.equal(s.skipEligible,false);assert.equal(s.generation,d.generation);assert.equal(d.eventId,event);assert.ok(d.commitSeq>0&&d.commitSeq<=current.commitSeq);
   assert.deepEqual([d.composition.protocolVersion,d.composition.valid,d.composition.mode,d.composition.x,d.composition.y,d.composition.width,d.composition.height],[1,true,2,48,16,64,64]);assert.deepEqual([current.composition.protocolVersion,current.composition.valid,current.composition.mode,current.composition.x,current.composition.y,current.composition.width,current.composition.height],[1,true,2,48,16,64,64]);
   assert.equal(d.frameIndex,e.frame);assert.equal(current.frameIndex,future.frame);assert.deepEqual(Buffer.from(d.visibleFrames),e.visible);assert.deepEqual(Buffer.from(d.composition.clearFrames),e.clears);assert.deepEqual(Buffer.from(current.visibleFrames),future.visible);assert.deepEqual(Buffer.from(current.composition.clearFrames),future.clears);bits(d.visibleFrames);bits(d.composition.clearFrames);stateOnlyMetadata(c.result,actorIndex,targetIndex);
   assert.deepEqual([c.drawing.scale,c.drawing.flip,c.drawing.paint,c.drawing.palette0,c.drawing.palette255],[1,0,255,0x00ffffff,0xff000000]);assert.ok(Array.isArray(c.paletteReadback)&&c.paletteReadback.length===256&&c.paletteReadback.every(n=>Number.isInteger(n)&&n>=0&&n<=0xffffffff));const raw=Buffer.from(c.nativeRgba,'base64');assert.equal(raw.length,SIZE);
   assert.ok(Array.isArray(c.nativeIndices)&&c.nativeIndices.length===W*H&&c.indexedSource.includes('not a native surface read'));const inverse=new Map();c.paletteReadback.forEach((v,i)=>inverse.set(v,inverse.has(v)?-1:i));let ambiguous=0;for(let p=0;p<W*H;p++){const v=raw.readUInt32LE(p*4),n=inverse.has(v)?inverse.get(v):-1;assert.equal(c.nativeIndices[p],n);if(n<0)ambiguous++;}assert.equal(c.ambiguousPixelCount,ambiguous);
   if(!outside){outside=Buffer.from(raw);palette=c.paletteReadback;}assert.deepEqual(c.paletteReadback,palette);const expected=Buffer.from(outside);for(let y=16;y<80;y++)for(let x=48;x<112;x++)expected.writeUInt32LE(palette[e.pixels[y*W+x]],(y*W+x)*4);assert.deepEqual(raw,expected,'Every actual160x96 native pixel equals original ROM timer history plus actual outside LCD');
   const nativePng=png(imageBytes(c,'native',artifactDir));assert.deepEqual([nativePng.width,nativePng.height],[W,H]);assert.deepEqual(normalized(nativePng.rgba),normalized(raw));
   if(expectClassic)verifyClassicCapture(c,raw,artifactDir);
   else{assert.ok(c.ui.open&&c.dom?.visible&&c.dom.inViewport&&c.dom.stackOwned&&!c.hidden);assert.deepEqual(c.ui.sourceRect,{x:0,y:0,width:W,height:H});assert.equal(c.ui.skipVisible,false);const scale=c.ui.scale;assert.ok(Number.isInteger(scale)&&scale>=1);const shown=Buffer.from(c.hdLogicalRgba,'base64'),image=png(imageBytes(c,'hd',artifactDir));assert.equal(shown.length,SIZE);assert.deepEqual([image.width,image.height],[W*scale,H*scale]);const native=normalized(raw);
    for(let y=0;y<H;y++)for(let x=0;x<W;x++){const at=(y*W+x)*4,p=(Math.floor((y+.5)*scale)*image.width+Math.floor((x+.5)*scale))*4;assert.deepEqual(shown.subarray(at,at+4),image.rgba.subarray(p,p+4));}
    if(expectMissing){assert.equal(c.ui.source,'lcd');assert.ok(!c.drawLog.some(o=>o.type==='fillRect'||o.type==='fillText'||o.type==='drawImage'&&o.src));}
    if(c.ui.source==='hd-assets'){assert.ok(!expectMissing);hd++;assert.equal(c.ui.outsideSource,'lcd');assert.deepEqual(c.ui.hdRegion,{x:48,y:16,width:64,height:64});draws(c,e,entry);assert.ok(artReadback(c,image,art,e)>0||bits(Array.from(e.visible)).length===0);
     for(let py=0;py<image.height;py++)for(let px=0;px<image.width;px++){const x=Math.floor(px/scale),y=Math.floor(py/scale);if(x>=48&&x<112&&y>=16&&y<80)continue;const at=(py*image.width+px)*4,n=(y*W+x)*4;assert.deepEqual(image.rgba.subarray(at,at+4),native.subarray(n,n+4),'Every actual physical pixel outside64 is exact nearest native LCD');}
    }else{assert.ok(allowLcd);assert.equal(c.ui.source,'lcd');assert.deepEqual(shown,native);}
   }
   commits.add(d.commitSeq);frames.add(d.frameIndex);verified.push({at:c.at,skillId:16,eventId:event,generation:s.generation,commitSeq:d.commitSeq,currentCommitSeq:s.commitSeq,displayLagsCurrent:d.commitSeq<s.commitSeq,frameIndex:d.frameIndex,visible:bits(d.visibleFrames),clear:bits(d.composition.clearFrames),source:expectClassic?'classic-lcd':c.ui.source,nativeRgbaSha256:sha(raw),expectedSha256:sha(expected),nativeFile:c.nativeFile,hdFile:expectClassic?null:c.hdFile,lcdFile:c.lcdFile||null});
  }
  assert.deepEqual([...commits].sort((x,y)=>x-y),[1,2,3,4,5,6,7,8]);assert.deepEqual([...frames].sort((x,y)=>x-y),[0,1,2,3,4,5,6,7]);
  const samples=report.speObservations.filter(c=>c.spe?.eventId===event&&c.spe.generation===a.proof.generation&&c.spe.kind===2&&c.spe.skillId===16);assert.ok(samples.length);for(const c of samples)stateOnlyMetadata(c.result,actorIndex,targetIndex);
  const blocked=report.engineInputs.filter(k=>(k.eventId===event&&k.generation===a.proof.generation&&k.speActive)||(k.resultActive&&k.resultSession===selected[0].result.session));assert.deepEqual(blocked,[],'No key while this real movie/result owns execution');
  const parts=liuyanMessages(library,assets),expectedText=a.target.name+parts.map(p=>p.text).join(''),actualReports=(report.reportObservations||[]).filter(r=>r.report?.active===1&&r.report.kind===1&&r.report.person===65535&&r.report.text===expectedText&&r.before?.spe.generation===a.proof.generation&&r.at>=selected[0].at&&r.at<=a.finishedAt);
  assert.ok(actualReports.length,'Real original status MSGBOX observed after movie scope, not invented after retirement');for(const r of actualReports){assert.deepEqual(r.before,r.after);assert.equal(r.after.spe.active,0);assert.equal(r.after.result.active,false);assert.equal(r.after.top.active,false);}
  const acknowledgements=(a.reports||[]).filter(r=>r.native?.text===expectedText);for(const r of acknowledgements){assert.equal(r.native.active,1);assert.equal(r.owner.seq,r.native.seq);assert.equal(r.owner.inputSeq,r.native.inputSeq);assert.deepEqual(r.keys.map(k=>k.code),[39]);}
  families.push({skillId:16,eventId:event,actorIndex,targetIndex,nativeCallbacks:selected.length,frames:[...frames],hdReadbacks:hd,mpCost:20,targetStateBefore:a.target.state,targetStateAfter:1,reportedText:expectedText,statusReports:actualReports.length,reportAcknowledgements:acknowledgements.length,numericReadbacks:0,holdReadbacks:0});
 }
 assert.ok(report.liuyanRetired);assert.equal(report.liuyanRetired.spe.active,0);assert.equal(report.liuyanRetired.result.active,false);assert.equal(report.liuyanRetired.top.active,false);assert.equal(report.liuyanRetired.ui.open,false);
 return {schemaVersion:1,ok:true,scope:'Actual player skill16 state1/movie40 original fullLCD/64window/outsideLCD/report/retirement only',hdAccepted:!allowLcd,fallbackAccepted:!!expectClassic||!!expectMissing,families,verified,actualCallbacks:verified.length,noNumbers:true,noHold:true};
}

export function selfTestLiuyanOracle({library,assets}) {
 const s=liuyanSkill(library),m=movie(library),records=counter(m,7),tests=[];assert.equal(records.length,8);assert.deepEqual(records.map(r=>r.frame),[0,1,2,3,4,5,6,7]);assert.deepEqual(bits(Array.from(records[7].clears)),[0,1,2,3,4,5,6]);tests.push('actual ROM all8 timer copies/last7/clear0..6');
 assert.throws(()=>bits(Buffer.alloc(32)));assert.throws(()=>bits(Array(31).fill(0)));tests.push('public bitset must be complete actual Array');
 const label={claimed:false,valid:false},r={active:true,skillId:16,actorIndex:0,targetIndex:10,phase:'movie',resultKind:1,value:0,custom:false,digits:[],label,display:{digits:[],label}};stateOnlyMetadata(r,0,10);
 for(const mutation of [{phase:'numbers'},{phase:'hold'},{resultKind:2},{value:1},{custom:true},{digits:[{}]},{label:{claimed:true,valid:true}},{display:{digits:[{}],label}}])assert.throws(()=>stateOnlyMetadata({...r,...mutation},0,10));tests.push('MOVIE metadata only; eight NUM/HOLD/gain/label/custom negatives');
 assert.deepEqual(s.oland,[100,100,100,100,100,100,100,0]);assert.deepEqual(s.earm,[80,80,80,80,80,80]);liuyanMessages(library,assets);tests.push('correct native packed eland/oland/earm and original report GBK');
 assert.throws(()=>verifyLiuyanCaptures({liuyanAttempts:[]},{library,assets}));tests.push('no actual evidence cannot be accepted');
 return {ok:true,scope:'Pure offline original ROM/schema negative checks only; no actual scene acceptance',checks:tests,accepted:false};
}
