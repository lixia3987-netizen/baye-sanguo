const fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),out=path.join(root,'build/r15-water-native'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
fs.mkdirSync(out,{recursive:true});
const lib=fs.readFileSync(path.join(root,'libs/dat-mod.lib'));
if(sha(lib)!=='3bd20146084054163d045c90987c756a6a210664e78253cc56bc4a274727903e')throw Error('Wrong actual LIB');
const address=lib.readUInt32LE(35*4),payload=lib.subarray(address+14,address+lib.readUInt32LE(address));
if(payload.length!==1084||sha(payload)!=='d606f81b597b3596a197273e87064edac201634a0cf3f838a78c00beb4b9f75a')throw Error('Wrong WATER36 bytes');
const crcTable=Array.from({length:256},(_,n)=>{for(let i=0;i<8;i++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
function chunk(type,data){const name=Buffer.from(type),size=Buffer.alloc(4),crc=Buffer.alloc(4);size.writeUInt32BE(data.length);let c=0xffffffff;for(const n of Buffer.concat([name,data]))c=crcTable[(c^n)&255]^(c>>>8);crc.writeUInt32BE((c^0xffffffff)>>>0);return Buffer.concat([size,name,data,crc]);}
function png(width,height,rgb){const head=Buffer.alloc(13);head.writeUInt32BE(width);head.writeUInt32BE(height,4);head[8]=8;head[9]=2;const rows=Buffer.alloc(height*(width*3+1));for(let y=0;y<height;y++)rgb.copy(rows,y*(width*3+1)+1,y*width*3,(y+1)*width*3);return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',head),chunk('IDAT',zlib.deflateSync(rows)),chunk('IEND',Buffer.alloc(0))]);}
let offset=6+payload[2]*5;const pictures=[];
for(let p=0;p<payload[3];p++){
 const width=payload.readUInt16LE(offset),height=payload.readUInt16LE(offset+2),count=payload.readUInt16LE(offset+4),mask=payload[offset+6],rowBytes=Math.ceil(width/8),bits=payload.subarray(offset+7,offset+7+rowBytes*height);
 if(width!==64||height!==64||count!==1||mask!==0||bits.length!==512)throw Error('Wrong native picture geometry');
 const references=[];
 for(const scale of [1,8]){
  const w=width*scale,h=height*scale,rgb=Buffer.alloc(w*h*3);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const nativeX=Math.floor(x/scale),nativeY=Math.floor(y/scale),gray=(bits[nativeY*rowBytes+(nativeX>>3)]&(128>>(nativeX&7)))?0:255;rgb.fill(gray,(y*w+x)*3,(y*w+x+1)*3);}
  const filename=path.join(out,`WATER36-picture-${p}${scale===1?'':'-packed-cells-x8'}.png`),bytes=png(w,h,rgb);fs.writeFileSync(filename,bytes);
  references.push({path:filename,bytes:bytes.length,sha256:sha(bytes),width:w,height:h,source:'Fresh native packed-bit decode, MSB-first bit1 black0; bit0 opaque white255. Scale8 redraws each native bit as a diagnostic cell, not a resized AI image.'});
 }
 pictures.push({index:p,width,height,count,mask,offset,packedBitsSha256:sha(bits),references});offset+=7+rowBytes*height;
}
if(offset!==payload.length)throw Error('Unexpected trailing bytes');
const metadata={head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),library:{path:'libs/dat-mod.lib',bytes:lib.length,sha256:sha(lib)},resource:36,item:0,payloadSha256:sha(payload),pictures};
fs.writeFileSync(path.join(out,'reference-source.json'),JSON.stringify(metadata,null,2)+'\n');console.log(JSON.stringify({ok:true,pictures:pictures.map(p=>p.references)}));
