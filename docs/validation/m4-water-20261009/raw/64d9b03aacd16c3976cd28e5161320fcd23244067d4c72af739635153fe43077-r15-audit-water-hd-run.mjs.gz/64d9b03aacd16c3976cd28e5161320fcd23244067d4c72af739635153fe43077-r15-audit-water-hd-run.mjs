import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import assert from 'node:assert/strict';

const root = process.cwd();
const dir = path.join(root, 'build/r15-water-hd-installed-v1');
const report = JSON.parse(fs.readFileSync(path.join(dir, 'result.json')));
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const file = filename => {
    const abs = path.isAbsolute(filename) ? filename : path.join(root, filename);
    const bytes = fs.readFileSync(abs);
    return { source: path.relative(root, abs).replaceAll('\\', '/'), bytes: bytes.length, sha256: sha(bytes) };
};
const normalized = buffer => {
    const out = Buffer.from(buffer);
    for (let i = 0; i < out.length; i += 4) if (out[i + 3] === 0) out[i] = out[i + 1] = out[i + 2] = 0;
    return out;
};
function decodeRgbaPng(bytes) {
    assert.equal(bytes.subarray(0, 8).toString('hex'), '89504e470d0a1a0a');
    let width, height, bitDepth, colourType, interlace;
    const compressed = [];
    for (let p = 8; p < bytes.length;) {
        const size = bytes.readUInt32BE(p), type = bytes.toString('ascii', p + 4, p + 8);
        const chunk = bytes.subarray(p + 8, p + 8 + size);
        assert.equal(chunk.length, size);
        if (type === 'IHDR') {
            width = chunk.readUInt32BE(0); height = chunk.readUInt32BE(4);
            bitDepth = chunk[8]; colourType = chunk[9]; interlace = chunk[12];
        }
        if (type === 'IDAT') compressed.push(chunk);
        p += size + 12;
        if (type === 'IEND') break;
    }
    assert.equal(bitDepth, 8); assert.equal(colourType, 6); assert.equal(interlace, 0);
    const decoded = zlib.inflateSync(Buffer.concat(compressed));
    const rowBytes = width * 4, rgba = Buffer.alloc(rowBytes * height);
    assert.equal(decoded.length, height * (rowBytes + 1));
    const paeth = (a, b, c) => {
        const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
        return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
    };
    for (let y = 0; y < height; y++) {
        const filter = decoded[y * (rowBytes + 1)], source = y * (rowBytes + 1) + 1, dest = y * rowBytes;
        assert.ok(filter <= 4);
        for (let x = 0; x < rowBytes; x++) {
            const left = x >= 4 ? rgba[dest + x - 4] : 0;
            const up = y ? rgba[dest + x - rowBytes] : 0;
            const upLeft = y && x >= 4 ? rgba[dest + x - rowBytes - 4] : 0;
            const predictor = filter === 0 ? 0 : filter === 1 ? left : filter === 2 ? up : filter === 3 ? Math.floor((left + up) / 2) : paeth(left, up, upLeft);
            rgba[dest + x] = (decoded[source + x] + predictor) & 255;
        }
    }
    return { width, height, rgba };
}

assert.equal(report.ok, true); assert.equal(report.hdAccepted, true);
assert.equal(report.allowLcd, false); assert.equal(report.baselineOnly, false);
assert.equal(report.preflightOnly, false); assert.equal(report.staged, false);
assert.equal(report.tool.sha256, 'c5a444a4a3a38e1c5318880bf731438d313782e3d7a686576b8132d9096eb510');
assert.equal(report.sourceVerification.ok, true); assert.equal(report.sourceVerification.count, 1145);
assert.equal(report.nativeSourceCheck.aggregate, '56b01e4becf3c06e6b4cc154dfa6585e37a2c9aa91cd3ada744420c72228e02f');
const freshSources = Object.entries(report.sources).map(([name, expected]) => {
    const actual = file(expected.source);
    return { name, ...actual, match: actual.bytes === expected.bytes && actual.sha256 === expected.sha256 };
});
assert.equal(freshSources.length, 1145); assert.ok(freshSources.every(s => s.match));
const runner = file(report.tool.source); assert.equal(runner.sha256, report.tool.sha256);
const backup = path.join(root, 'build/r15-water-runtime-final-c5a444.mjs');
if (fs.existsSync(backup)) assert.equal(sha(fs.readFileSync(backup)), runner.sha256);
else fs.copyFileSync(path.join(root, report.tool.source), backup);

const attempt = report.waterAttempts.find(a => a.succeeded);
assert.ok(attempt); assert.equal(report.waterAttempts.length, 1);
const unit = (state, id) => state.units.find(u => u.id === id);
const casterBefore = unit(attempt.before, 15), casterAfter = unit(attempt.after, 15);
const targetBefore = unit(attempt.before, 18), targetAfter = unit(attempt.after, 18);
assert.equal(attempt.actor.id, 15); assert.equal(attempt.actor.personIndex, 14);
assert.equal(casterBefore.side, 'player'); assert.equal(casterBefore.armType, 3);
assert.equal(targetBefore.side, 'enemy'); assert.equal(targetBefore.terrain, 7);
assert.ok(Math.max(Math.abs(casterBefore.x - targetBefore.x), Math.abs(casterBefore.y - targetBefore.y)) === 1);
assert.equal(casterBefore.mp - casterAfter.mp, 20);
assert.equal(targetBefore.arms - targetAfter.arms, 400);
assert.equal(attempt.before.weather, 4); assert.equal(targetBefore.armType, 3);
assert.equal(attempt.proof.terrain, 7); assert.equal(attempt.proof.targetId, 18);
assert.equal(attempt.confirmation.ok, true); assert.equal(attempt.confirmation.kind, 5);
assert.equal(attempt.before.nativeMapId, 115);

const oracle = report.nativePixelOracle, verified = oracle.verified;
assert.equal(verified.length, 29); assert.equal(oracle.actualLcdCallbacks, 28);
assert.equal(oracle.movieReadbacks, 8); assert.equal(oracle.postReadbacks, 21);
assert.equal(oracle.movieHd, 8); assert.equal(oracle.postHd, 21);
assert.equal(oracle.numericReadbacks, 20); assert.equal(oracle.completedHoldReadbacks, 1);
const captureByName = new Map(report.skillCaptures.map(c => [c.nativeFile.file, c]));
const readbacks = verified.map(v => {
    const c = captureByName.get(v.nativeFile.file); assert.ok(c);
    const raw = Buffer.from(c.nativeRgba, 'base64'); assert.equal(raw.length, 160 * 96 * 4);
    assert.equal(sha(raw), v.nativeRgbaSha256);
    assert.equal(v.nativeRgbaSha256, v.independentExpectedSha256);
    assert.equal(c.result.active, true); assert.equal(c.top.valid, true);
    assert.equal(c.top.kind, 2); assert.equal(c.top.session, c.result.session);
    assert.equal(c.result.actorIndex, casterBefore.i); assert.equal(c.result.targetIndex, targetBefore.i);
    assert.equal(c.result.skillId, 12); assert.equal(c.ui.source, 'hd-assets');
    assert.equal(c.result.skipEligible, false); assert.equal(c.result.returnEligible, false);
    assert.ok(c.dom.visible && c.dom.inViewport && c.dom.stackOwned);
    assert.deepEqual(c.callbackBefore, c.callbackAfter);
    const nativeMetadata = file(path.join(dir, c.nativeFile.file));
    const hdMetadata = file(path.join(dir, c.hdFile.file));
    assert.equal(nativeMetadata.sha256, c.nativeFile.sha256); assert.equal(nativeMetadata.bytes, c.nativeFile.bytes);
    assert.equal(hdMetadata.sha256, c.hdFile.sha256); assert.equal(hdMetadata.bytes, c.hdFile.bytes);
    const decoded = decodeRgbaPng(fs.readFileSync(path.join(dir, c.nativeFile.file)));
    assert.deepEqual([decoded.width, decoded.height], [160, 96]);
    assert.deepEqual(normalized(decoded.rgba), normalized(raw));
    if (v.phase !== 'movie') {
        assert.equal(c.ui.presentation, 'skill-postlude'); assert.equal(c.ui.outsideSource, 'lcd');
        assert.deepEqual(c.ui.sourceRect, { x: 15, y: 16, width: 130, height: 64 });
        assert.equal(c.ui.hdRegion.mode, 2);
        assert.deepEqual([c.ui.hdRegion.x, c.ui.hdRegion.y, c.ui.hdRegion.width, c.ui.hdRegion.height], [48, 16, 64, 64]);
        assert.equal(c.result.value, 400); assert.equal(c.result.label.text, '兵力减少');
    }
    return { ...v, nativeFile: nativeMetadata, hdFile: hdMetadata, pngCanonicalRgbaSha256: sha(normalized(decoded.rgba)), pngMatchesRecordedActualRawRgba: true };
});
assert.deepEqual(readbacks.filter(v => v.phase === 'movie').map(v => v.frameIndex), [0, 1, 2, 3, 4, 5, 6, 7]);
const hold = report.skillCaptures.find(c => c.stage === 'held-lcd-readback');
assert.ok(hold); assert.equal(hold.result.phase, 'hold');
assert.deepEqual(hold.result.display.digits.map(d => d.digit), [4, 0, 0]);
assert.deepEqual(hold.result.display.digits.map(d => [d.x, d.y, d.firstY, d.drawCount]), [[55, 49, 56, 8], [61, 49, 56, 8], [67, 49, 56, 8]]);
const firstAt = report.skillCaptures[0].at, holdAt = hold.at;
const duringInputs = report.engineInputs.filter(k => k.at >= firstAt && k.at <= holdAt);
assert.equal(duringInputs.length, 0);
const retired = report.skillCaptures.slice(-2);
assert.ok(retired.every(c => !c.result.active && !c.top.active && c.ui.source === 'lcd'));

const pngs = fs.readdirSync(dir).filter(n => n.endsWith('.png')).sort().map(n => {
    const bytes = fs.readFileSync(path.join(dir, n));
    return { ...file(path.join(dir, n)), width: bytes.readUInt32BE(16), height: bytes.readUInt32BE(20) };
});
for (const c of report.skillCaptures) {
    for (const metadata of [c.nativeFile, c.hdFile].filter(Boolean)) {
        const actual = file(path.join(dir, metadata.file));
        assert.equal(actual.sha256, metadata.sha256); assert.equal(actual.bytes, metadata.bytes);
    }
    const originalNative = decodeRgbaPng(fs.readFileSync(path.join(dir, c.nativeFile.file)));
    const recordedNative = Buffer.from(c.nativeRgba, 'base64');
    assert.deepEqual([originalNative.width, originalNative.height], [160, 96]);
    assert.deepEqual(normalized(originalNative.rgba), normalized(recordedNative));
}
const viewed = [
    ['water-000-movie-hd.png', 'Actual first native-frame HD layer; one helmeted soldier within water, complete scene rectangle, no label/number covering the movie. Neutral dark margins belong to the stage.'],
    ['water-001-movie-hd.png', 'Actual alternating second slot: soldier displaced right through water; complete head/helmet and water panel with no edge cutout defect. Artistic interpretation rather than native monochrome pixel equivalence.'],
    ['water-027-numbers-hd.png', 'Actual completed 400 is legible and the Chinese label is complete. The stepped gold tail comes from preserved eight-pose native opaque history, not extra damage or native font equality.'],
    ['water-028-hold-hd.png', 'Actual held frame equals last number frame by PNG SHA. Visible 400 and label remain readable inside the 64x64 HD window; perimeter is actual native LCD.'],
    ['water-000-movie-lcd.png', 'Original transparent LCD export opened without modification. Black native ink on the viewer dark transparency background is difficult to judge visually; raw pixel and PNG decode checks provide the detailed source proof.'],
    ['water-001-movie-lcd.png', 'Original second native slot export opened. No HD canvas is called native; exact source pixels are checked separately.'],
    ['water-027-numbers-lcd.png', 'Original native final-number export opened; source alpha is retained. Native NUM15 shapes/history are verified by raw pixel oracle rather than assuming HD glyph equivalence.'],
    ['water-028-hold-lcd.png', 'Original held LCD export opened; byte-identical to last native numbers PNG.'],
    ['water12-real-movie-numeric-result.png', 'Actual post-action battle view shows WangLang MP46 and ChenYing troops400, while caster remains800. The overlay has retired and the map remains usable.']
].map(([name, observation]) => ({ ...file(path.join(dir, name)), tool: 'view_image', viewedOriginalFile: true, observation }));
const cleanup = JSON.parse(fs.readFileSync(path.join(dir, 'cleanup-verification.json'))); assert.equal(cleanup.ok, true);
const recruitment = report.recruitment;
const output = {
    schema: 'r15-water-installed-independent-audit-v1', checkedAt: new Date().toISOString(), ok: true,
    run: { startedAt: report.startedAt, finishedAt: report.finishedAt, result: file(path.join(dir, 'result.json')), console: file('build/r15-water-hd-installed-v1-console.log'), exitCode: 0, phases: report.phases.length, phaseNames: report.phases.map(p => p.name), rawCaptures: report.skillCaptures.length, oracleReadbacks: verified.length, pngs: pngs.length, uniquePngs: new Set(pngs.map(p => p.sha256)).size, exceptions: report.exceptions.length, dialogs: report.dialogs.length, observerErrors: report.observerErrors.length, nativeInputs: report.engineInputs.length },
    source: { runner, exactPostRunSourceBackup: file(backup), backupTiming: 'Created after the completed run; SHA equals startup and post-run frozen runner SHA. Not claimed as a pre-execution saved copy.', sourceVerification: file(path.join(dir, 'source-verification.json')), count: freshSources.length, allFreshFileShaAndBytesMatch: freshSources.every(s => s.match), drift: report.sourceVerification.drift, added: report.sourceVerification.added, native128Aggregate: report.nativeSourceCheck.aggregate, actualLoadedLib: report.actualLib, selected: freshSources.filter(s => ['baye.js','baye.wasm','baye.wasm.map','baye.build.json','assets/hd-spe/manifest.json','pc.html','js/hd-spe.js','docs/validation/m4-water-20261009/route-plan.json','docs/validation/m4-water-20261009/resource-plan.json'].includes(s.name)) },
    route: { period: report.period, lord: report.selectedLord, origin: report.originCity, destination: report.destination, casterPerson: report.casterPerson, marchPeople: report.marchPersonIds, orderReceipt: report.marchOrderReceipt, destinationReceipt: report.battleDestinationReceipt },
    recruitment: { requestedArms: recruitment.requestedArms, recruiterPerson: recruitment.recruiter.personIndex, actualQtyMax: recruitment.quantity.initial.max, enlisted: recruitment.quantity.wanted, distributed: recruitment.distribution.wanted, moneyBefore: recruitment.before.money, moneyAfter: recruitment.equipped.money, reserveAfter: recruitment.equipped.reserve, boundedActualInputAndReceiptsRecorded: true },
    cast: { attempts: report.waterAttempts.length, actorBefore: casterBefore, actorAfter: casterAfter, targetBefore, targetAfter, weather: attempt.before.weather, mpSpent: casterBefore.mp - casterAfter.mp, actualDamage: targetBefore.arms - targetAfter.arms, playerConfirmation: attempt.confirmation, proof: attempt.proof, movieEvents: attempt.movieEvents, reports: attempt.reports, noEngineKeysDuringMovieAndNumericHold: duringInputs.length === 0, nativeOwnerRetired: retired.every(c => !c.result.active && !c.top.active), sourceRetiredToLcd: true },
    oracle: { ...Object.fromEntries(Object.entries(oracle).filter(([k]) => k !== 'verified')), readbacks, allNativePngsDecoded: report.skillCaptures.length, oracleNativePngs: verified.length, retiredNativePngs: retired.length, auditMethod: 'Fresh file SHA/byte checks, decoding and unfiltering all31 original 160x96 PNGs, comparing decoded canonical pixels to actual recorded callback/hold RGBA; the29 authorized movie/postlude readbacks additionally match their independently computed runtime oracle hashes. The2 retired LCD files are not counted as HD or effect oracle acceptance. This audit does not claim a second independent LIB renderer; the runtime retains its full ROM/font/NUM oracle and raw facts.' },
    displayScope: { movie: 'Only actual native picture slots are HD. Neutral stage outside the effect window is not authenticated full battle arena art.', postlude: '64x64 HD window at48,16; outside is actual native LCD within the130x64 arena crop.', native: 'Entire160x96 raw callback pixels checked by runtime ROM/font/NUM oracle.', artistic: 'HD soldier and water are an artistic interpretation; HD glyphs are fitted to6px native advance but are not native pixel-equal.' },
    visualReview: { count: viewed.length, files: viewed, materialFinding: null },
    cleanup: { metadata: file(path.join(dir, 'cleanup-verification.json')), ...cleanup }, pngs,
    notClaimed: ['Other skills or custom hooks', 'Whole arena HD replacement', 'Mobile or performance acceptance', 'Any success from enemy-triggered water events', 'Repair of the prior LiHui route death', 'All native glyphs visually readable on a black transparency viewer'],
    priorFailurePreserved: { result: file('build/r15-water-lcd-cast-v1/result.json'), candidate: file('build/r15-water-runtime-candidate-original.mjs'), noReplayOrOverwrite: true }
};
assert.equal(output.run.exceptions, 0); assert.equal(output.run.dialogs, 0); assert.equal(output.run.observerErrors, 0);
fs.writeFileSync(path.join(dir, 'runtime-validation-audit.json'), JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify({ ok: output.ok, phases: output.run.phases, rawCaptures: output.run.rawCaptures, oracleReadbacks: output.run.oracleReadbacks, actualLcdCallbacks: oracle.actualLcdCallbacks, hdMovie: oracle.movieHd, hdPost: oracle.postHd, pngs: output.run.pngs, uniquePngs: output.run.uniquePngs, sources: freshSources.length, audit: file(path.join(dir, 'runtime-validation-audit.json')) }));
