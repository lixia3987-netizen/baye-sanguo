const fs=require('fs'),path=require('path'),crypto=require('crypto'),zlib=require('zlib'),assert=require('assert/strict');
const read=p=>fs.readFileSync(p),json=p=>JSON.parse(read(p).toString('utf8').replace(/^\uFEFF/,'')),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const [runDir,...failedDirs]=process.argv.slice(2),run=json(runDir+'/result.json');
assert.ok(run.ok&&run.accepted&&run.previewAccepted&&run.previewOnly&&run.cleanup.treeExited&&run.serverClosed);
assert.equal(run.previewChecks.length,2);assert.ok(run.previewChecks.every(v=>v.accepted));assert.deepEqual(run.sourceDrift,[]);assert.deepEqual(run.exceptions,[]);assert.equal(run.nativeTouches.length,0);
for(const ref of run.sourceFiles){const b=read(ref.path);assert.equal(b.length,ref.bytes);assert.equal(sha(b),ref.sha256);}
const suite='build/mobile-preview-suite-v2-20261011.log',suiteText=read(suite).toString('utf8');
const count=k=>Number(suiteText.match(new RegExp('(?:ℹ|#) '+k+' (\\d+)'))?.[1]);
assert.ok(count('tests')>=2423);assert.equal(count('pass'),count('tests'));for(const k of ['fail','cancelled','skipped','todo'])assert.equal(count(k),0);
const base='docs/validation/m5-mobile-preview-20261011',rawDir=base+'/raw';assert.ok(!fs.existsSync(base+'.json'));fs.mkdirSync(rawDir,{recursive:true});
const files=new Set(),add=p=>{assert.ok(fs.existsSync(p),'Missing evidence '+p);files.add(p.replaceAll('\\','/'));};
for(const dir of [runDir,...failedDirs]){
  const r=json(dir+'/result.json');for(const name of ['result.json','executed-tool.mjs','source-verification.json','owned-process-samples.jsonl'])add(dir+'/'+name);
  add(dir.replace(/-20261011$/,'')+'-cli-20261011.log');
  for(const file of fs.readdirSync(dir).filter(v=>v.endsWith('.png')&&(/preview-.*(?:-preview|-all-properties|-map)\.png$/.test(v)||/^failure.*\.png$/.test(v))))add(dir+'/'+file);
  assert.ok(r.cleanup.treeExited&&r.serverClosed,'Every retained run reached terminal owned cleanup');
}
for(const name of fs.readdirSync('build').filter(v=>/^mobile-preview-focused-.*\.log$/.test(v)||/^hd-mobile-preview-runtime-checks-failed-.*\.mjs$/.test(v)||/^mobile-preview-old-source-.*\.(?:js|log)$/.test(v)))add('build/'+name);
const repairedFreeze=json('build/mobile-preview-product-freeze-v2.json');
for(const ref of [...repairedFreeze.evidence,repairedFreeze.delta]){const b=read(ref.path);assert.equal(b.length,ref.bytes);assert.equal(sha(b),ref.sha256);add(ref.path);}
for(const p of [suite,'build/mobile-preview-suite-20261011.log','build/mobile-preview-product-freeze-v1.json','build/mobile-preview-product-freeze-v2.json','build/mobile-preview-runtime-source-audit-v1-20261011.txt',
  'build/mobile-preview-before-city-source.js','build/mobile-preview-old-source-negative-test.mjs','build/mobile-preview-old-source-negative-v1-20261011.log',
  'build/mobile-preview-cancel-old-source-negative-test-v1.mjs','build/mobile-preview-cancel-old-source-negative-v1-20261011.log',
  'build/mobile-preview-product-source-audit-v1-20261011.txt','build/mobile-preview-presentation-source-audit-v1-20261011.txt',
  'build/mobile-preview-independent-audit-20261011.txt','build/mobile-preview-user-service-before-20261011.json','build/mobile-preview-user-service-after-20261011.json',
  'build/mobile-preview-owned-historical-after-20261011.json','build/mobile-preview-owned-history-input-20261011.json',
  'build/check-mobile-preview-cleanup-20261011.ps1','build/prepare-mobile-preview-history-20261011.cjs','build/archive-mobile-preview-20261011.cjs','build/mobile-preview-cleanup-proof-20261011.log',
  'scripts/hd-mobile-preview-runtime-checks.mjs','scripts/test-hd-mobile-city-runtime.mjs','scripts/test-hd-city-mobile-host.mjs',
  'js/hd-city-menu.js','css/hd-mobile.css','m.html','pc.html','package.json'])add(p);
for(const name of fs.readdirSync('build/mobile-preview-product-v1-source-20261011'))add('build/mobile-preview-product-v1-source-20261011/'+name);
const originals=[];let index=0;for(const file of files){const b=read(file),compressed=zlib.gzipSync(b,{level:9});assert.deepEqual(zlib.gunzipSync(compressed),b);
  const target=rawDir+'/'+String(++index).padStart(3,'0')+'-'+path.basename(file)+'.gz';fs.writeFileSync(target,compressed,{flag:'wx'});
  originals.push({original:file,bytes:b.length,sha256:sha(b),archive:target,archiveBytes:compressed.length,archiveSha256:sha(compressed),roundTripExact:true});}
const before=json('build/mobile-preview-user-service-before-20261011.json'),after=json('build/mobile-preview-user-service-after-20261011.json'),history=json('build/mobile-preview-owned-historical-after-20261011.json');
assert.deepEqual(after.identities,before.identities);assert.equal(before.httpStatus,200);assert.equal(after.httpStatus,200);assert.ok(history.rows.every(v=>!v.exactIdentityPresent));
const flows=run.previewChecks.map(f=>({label:f.label,cityIndex:f.cityIndex,accepted:f.accepted,viewport:f.baseline.state.viewport,
  previews:f.checks.filter(v=>v.kind==='preview').map(v=>({menuKind:v.menuKind,id:v.personOrTool,index:v.index,keys:v.keys.map(k=>k.code)})),
  pages:f.checks.filter(v=>v.kind==='property-page').length,visibleCurrentCells:f.checks.filter(v=>v.kind==='visible-current-property').length,
  complete:f.checks.filter(v=>v.kind==='complete-properties').map(v=>({kind:v.menuKind,person:v.attributes.person,tool:v.attributes.tool,count:v.attributes.propertyCount})),
  negative:f.checks.filter(v=>v.kind.startsWith('negative-')).map(v=>v.kind),trustedPans:f.scrollChecks.length,
  goodsPerson:f.goodsEntry.personId,goodsIds:f.goodsEntry.after.state.menu.ids,newPersonSeq:f.returnedPerson.state.menu.seq,
  returnedHud:f.returned.state.hud,expectedHud:f.returned.state.expected}));
const summary={schemaVersion:1,date:'2026-10-11',accepted:true,scope:run.scope,fullHdAccepted:false,realDeviceAccepted:false,wholeNativeAbiAccepted:false,nativeBuildChanged:false,
  runtime:{directory:runDir,phases:run.phases.length,nativeKeys:run.nativeKeys.length,nativeLcdTouches:run.nativeTouches.length,sourceFiles:run.sourceFiles.length,
    sourceDrift:run.sourceDrift,exceptions:run.exceptions,cleanup:run.cleanup.treeExited,serverClosed:run.serverClosed},
  flows,tests:{modules:72,tests:count('tests'),pass:count('pass'),fail:0,cancelled:0,skipped:0,todo:0,log:suite},
  failedRuns:failedDirs.map(d=>({directory:d,accepted:json(d+'/result.json').accepted,error:json(d+'/result.json').error})),
  userService:{before,after,unchanged:true},ownedHistoricalRows:history.rows.length,portableClosedArchive:false,
  limits:['Desktop Chrome touch/landscape emulation, not real mobile hardware','Only recorded world fields, not whole native memory',
    'No confiscation or granting commitment: actual actor selection opens equipped goods; goods confirmation is never sent',
    'No strategy month, battle, succession, save-load, zero recruitment, full order queue or performance acceptance',
    'Selected original evidence is archived; browser profiles, other screenshots and full source/binary trees are not a standalone replay package'],
  archive:{originalCount:originals.length,originalBytes:originals.reduce((s,v)=>s+v.bytes,0),archiveBytes:originals.reduce((s,v)=>s+v.archiveBytes,0),originals}};
fs.writeFileSync(base+'.json',JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
const lines=['# 原版移动 HD 人物与道具资料浏览','',
  '日期：2026-10-11。限定本机 Chrome 手机横屏模拟，实际原版 libs/dat-mod.lib。完整 HD、真实设备与完整原生 ABI 继续待验。','',
  '## 修改','',
  '- 普通人物和道具列表增加独立“查看”按钮，原选择按钮保持确认行为。查看只发送原生焦点方向键，当前项查看不发键；资料始终跟随原生高亮与当前身份。',
  '- 旧按钮、取消手势、竞争窗口、隐藏、经典、换库和队列退休不能继续旧查看；不同人物／道具的资料回到顶部，同身份轮询与显式属性翻页保留滚动。',
  '- 道具取消只发送一次EXIT，等真实完整新人物名单及原人物身份到齐后恢复；等待期阻止其它输入，超时或所有者变化时不补按键。',
  '- 手机人物属性页控件置于属性段顶部，道具翻页控件固定在资料下边；名单与资料分别滚动，触控按钮至少44 CSS像素。PC界面保持。','',
  '## 实际运行','',
  `共 ${run.phases.length} 检查点、${run.nativeKeys.length} 次原生按键、0次LCD触摸，${run.sourceFiles.length} 份来源无漂移、无未捕获异常。`,
  '', '| 视口 | 人物与道具 | 显式属性翻页 | 当前页实际可见单元 | 可信滚动 |', '|---|---|---:|---:|---:|',
  ...flows.map(f=>`| ${f.viewport.join('×')} | 董卓／吕布；方天画戟／赤兔 | ${f.pages} | ${f.visibleCurrentCells} | ${f.trustedPans} |`),'',
  '各尺寸通过原版洛阳内政搜寻查看不同人物，逐页读取吕布13列；正常没收菜单明确选择吕布后进入真实装备名单，分别查看方天画戟和赤兔的5列属性，不确认道具。每次查看只核精确UP／DOWN，显式翻页只核单次LEFT／RIGHT；原生所有者、当前人物／道具ID、页范围及HD逐行文字相同。每个当前页单元都通过真实滚动露出，记录祖先裁切及命中；道具取消返回新的完整人物名单，再逐层回地图及核HUD。',
  '', '每条浏览及滚动世界采样保持一致，包括200人物的装备、38城池已采字段及Tools／ToolQueue、完整道具队列原值与发现位、33项道具原始资源字段、人物队列、订单和战斗人员。只证明这些已采字段，不扩大为完整原生内存。',
  '', `最终72模块 ${count('pass')}/${count('tests')} 通过，失败／取消／跳过／todo均0，修复后专项449/449通过；修复前420/420专项与2423/2423全量是历史范围，最新产品以v2冻结及修复后日志为准。没有改动native源码或更新既有引擎构建来源。`,
  '', '## 证据与边界','',
  '前两次实测分别因验证脚本浏览器侧变量引用错误、未扣除自有固定翻页栏的实际遮挡范围失败。第三次严格取消门揭示产品缺陷：原生已回人物名单，HD却退上层并显示经典画面。本批修复该真实返回衔接后重新冻结、全量回归并完整重跑两尺寸；错误helper、旧产品源和完整失败结果保留，不把失败记录改写为通过。实际可见仍同时要求祖先裁切、自有固定栏裁切与物理命中。',
  '', `自有Chrome树与私服退出，${history.rows.length} 个历史记录身份均已消失；用户8080服务前后身份与启动时间一致、HTTP200。`,
  '', `见[结构化记录](m5-mobile-preview-20261011.json)。${originals.length} 份原件以长度及SHA-256归档，gzip解压逐字节一致；这是选择性证据归档，不是独立完整重放包。`,
  '', '未验本批实际没收／赏赐提交、完整库存流转、战果／继任／存读档、其它时期或真实手机、安全区与性能。原版唯一入口及暂时移除版本切换的范围保持，完整HD仍partial。',''];
fs.writeFileSync(base+'.md',lines.join('\n'),{flag:'wx'});console.log(JSON.stringify({base,files:originals.length,bytes:summary.archive.originalBytes,gzip:summary.archive.archiveBytes,tests:summary.tests,phases:run.phases.length,flows}));
