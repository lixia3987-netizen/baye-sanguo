const fs = require('fs');
const assert = require('assert/strict');
const folders = process.argv.slice(2);
assert.ok(folders.length >= 4);
const identities = new Map();
for (const folder of folders) {
  const run = JSON.parse(fs.readFileSync(folder + '/result.json', 'utf8').replace(/^\uFEFF/, ''));
  assert.equal(run.cleanup.treeExited, true, folder);
  assert.equal(run.serverClosed, true, folder);
  assert.ok(run.historicalRecordedIdentities.length > 0, folder);
  for (const identity of run.historicalRecordedIdentities) {
    const {ProcessId, CreationDate, ExecutablePath} = identity;
    assert.ok(ProcessId && CreationDate && ExecutablePath);
    identities.set(JSON.stringify([ProcessId, CreationDate, ExecutablePath]), {ProcessId, CreationDate, ExecutablePath});
  }
}
const output = {cleanup: {treeExited: true}, serverClosed: true, runs: folders,
  historicalRecordedIdentities: [...identities.values()]};
fs.writeFileSync('build/mobile-preview-owned-history-input-20261011.json', JSON.stringify(output, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify({runs: folders.length, identities: identities.size}));
