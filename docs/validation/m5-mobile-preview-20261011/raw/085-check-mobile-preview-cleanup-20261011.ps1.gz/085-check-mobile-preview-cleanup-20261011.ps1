param([Parameter(Mandatory=$true)][string]$ArtifactRelative)
$ErrorActionPreference = 'Stop'
$hdPreviewResult = Get-Content -LiteralPath 'build/mobile-preview-owned-history-input-20261011.json' -Encoding UTF8 -Raw | ConvertFrom-Json
if (-not $hdPreviewResult.cleanup.treeExited -or -not $hdPreviewResult.serverClosed) { throw 'Runtime cleanup is not terminal and accepted' }
$hdPreviewLive = @(Get-CimInstance Win32_Process)
$hdPreviewRows = @($hdPreviewResult.historicalRecordedIdentities | ForEach-Object {
    $hdPreviewRecorded = $_
    $hdPreviewCurrent = @($hdPreviewLive | Where-Object { $_.ProcessId -eq $hdPreviewRecorded.ProcessId })
    $hdPreviewBirth = if ($hdPreviewRecorded.CreationDate -is [datetime]) { $hdPreviewRecorded.CreationDate.ToUniversalTime() } else { [datetime]::Parse($hdPreviewRecorded.CreationDate).ToUniversalTime() }
    $hdPreviewExact = @($hdPreviewCurrent | Where-Object { $_.CreationDate.ToUniversalTime().Ticks -eq $hdPreviewBirth.Ticks -and $_.ExecutablePath -eq $hdPreviewRecorded.ExecutablePath })
    [ordered]@{ProcessId=$hdPreviewRecorded.ProcessId;CreationDateUtc=$hdPreviewBirth.ToString('o');ExecutablePath=$hdPreviewRecorded.ExecutablePath;currentPidPresent=($hdPreviewCurrent.Count -gt 0);exactIdentityPresent=($hdPreviewExact.Count -gt 0)}
})
[ordered]@{checkedAt=(Get-Date).ToUniversalTime().ToString('o');runtime=$ArtifactRelative;comparison='PID, executable path and exact UTC DateTime ticks';rows=$hdPreviewRows} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath 'build/mobile-preview-owned-historical-after-20261011.json' -Encoding utf8
if (@($hdPreviewRows | Where-Object { $_.exactIdentityPresent }).Count -ne 0) { throw 'An exact recorded owned browser identity still exists' }
$hdPreviewServicePids = @(Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
$hdPreviewServiceIdentities = @($hdPreviewServicePids | ForEach-Object { Get-CimInstance Win32_Process -Filter "ProcessId = $_" | Select-Object ProcessId, ExecutablePath, @{Name='CreationDateUtc';Expression={$_.CreationDate.ToUniversalTime().ToString('o')}} })
$hdPreviewServiceHttp = (Invoke-WebRequest -Uri 'http://localhost:8080/' -UseBasicParsing).StatusCode
[ordered]@{checkedAt=(Get-Date).ToUniversalTime().ToString('o');listenPort=8080;identities=$hdPreviewServiceIdentities;httpStatus=$hdPreviewServiceHttp} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath 'build/mobile-preview-user-service-after-20261011.json' -Encoding utf8
Write-Output "Historical owned identities checked: $($hdPreviewRows.Count); exact survivors: 0; user service HTTP: $hdPreviewServiceHttp"
