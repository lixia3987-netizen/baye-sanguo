import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
const root=process.cwd(),base='build/person-equipment-20261011',target='docs/validation/m5-person-equipment-20261011';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const files=[];
for(const name of fs.readdirSync(base)){
 const directory=path.join(base,name);
 if(!fs.statSync(directory).isDirectory()){
  if(/\.(json|jsonl|log|mjs|ps1)$/.test(name))files.push(directory);
  continue;
 }
 for(const file of fs.readdirSync(directory)){
  const source=path.join(directory,file);
  if(!fs.statSync(source).isFile())continue;
  if(/\.(json|jsonl|log|mjs)$/.test(file)||/equipment.*\.png$/.test(file))files.push(source);
 }
 const frozen=path.join(directory,'frozen-sources');
 if(fs.existsSync(frozen))for(const file of fs.readdirSync(frozen))if(fs.statSync(path.join(frozen,file)).isFile())files.push(path.join(frozen,file));
}
for(const file of ['build/person-equipment-hud-preflight.log','build/person-equipment-hud-v1.log'])if(fs.existsSync(file))files.push(file);
fs.mkdirSync(target,{recursive:true});
const entries=[];
for(const source of files){
 const raw=fs.readFileSync(source),hash=sha(raw),file=hash+path.extname(source)+'.gz',compressed=zlib.gzipSync(raw,{level:9}),destination=path.join(target,file);
 if(!fs.existsSync(destination))fs.writeFileSync(destination,compressed,{flag:'wx'});
 const actual=fs.readFileSync(destination),roundtrip=zlib.gunzipSync(actual);
 if(roundtrip.length!==raw.length||sha(roundtrip)!==hash)throw Error('Archive mismatch '+source);
 entries.push({source:source.replaceAll('\\','/'),file:path.relative('docs/validation',destination).replaceAll('\\','/'),rawBytes:raw.length,rawSha256:hash,bytes:actual.length,sha256:sha(actual)});
}
const index={schemaVersion:1,createdAt:new Date().toISOString(),scope:'All root evidence JSON/JSONL/log and executed tools for each attempt; equipment PNG checkpoints. Browser profiles retained locally, never archived.',entries};
fs.writeFileSync('docs/validation/m5-person-equipment-20261011-archive.json',JSON.stringify(index,null,2)+'\n');
console.log(JSON.stringify({files:entries.length,unique:new Set(entries.map(x=>x.file)).size,rawBytes:entries.reduce((n,x)=>n+x.rawBytes,0),bytes:entries.reduce((n,x)=>n+x.bytes,0)}));
