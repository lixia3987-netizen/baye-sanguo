// Real shared selector + mobile host, with controlled native publication/ACKs.
// No browser, service, native engine or user storage is accessed.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const sharedSource = readFileSync(new URL('../js/hd-system-ui.js', import.meta.url), 'utf8');
const hostSource = readFileSync(process.env.BAYE_HD_MOBILE_SYSTEM_SOURCE || new URL('../js/hd-mobile-system.js', import.meta.url), 'utf8');
const SHA = '3bd20146084054163d045c90987c756a6a210664e78253cc56bc4a274727903e';
const RAW = ['g_hdEngineReady', 'g_hdDetailGeneration', 'g_hdSpeGeneration', 'g_hdMenuActive', 'g_hdMenuContext', 'g_hdMenuKind',
    'g_hdMenuSeq', 'g_hdMenuCount', 'g_hdMenuIndex', 'g_hdRecordActive', 'g_hdRecordMode', 'g_hdRecordIndex', 'g_hdRecordCount',
    'g_hdRecordSeq', 'g_hdMapPick', 'g_hdBattlePick', 'g_hdMapCity', 'g_hdMapInputSeq', 'g_hdMarchPhase',
    'g_hdReportActive', 'g_hdQtyActive', 'g_hdHelpActive', 'g_hdFightActive', 'g_hdMovieActive', 'g_hdSpeActive',
    'g_hdSkillActive', 'g_hdAttackActive', 'g_hdSkillResultActive', 'g_hdMakerActive', 'g_hdViewActive', 'g_hdMiniMapActive',
    'g_hdGoodsActive', 'g_hdPersonPropertiesActive', 'g_hdResultOwnerKind', 'g_hdResultOwnerValid'];

function fixture({screen = 'title', acknowledge = true, mount = true, storageThrows = false, diagnostics = false} = {}) {
    const listeners = new Map(), windowListeners = new Map(), windowCaptureListeners = new Map(), timers = new Map(), intervals = new Map(), subscribers = [];
    const nodes = new Map(), keys = [], writes = [];
    let clock = 0, timerId = 0, topOverride = null, menuHook = null, inspectHook = null, currentIdentity;
    class Element {
        constructor(id = '', tag = 'div') {
            this.id = id; this.tagName = tag.toUpperCase(); this.nodeType = 1; this.children = []; this.attrs = {};
            this.hidden = this.disabled = false; this.isConnected = true; this.textContent = ''; this.className = '';
            this.rect = {left: 10, top: 70, width: 180, height: 44}; this.style = {display: 'block', visibility: 'visible', opacity: '1'};
            this.events = new Map(); this.scrollTop = 0;
            this.classList = {contains: name => this.className.split(/\s+/).includes(name),
                add: name => { if (!this.classList.contains(name)) this.className += ' ' + name; },
                toggle: (name, on) => { const yes = on ?? !this.classList.contains(name); this.className = this.className.split(/\s+/).filter(x => x && x !== name).join(' '); if (yes) this.classList.add(name); }};
            if (id) nodes.set(id, this);
        }
        setAttribute(name, value) { this.attrs[name] = String(value); }
        getAttribute(name) { return this.attrs[name] ?? null; }
        appendChild(child) { child.parentElement = child.parentNode = this; this.children.push(child); return child; }
        set innerHTML(value) { this.html = value; this.children.forEach(n => { n.isConnected = false; }); this.children = []; }
        get innerHTML() { return this.html || ''; }
        getBoundingClientRect() { return {...this.rect}; }
        contains(other) { for (let n = other; n; n = n.parentElement) if (n === this) return true; return false; }
        querySelector(selector) { return this.children.find(n => selector.split('.').slice(1).every(c => n.classList.contains(c))) || null; }
        querySelectorAll() { return []; }
        addEventListener(name, fn) { const list = this.events.get(name) || []; list.push(fn); this.events.set(name, list); }
        scrollIntoView() { throw Error('mobile polling must not scroll the list'); }
    }
    const html = new Element('html'), body = html.appendChild(new Element('body', 'body')); body.className = 'hd-mobile-page';
    const root = body.appendChild(new Element('hd-system-ui'));
    for (const id of ['hd-system-ui-title', 'hd-system-ui-sub', 'hd-system-ui-list', 'hd-system-ui-probe']) root.appendChild(new Element(id));
    const list = nodes.get('hd-system-ui-list'), back = root.appendChild(new Element('back', 'button')); back.setAttribute('data-hd-sys-back', ''); back.rect.top = 290;
    const mode = body.appendChild(new Element('hd-mobile-system-mode', 'button')), open = body.appendChild(new Element('hd-mobile-system-open', 'button'));
    mode.rect = {left: 600, top: 4, width: 90, height: 44}; open.rect = {left: 700, top: 4, width: 60, height: 44};
    const outside = body.appendChild(new Element('outside')); outside.rect = {left: 400, top: 300, width: 70, height: 44};
    const document = {body, documentElement: html, hidden: false, fonts: {status:'loaded'}, getElementById: id => nodes.get(id) || null,
        createElement: tag => new Element('', tag), addEventListener(name, fn) { const list = listeners.get(name) || []; list.push(fn); listeners.set(name, list); },
        elementFromPoint(x, y) { return topOverride || [mode, open, back, ...list.children].find(n => !n.hidden && x >= n.rect.left && x < n.rect.left + n.rect.width && y >= n.rect.top && y < n.rect.top + n.rect.height) || outside; }};
    const values = {'baye/systemUiMode': 'classic', 'baye/overworldMode': 'classic', 'baye/mobileOverworldMode': 'hd-map'};
    const storage = {getItem: key => { if (storageThrows) throw Error('blocked'); return values[key] ?? null; },
        setItem(key, value) { if (storageThrows) throw Error('blocked'); writes.push([key, value]); values[key] = value; }};
    let data = Object.fromEntries(RAW.map(name => [name, 0]));
    Object.assign(data, {g_hdEngineReady: 1, g_hdDetailGeneration: 7, g_hdSpeGeneration: 9, g_hdMenuSeq: 12, g_hdRecordSeq: 15,
        g_hdMapInputSeq: 8, g_hdMapCity: 16, g_PIdx: 1, g_PlayerKing: 0, g_Cities: [{Belong: 1}]});
    data.circular = data; data.toJSON = () => { throw Error('opaque data must not be serialized'); };
    const kings = [{id: 0, name: '董卓'}, {id: 5, name: '马腾'}], slots = Array.from({length: 4}, (_, slot) => ({slot, status: 'empty', canLoad: false}));
    let names = [], ready = true;
    currentIdentity = {status: 'ready', sha256: SHA, byteLength: 207195, generation: 2};
    function publish(which, seq = data.g_hdMenuSeq + 2) {
        Object.assign(data, {g_hdMenuActive: 0, g_hdRecordActive: 0, g_hdMapPick: 0, g_hdMenuIndex: 0, g_hdMenuSeq: seq}); names = [];
        if (which === 'map') data.g_hdMapPick = 1;
        else if (which === 'save' || which === 'load') Object.assign(data, {g_hdRecordActive: 1, g_hdRecordMode: which === 'save' ? 1 : 2,
            g_hdRecordCount: which === 'save' ? 3 : 4, g_hdRecordIndex: 0, g_hdRecordSeq: data.g_hdRecordSeq + 2});
        else {
            const table = {title: [4, 1, 4], period: [4, 2, 4], king: [4, 3, kings.length], insystem: [2, 1, 3], confirm: [2, 2, 1], city: [1, 1, 4]};
            const [context, kind, count] = table[which]; Object.assign(data, {g_hdMenuActive: 1, g_hdMenuContext: context, g_hdMenuKind: kind, g_hdMenuCount: count});
            names = which === 'king' ? kings.map(k => k.name) : which === 'insystem' ? ['策略结束', '存储进度', '结束游戏'] : which === 'confirm' ? ['确定退出'] : [];
        }
    }
    publish(screen);
    const env = {document, localStorage: storage, innerWidth: 844, innerHeight: 390, BAYE_HD_MOBILE_SYSTEM_DIAGNOSTICS:diagnostics, console: {log() {}, warn() {}},
        Date: class extends Date { static now() { return clock; } },
        setTimeout(fn, delay = 0) { const id = ++timerId; timers.set(id, {fn, at: clock + delay}); return id; }, clearTimeout: id => timers.delete(id),
        setInterval(fn) { const id = ++timerId; intervals.set(id, fn); return id; }, clearInterval: id => intervals.delete(id),
        addEventListener(name, fn, capture) { const target = capture === true ? windowCaptureListeners : windowListeners;
            const list = target.get(name) || []; list.push(fn); target.set(name, list); },
        getComputedStyle: node => node.style, matchMedia: () => ({matches: env.innerWidth > env.innerHeight}),
        mobileTouch: {cancel() {}}, BayeHdOverworld: {getMode: () => values['baye/mobileOverworldMode']},
        BayeHdLibIdentity: {read: () => currentIdentity, isCurrent: candidate => candidate === currentIdentity, subscribe: fn => subscribers.push(fn)},
        BayeSaveStorage: {slots: () => slots.map(s => ({...s})), inspectSlot(index) { inspectHook?.(); return {...slots[index]}; }},
        sendKey(code) { keys.push(code); if (acknowledge && (code === 34 || code === 35)) {
            const field = data.g_hdRecordActive ? 'g_hdRecordIndex' : 'g_hdMenuIndex', count = data.g_hdRecordActive ? data.g_hdRecordCount : data.g_hdMenuCount;
            data[field] = (data[field] + (code === 34 ? -1 : 1) + count) % count;
        } },
        baye: {get data() { return data; }, ensureData: () => data, hd: {ready: () => ready, fight: () => ({active: data.g_hdFightActive, over: 0}),
            maker: () => ({active: data.g_hdMakerActive}), march: () => ({pick: data.g_hdMapPick, battlePick: data.g_hdBattlePick, mapInputSeq: data.g_hdMapInputSeq}),
            menuItems() { menuHook?.(); return {active: data.g_hdMenuActive, context: data.g_hdMenuContext, kind: data.g_hdMenuKind, count: data.g_hdMenuCount,
                index: data.g_hdMenuIndex, seq: data.g_hdMenuSeq, detailGeneration: data.g_hdDetailGeneration, names: names.slice()}; },
            record: () => ({active: data.g_hdRecordActive, mode: data.g_hdRecordMode, index: data.g_hdRecordIndex, count: data.g_hdRecordCount, seq: data.g_hdRecordSeq}),
            kings: () => ({count: kings.length, index: data.g_hdMenuIndex, currentId: kings[data.g_hdMenuIndex]?.id, kings: kings.map(k => ({...k}))})}}};
    env.window = env; const context = vm.createContext(env);
    vm.runInContext(sharedSource, context); vm.runInContext(hostSource, context);
    const api = env.BayeHdMobileSystem, shared = env.BayeHdSystemUi;
    function layout() { list.children.forEach((button, i) => { button.rect = {left: 10 + (i % 2) * 200, top: 100 + Math.floor(i / 2) * 50, width: 180, height: 44}; }); }
    function refresh() { api.refresh(); layout(); }
    if (mount) { api.init(); layout(); }
    function fire(type, target = outside, extra = {}) {
        const r = target.rect, e = {type, target, isTrusted: true, pointerId: 1, isPrimary: true, button: 0, detail: 1,
            clientX: r.left + 5, clientY: r.top + 5, defaultPrevented: false,
            preventDefault() { this.defaultPrevented = true; }, stopPropagation() { this.stopped = true; }, stopImmediatePropagation() { this.stopped = true; }, ...extra};
        for (const fn of windowCaptureListeners.get(type) || []) { fn(e); if (e.stopped) break; }
        if (!e.stopped) for (const fn of listeners.get(type) || []) { fn(e); if (e.stopped) break; }
        if (!e.stopped) for (const fn of root.events.get(type) || []) fn(e);
        return e;
    }
    function click(target) { fire('pointerdown', target); fire('pointerup', target); return fire('click', target); }
    function tick(ms = 200) { const end = clock + ms; let count = 0; while (timers.size) {
        const [id, timer] = [...timers].sort((a,b) => a[1].at - b[1].at)[0]; if (timer.at > end) break;
        assert.ok(++count < 1000); timers.delete(id); clock = timer.at; timer.fn();
    } clock = end; refresh(); }
    return {env, api, shared, nodes, root, list, back, mode, open, outside, keys, writes, values, slots, kings, get data() { return data; },
        publish, refresh, click, fire, tick, timers, intervals,
        windowEvent(name) { [...(windowCaptureListeners.get(name) || []), ...(windowListeners.get(name) || [])].forEach(fn => fn()); },
        identity(value) { currentIdentity = {...currentIdentity, ...value}; subscribers.forEach(fn => fn(currentIdentity)); },
        rebind() { data = {...data}; data.circular = data; }, setReady(value) { ready = value; },
        setMenuHook(fn) { menuHook = fn; }, setInspectHook(fn) { inspectHook = fn; }, setTop(value) { topOverride = value; },
        button: index => list.children.find(n => n.getAttribute('data-hd-sys') === String(index))};
}

test('mobile is fail-closed before host init and does not read/write the PC preference', () => {
    const h = fixture({mount: false}); assert.equal(h.shared.shouldShowHd(), false); assert.equal(h.shared.isOpen(), false);
    h.api.init(); assert.equal(h.api.snapshot().screen, 'title'); assert.equal(h.api.snapshot().active, true); assert.deepEqual(h.writes, []);
    assert.equal(h.values['baye/systemUiMode'], 'classic');
});
for (const [screen, count] of [['title',4],['period',4],['king',2],['insystem',3],['confirm',1],['save',3],['load',4]]) {
    test(`real ${screen} publication renders ${count} items without engine input`, () => {
        const h = fixture({screen}); assert.equal(h.list.children.length, count); assert.equal(h.api.snapshot().active, true); assert.deepEqual(h.keys, []);
        assert.equal(h.api.readInputTicket().data, h.data);
    });
}
test('title and period accept their native pictorial selector during icon movie', () => {
    for (const screen of ['title','period']) { const h = fixture({screen}); h.data.g_hdMovieActive = h.data.g_hdSpeActive = 1; h.refresh(); assert.equal(h.api.snapshot().active, true); }
});
test('trusted touch follows real Arrow ACK before one final Enter', () => {
    const h = fixture(); h.click(h.button(2)); h.tick(); assert.deepEqual(h.keys, [35,35,39]);
    h.click(h.button(2)); h.tick(); assert.deepEqual(h.keys, [35,35,39]);
});
test('native current item touch sends exactly Enter, not a guessed cursor reset', () => {
    const h = fixture({screen:'king'}); h.click(h.button(0)); assert.deepEqual(h.keys, [39]);
});
test('missing native ACK cannot produce Enter; retirement cancels later work', () => {
    const h = fixture({acknowledge:false}); h.click(h.button(3)); h.tick(1000); assert.deepEqual(h.keys,[35]);
    h.api.retireInteraction('test'); h.tick(10000); assert.deepEqual(h.keys,[35]);
});
test('bare/untrusted clicks and keyboard-generated clicks never authorize input', () => {
    const h = fixture(); h.fire('click', h.button(0)); h.fire('click', h.button(0), {isTrusted:false});
    h.fire('pointerdown', h.button(0), {isTrusted:false}); h.fire('pointerup',h.button(0)); h.fire('click',h.button(0));
    h.fire('keydown',h.button(0),{key:'Enter'}); h.fire('click',h.button(0),{detail:0}); assert.deepEqual(h.keys,[]);
});
for (const boundary of ['pointercancel','scroll','resize','orientationchange','blur','pagehide']) {
    test(`${boundary} retires DOWN and delayed native selection without keys`, () => {
        const h = fixture(); const button = h.button(1); h.fire('pointerdown',button);
        if (['pointercancel','scroll'].includes(boundary)) h.fire(boundary,button); else h.windowEvent(boundary);
        h.fire('pointerup',button); h.fire('click',button); h.tick(); assert.deepEqual(h.keys,[]);
    });
}
test('hidden/portrait immediately retire and restore only fresh current owner', () => {
    const h = fixture(), button = h.button(0); h.fire('pointerdown',button); h.env.document.hidden = true; h.fire('visibilitychange');
    assert.equal(h.api.snapshot().active,false); assert.equal(h.intervals.size,0);
    h.env.document.hidden = false; h.fire('visibilitychange'); h.fire('pointerup',button); h.fire('click',button); assert.deepEqual(h.keys,[]);
    h.env.innerWidth=390; h.env.innerHeight=844; h.windowEvent('orientationchange'); assert.equal(h.api.snapshot().active,false);
    h.env.innerWidth=844; h.env.innerHeight=390; h.windowEvent('orientationchange'); assert.equal(h.api.snapshot().active,true);
});
test('multiple pointers, dragged gesture, changed geometry and covered controls reject', () => {
    for (const cause of ['multi','drag','geometry','cover']) {
        const h=fixture(), b=h.button(0); h.fire('pointerdown',b);
        if(cause==='multi') h.fire('pointerdown',h.outside,{pointerId:2,isPrimary:false});
        if(cause==='drag') h.fire('pointermove',b,{clientY:b.rect.top+20});
        if(cause==='geometry') b.rect.left+=1;
        if(cause==='cover') h.setTop(h.outside);
        h.fire('pointerup',b); h.fire('click',b); assert.deepEqual(h.keys,[],cause);
    }
});
test('same native ticket preserves actual DOM nodes and scroll across polls', () => {
    const h=fixture({screen:'king'}), b=h.button(1); h.list.scrollTop=70;
    h.fire('pointerdown',b); for(let i=0;i<8;i++) h.refresh(); assert.equal(h.button(1),b); assert.equal(h.list.scrollTop,70);
    h.fire('pointerup',b); h.fire('click',b); h.tick(); assert.deepEqual(h.keys,[35,39]);
});
test('real list pan retires input but keeps same-owner shell, nodes and scroll', () => {
    const h=fixture({screen:'king'}), b=h.button(1); h.list.scrollTop=72;
    h.fire('pointerdown',b); h.fire('pointermove',b,{clientY:b.rect.top+25}); h.fire('scroll',h.list);
    assert.equal(h.shared.isOpen(),true); assert.equal(h.button(1),b); assert.equal(h.list.scrollTop,72);
    h.fire('pointerup',b); h.fire('click',b); assert.deepEqual(h.keys,[]);
});
test('stale rendered buttons cannot authorize a new seq before the next render', () => {
    const h=fixture(), b=h.button(0); h.data.g_hdMenuSeq+=2;
    h.click(b); assert.deepEqual(h.keys,[]);
    h.refresh(); const fresh=h.button(0); assert.notEqual(fresh,b); h.click(fresh); assert.deepEqual(h.keys,[39]);
});
test('render binding rejects old nodes after opaque same-values data replacement', () => {
    const h=fixture(), old=h.button(0); h.rebind(); h.click(old); assert.deepEqual(h.keys,[]);
    h.refresh(); h.click(h.button(0)); assert.deepEqual(h.keys,[39]);
});
test('non-presentation raw ticket changes rebind buttons despite unchanged menu seq/stable owner', () => {
    const h=fixture(), old=h.button(0), seq=h.data.g_hdMenuSeq; h.data.g_hdRecordSeq++;
    h.click(old); assert.deepEqual(h.keys,[]); h.refresh(); assert.equal(h.data.g_hdMenuSeq,seq);
    assert.notEqual(h.button(0),old); h.click(h.button(0)); assert.deepEqual(h.keys,[39]);
});
for(const field of ['g_hdMenuSeq','g_hdDetailGeneration','g_hdSpeGeneration','g_hdMenuCount','g_hdMenuIndex']) {
    test(`${field} change rejects old gesture and stale DOM`,()=>{
        const h=fixture(), b=h.button(0); h.fire('pointerdown',b); h.data[field]++;
        h.fire('pointerup',b); h.fire('click',b); assert.deepEqual(h.keys,[]);
    });
}
test('opaque data rebind with identical primitive fields rejects old input',()=>{
    const h=fixture(), b=h.button(0); h.fire('pointerdown',b); h.rebind(); h.fire('pointerup',b); h.fire('click',b); assert.deepEqual(h.keys,[]);
});
for(const [field,value] of [['status','pending'],['sha256','00'.repeat(32)],['byteLength',207194],['generation',0]]) {
    test(`uncertified identity ${field} refuses native display and input`,()=>{
        const h=fixture(); h.identity({[field]:value}); assert.equal(h.api.snapshot().active,false); assert.deepEqual(h.keys,[]);
    });
}
for(const field of ['g_hdFightActive','g_hdQtyActive','g_hdReportActive','g_hdHelpActive','g_hdMakerActive','g_hdSkillActive','g_hdAttackActive',
    'g_hdBattlePick','g_hdViewActive','g_hdMiniMapActive','g_hdGoodsActive','g_hdPersonPropertiesActive','g_hdSkillResultActive','g_hdResultOwnerValid']) {
    test(`competing ${field} retires the system shell`,()=>{
        const h=fixture(); h.data[field]=1; h.refresh(); assert.equal(h.api.snapshot().active,false); assert.deepEqual(h.keys,[]);
    });
}
test('wrong system count/context, half names and invalid king publication fall back',()=>{
    for(const fault of ['context','count','names','kingID','period']) {
        const h=fixture({screen:fault==='kingID'||fault==='period'?'king':'insystem'});
        if(fault==='context') h.data.g_hdMenuContext=1;
        if(fault==='count') h.data.g_hdMenuCount=2;
        if(fault==='names') h.setMenuHook(()=>{ h.data.g_hdMenuCount=4; });
        if(fault==='kingID') h.kings[1].id=65535;
        if(fault==='period') h.data.g_PIdx=0;
        h.refresh(); assert.equal(h.api.snapshot().active,false,fault);
    }
});
test('continuous torn native publication cannot render or input',()=>{
    const h=fixture(); h.setMenuHook(()=>h.data.g_hdMenuSeq++); h.refresh(); assert.equal(h.api.snapshot().active,false);
});
test('save slots are three; load slots four and empty/wrong-LIB/corrupt are disabled',()=>{
    const h=fixture({screen:'load'}); for(const status of ['empty','wrong-lib','incomplete','invalid']) {
        h.slots[0]={slot:0,status,canLoad:false}; h.refresh(); assert.equal(h.button(0).disabled,true); h.click(h.button(0));
    } assert.deepEqual(h.keys,[]);
});
test('load revalidates the actual slot immediately before final Enter',()=>{
    const h=fixture({screen:'load'}); h.slots[1]={slot:1,status:'valid',canLoad:true}; h.refresh(); h.click(h.button(1));
    h.slots[1].canLoad=false; h.tick(); assert.deepEqual(h.keys,[35]);
});
test('storage-triggered owner change refuses final Enter even at current index',()=>{
    const h=fixture({screen:'load'}); h.slots[0]={slot:0,status:'valid',canLoad:true}; h.refresh();
    let calls=0; h.setInspectHook(()=>{if(++calls===2) h.data.g_hdMenuActive=1;}); h.click(h.button(0)); assert.deepEqual(h.keys,[]);
});
test('mobile classic mode keeps real LCD touch surface and fresh HD reattachment',()=>{
    const h=fixture(); h.click(h.mode); assert.equal(h.api.snapshot().mode,'classic'); assert.equal(h.api.snapshot().active,false);
    assert.equal(h.env.document.body.getAttribute('data-hd-mobile-system'),'lcd'); assert.equal(h.values['baye/systemUiMode'],'classic');
    h.click(h.mode); assert.equal(h.api.snapshot().active,true); assert.deepEqual(h.keys,[]);
    assert.ok(h.writes.every(([key])=>key==='baye/mobileSystemUiMode'));
});
test('mobile mode remains usable when storage is blocked',()=>{
    const h=fixture({storageThrows:true}); h.click(h.mode); assert.equal(h.shared.getMode(),'classic'); h.click(h.mode); assert.equal(h.shared.getMode(),'hd');
});
test('MAP system entry is one real EXIT and no guessed root/record',()=>{
    const h=fixture({screen:'map'}); assert.equal(h.open.disabled,false); h.click(h.open); h.click(h.open); assert.deepEqual(h.keys,[40]);
    h.publish('insystem'); h.refresh(); assert.equal(h.api.snapshot().screen,'insystem');
});
test('MAP trusted DOWN survives actual timer polls before UP/click sends one EXIT',()=>{
    const h=fixture({screen:'map'}); h.fire('pointerdown',h.open);
    for(let i=0;i<5;i++) for(const callback of h.intervals.values()) callback();
    h.fire('pointerup',h.open); h.fire('click',h.open); assert.deepEqual(h.keys,[40]);
    for(const callback of h.intervals.values()) callback(); h.click(h.open); assert.deepEqual(h.keys,[40]);
});
for (const phase of [0,7]) {
    test(`window pointer capture pairs earlier document-consumed battle releases before MAP phase ${phase} system entry`,()=>{
        const h=fixture({screen:'map',mount:false,diagnostics:true}); let consumed=0;
        // A preceding mobile battle footer consumer sees DOWN but consumes
        // its successful UP at document capture. Window capture runs first.
        h.env.document.addEventListener('pointerup',event=>{
            if(event.target===h.outside){consumed++;event.stopImmediatePropagation();}
        },true);
        h.api.init();h.data.g_hdMarchPhase=phase;h.refresh();
        for(const pointerId of [4,5,6]){
            h.fire('pointerdown',h.outside,{pointerId});
            h.fire('pointerup',h.outside,{pointerId});
        }
        assert.equal(consumed,3);assert.deepEqual(h.keys,[]);
        let d=h.api.debugSnapshot().diagnostics;
        assert.deepEqual(Array.from(d.pointerIDs),[]);assert.equal(d.blocked,false);
        h.fire('pointerdown',h.open,{pointerId:21});
        for(const callback of h.intervals.values())callback();
        h.fire('pointerup',h.open,{pointerId:21});h.fire('click',h.open);
        assert.deepEqual(h.keys,[40]);h.click(h.open);assert.deepEqual(h.keys,[40]);
        d=h.api.debugSnapshot().diagnostics;assert.equal(d.pointerCount,0);assert.equal(d.blocked,false);
    });
}
test('window pointer capture observes CANCEL consumed by an earlier document host',()=>{
    const h=fixture({screen:'map',mount:false,diagnostics:true});let consumed=0;
    h.env.document.addEventListener('pointercancel',event=>{
        if(event.target===h.outside){consumed++;event.stopImmediatePropagation();}
    },true);
    h.api.init();h.fire('pointerdown',h.outside,{pointerId:4});
    h.fire('pointercancel',h.outside,{pointerId:4});
    assert.equal(consumed,1);assert.equal(h.api.debugSnapshot().diagnostics.pointerCount,0);
    h.click(h.open);assert.deepEqual(h.keys,[40]);
});
test('window pointer capture rejects a real second pointer even when document host consumes its DOWN and UP',()=>{
    const h=fixture({screen:'map',mount:false,diagnostics:true});let consumed=0;
    for(const type of ['pointerdown','pointerup'])h.env.document.addEventListener(type,event=>{
        if(event.target===h.outside){consumed++;event.stopImmediatePropagation();}
    },true);
    h.api.init();h.fire('pointerdown',h.open,{pointerId:21});
    h.fire('pointerdown',h.outside,{pointerId:22,isPrimary:false});
    assert.equal(h.api.debugSnapshot().diagnostics.blocked,true);
    h.fire('pointerup',h.outside,{pointerId:22,isPrimary:false});
    assert.equal(h.api.debugSnapshot().diagnostics.pointerCount,1);
    h.fire('pointerup',h.open,{pointerId:21});h.fire('click',h.open);
    assert.equal(consumed,2);assert.deepEqual(h.keys,[]);
    assert.equal(h.api.debugSnapshot().diagnostics.pointerCount,0);
    h.fire('pointerdown',h.open,{pointerId:23});h.fire('pointerup',h.open,{pointerId:23});h.fire('click',h.open);
    assert.deepEqual(h.keys,[40]);
});
test('hidden boundary does not clear an actually held foreign pointer to authorize system entry',()=>{
    const h=fixture({screen:'map',mount:false,diagnostics:true});
    h.env.document.addEventListener('pointerup',event=>{
        if(event.target===h.outside)event.stopImmediatePropagation();
    },true);
    h.api.init();h.fire('pointerdown',h.outside,{pointerId:4});
    h.env.document.hidden=true;h.fire('visibilitychange');
    h.env.document.hidden=false;h.fire('visibilitychange');
    assert.equal(h.api.debugSnapshot().diagnostics.pointerCount,1);
    h.fire('pointerdown',h.open,{pointerId:21,isPrimary:false});
    h.fire('pointerup',h.open,{pointerId:21,isPrimary:false});h.fire('click',h.open);
    assert.deepEqual(h.keys,[]);assert.equal(h.api.debugSnapshot().diagnostics.pointerCount,1);
    h.fire('pointerup',h.outside,{pointerId:4});
    assert.equal(h.api.debugSnapshot().diagnostics.pointerCount,0);
    h.click(h.open);assert.deepEqual(h.keys,[40]);
});
test('window capture still rejects MAP owner replacement between trusted DOWN and UP',()=>{
    const h=fixture({screen:'map',mount:false,diagnostics:true});
    h.env.document.addEventListener('pointerup',event=>{
        if(event.target===h.outside)event.stopImmediatePropagation();
    },true);
    h.api.init();h.fire('pointerdown',h.outside,{pointerId:4});h.fire('pointerup',h.outside,{pointerId:4});
    h.fire('pointerdown',h.open,{pointerId:21});h.rebind();
    h.fire('pointerup',h.open,{pointerId:21});h.fire('click',h.open);
    assert.deepEqual(h.keys,[]);assert.equal(h.api.debugSnapshot().diagnostics.last.up.reason,'owner-data-changed');
    h.click(h.open);assert.deepEqual(h.keys,[40]);
});
for(const change of ['map-seq','map-city','data','native-menu','report']) {
    test(`MAP timer polling rejects armed system entry after ${change} changes`,()=>{
        const h=fixture({screen:'map'}); h.fire('pointerdown',h.open);
        if(change==='map-seq') h.data.g_hdMapInputSeq++;
        if(change==='map-city') h.data.g_hdMapCity++;
        if(change==='data') h.rebind();
        if(change==='native-menu') h.publish('insystem');
        if(change==='report') h.data.g_hdReportActive=1;
        for(const callback of h.intervals.values()) callback();
        h.fire('pointerup',h.open); h.fire('click',h.open); assert.deepEqual(h.keys,[]);
    });
}
test('terminal march7 allows only separately proven MAP; active/unknown phases refuse',()=>{
    for(const phase of [0,1,2,3,4,5,6,7,8]) {
        const h=fixture({screen:'map'}); h.data.g_hdMarchPhase=phase; h.refresh(); assert.equal(h.open.disabled,![0,7].includes(phase));
    }
});
test('real root→exit confirmation→root→record→MAP retires old controls once',()=>{
    const h=fixture({screen:'insystem'}); h.click(h.button(2)); h.tick(); assert.deepEqual(h.keys,[35,35,39]);
    h.publish('confirm'); h.refresh(); assert.equal(h.button(0).textContent,'确定退出'); h.click(h.back); h.click(h.back); assert.equal(h.keys.at(-1),40);
    const count=h.keys.length; h.publish('insystem'); h.refresh(); h.publish('save'); h.refresh(); const old=h.button(0); h.click(old); assert.equal(h.keys.at(-1),39);
    h.publish('map'); h.refresh(); h.fire('click',old); assert.equal(h.api.snapshot().active,false); assert.equal(h.keys.length,count+1);
});
test('init is idempotent, hidden pauses polling and pagehide has no input',()=>{
    const h=fixture(), n=h.intervals.size; h.api.init(); assert.equal(h.intervals.size,n);
    h.env.document.hidden=true; h.fire('visibilitychange'); assert.equal(h.intervals.size,0); assert.deepEqual(h.keys,[]);
});

test('diagnostics are dynamically opt-in and do not change the normal snapshot contract',()=>{
    const h=fixture(); assert.equal('diagnostics' in h.api.debugSnapshot(),false);
    h.env.BAYE_HD_MOBILE_SYSTEM_DIAGNOSTICS=true;
    assert.equal(h.api.debugSnapshot().diagnostics.total,0);
    h.fire('pointerdown',h.mode);let d=h.api.debugSnapshot().diagnostics;
    assert.equal(d.arm.kind,'mode');assert.equal(d.last.down.reason,'armed');
    assert.equal(d.last.down.checks.dataSame,true);assert.equal(d.last.down.checks.keySame,true);
    h.fire('pointerup',h.mode);d=h.api.debugSnapshot().diagnostics;
    assert.equal(d.arm,null);assert.equal(d.grant.kind,'mode');assert.equal(d.last.up.reason,'grant-created');
    assert.equal(d.last.up.checks.geometrySame,true);assert.equal(d.last.up.checks.visible,true);
    h.fire('click',h.mode);d=h.api.debugSnapshot().diagnostics;
    assert.equal(d.last.click.reason,'authorized');assert.equal(d.last.retire.reason,'mode-change');
    assert.equal(d.last.click.checks.dataSame,true);assert.equal(d.last.click.checks.keySame,true);
    assert.equal(d.last.down.fontsStatus,'loaded');assert.equal(h.api.snapshot().mode,'classic');
    assert.equal('diagnostics' in h.api.snapshot(),false);assert.deepEqual(h.keys,[]);
    h.env.BAYE_HD_MOBILE_SYSTEM_DIAGNOSTICS=false;
    assert.equal('diagnostics' in h.api.debugSnapshot(),false);
});
test('20 diagnostic HD/classic cycles remain bounded, serializable and input-free across real poll callbacks',()=>{
    const h=fixture({diagnostics:true});
    for(let i=0;i<40;i++){
        h.fire('pointerdown',h.mode);
        for(const fn of h.intervals.values())fn();
        h.fire('pointerup',h.mode);h.fire('click',h.mode);
        assert.equal(h.api.snapshot().mode,i%2?'hd':'classic');
    }
    const snap=h.api.debugSnapshot(),d=snap.diagnostics;
    assert.equal(d.total,160);assert.equal(d.events.length,12);assert.equal(d.limit,12);
    assert.equal(d.last.up.reason,'grant-created');assert.equal(d.last.click.reason,'authorized');
    assert.equal(d.arm,null);assert.equal(d.grant,null);assert.deepEqual(Array.from(d.pointerIDs),[]);
    assert.ok(JSON.stringify(d).length<24000);assert.doesNotThrow(()=>JSON.stringify(snap));
    assert.equal(JSON.stringify(d).includes('stableKey'),false);assert.equal(JSON.stringify(d).includes('circular'),false);
    d.events.length=0;d.last.click.reason='tampered';
    assert.equal(h.api.debugSnapshot().diagnostics.events.length,12);
    assert.equal(h.api.debugSnapshot().diagnostics.last.click.reason,'authorized');assert.deepEqual(h.keys,[]);
});
test('diagnostic enabled and disabled paths make the same native getter calls, keys and preference writes',()=>{
    const run=diagnostics=>{const h=fixture({diagnostics});let calls=0;h.setMenuHook(()=>calls++);
        for(let i=0;i<4;i++){h.fire('pointerdown',h.mode);for(const fn of h.intervals.values())fn();h.fire('pointerup',h.mode);h.fire('click',h.mode);}
        h.click(h.button(1));h.tick();return {calls,keys:h.keys,writes:h.writes,mode:h.shared.getMode()};};
    assert.deepEqual(run(true),run(false));
});
test('diagnostic snapshot does not resample native getters and never retains opaque event data',()=>{
    const h=fixture({diagnostics:true});h.fire('pointerdown',h.mode);h.fire('pointerup',h.mode);
    h.fire('click',h.mode,{detail:h.data});
    const fail=()=>{throw Error('diagnostic must not read native');};
    h.env.baye.ensureData=fail;h.env.baye.hd.ready=fail;h.env.baye.hd.menuItems=fail;h.env.BayeHdLibIdentity.read=fail;
    const d=h.api.debugSnapshot().diagnostics;
    assert.equal(d.last.click.detail,null);assert.equal(d.last.click.reason,'authorized');
    assert.doesNotThrow(()=>JSON.stringify(d));assert.deepEqual(h.keys,[]);
});
for(const fault of ['untrusted','wrong-button','invalid-pointer','disabled','small','covered','stale-render']){
    test('diagnostic DOWN records exact rejection: '+fault,()=>{
        const h=fixture({diagnostics:true}),b=fault==='stale-render'?h.button(0):h.mode;let extra={};
        if(fault==='untrusted')extra.isTrusted=false;
        if(fault==='wrong-button')extra.button=2;
        if(fault==='invalid-pointer')extra.pointerId=-1;
        if(fault==='disabled')b.disabled=true;
        if(fault==='small')b.rect.width=43;
        if(fault==='covered')h.setTop(h.outside);
        if(fault==='stale-render')h.data.g_hdMenuSeq++;
        h.fire('pointerdown',b,extra);const d=h.api.debugSnapshot().diagnostics;
        const reason={untrusted:'untrusted','wrong-button':'wrong-button','invalid-pointer':'invalid-pointer-id',disabled:'not-visible',small:'not-visible',covered:'not-visible','stale-render':'stale-render'}[fault];
        assert.equal(d.last.down.reason,reason);assert.equal(d.arm,null);assert.deepEqual(h.keys,[]);
        if(fault==='covered')assert.equal(d.last.down.checks.visibilityReason,'target-covered');
        if(fault==='small')assert.equal(d.last.down.checks.visibilityReason,'target-too-small');
    });
}
for(const fault of ['no-arm','geometry','data','key','owner-unavailable','target','covered','untrusted']){
    test('diagnostic UP preserves precise cause after a subsequent no-grant click: '+fault,()=>{
        const h=fixture({diagnostics:true}),b=h.mode;if(fault!=='no-arm')h.fire('pointerdown',b);
        if(fault==='geometry')b.rect.left+=.25;
        if(fault==='data')h.rebind();
        if(fault==='key')h.data.g_hdRecordSeq++;
        if(fault==='owner-unavailable')h.setReady(false);
        if(fault==='covered')h.setTop(h.outside);
        const target=fault==='target'?h.open:b;
        h.fire('pointerup',target,fault==='untrusted'?{isTrusted:false}:{});h.fire('click',target);
        const d=h.api.debugSnapshot().diagnostics;
        assert.equal(d.last.up.reason,{'no-arm':'no-arm',geometry:'geometry-changed',data:'owner-data-changed',key:'owner-key-changed','owner-unavailable':'current-owner-unavailable',target:'target-changed',covered:'not-visible',untrusted:'untrusted'}[fault]);
        assert.equal(d.last.click.reason,'no-grant');assert.deepEqual(h.keys,[]);
        if(fault==='geometry')assert.equal(d.last.up.checks.geometrySame,false);
        if(fault==='data'){assert.equal(d.last.up.checks.dataSame,false);assert.equal(d.last.up.checks.keySame,true);}
        if(fault==='key'){assert.equal(d.last.up.checks.dataSame,true);assert.equal(d.last.up.checks.keySame,false);}
    });
}
for(const fault of ['untrusted','keyboard','expired','covered','data','key']){
    test('diagnostic CLICK distinguishes the authorized-grant rejection: '+fault,()=>{
        const h=fixture({diagnostics:true});h.fire('pointerdown',h.mode);h.fire('pointerup',h.mode);
        if(fault==='expired')h.tick(1001);
        if(fault==='covered')h.setTop(h.outside);
        if(fault==='data')h.rebind();
        if(fault==='key')h.data.g_hdRecordSeq++;
        h.fire('click',h.mode,fault==='untrusted'?{isTrusted:false}:fault==='keyboard'?{detail:0}:{});
        const d=h.api.debugSnapshot().diagnostics;
        assert.equal(d.last.click.reason,{untrusted:'untrusted',keyboard:'keyboard-click',expired:'grant-expired',covered:'not-visible',data:'owner-data-changed',key:'owner-key-changed'}[fault]);
        assert.equal(d.last.up.reason,'grant-created');assert.equal(h.shared.getMode(),'hd');assert.deepEqual(h.keys,[]);
    });
}
for(const cause of ['scroll','resize','blur','pointercancel','multi','poll-key','poll-data']){
    test('diagnostic retirement records the actual boundary or sampled mismatch: '+cause,()=>{
        const h=fixture({diagnostics:true});h.fire('pointerdown',h.mode);
        if(cause==='scroll'||cause==='pointercancel')h.fire(cause,h.mode);
        if(cause==='resize'||cause==='blur')h.windowEvent(cause);
        if(cause==='multi')h.fire('pointerdown',h.outside,{pointerId:2,isPrimary:false});
        if(cause==='poll-key')h.data.g_hdRecordSeq++;
        if(cause==='poll-data')h.rebind();
        if(cause.startsWith('poll'))for(const fn of h.intervals.values())fn();
        h.fire('pointerup',h.mode);h.fire('click',h.mode);const d=h.api.debugSnapshot().diagnostics;
        assert.equal(d.last.retire.reason,{'scroll':'scroll',resize:'resize',blur:'blur',pointercancel:'pointer-cancel',multi:'multiple-pointers','poll-key':'owner-changed','poll-data':'owner-changed'}[cause]);
        assert.equal(d.last.up.reason,'no-arm');assert.equal(d.last.click.reason,'no-grant');assert.deepEqual(h.keys,[]);
        if(cause==='poll-key')assert.equal(d.last.retire.checks.keySame,false);
        if(cause==='poll-data')assert.equal(d.last.retire.checks.dataSame,false);
    });
}

test('returned title keeps the exact granted button across UP then same-ticket host polls',()=>{
    const h=fixture({diagnostics:true});h.click(h.button(1));h.tick();
    h.publish('load');h.refresh();h.click(h.back);h.publish('title');h.data.g_hdSpeActive=1;h.refresh();
    const b=h.button(0),before=h.keys.length;h.fire('pointerdown',b);h.fire('pointerup',b);
    const granted=h.api.debugSnapshot().diagnostics.last.up.grant.target.node;
    for(let i=0;i<8;i++)for(const fn of h.intervals.values())fn();
    assert.equal(h.button(0),b);h.fire('click',b);
    const d=h.api.debugSnapshot().diagnostics;
    assert.equal(d.last.click.reason,'authorized');assert.equal(d.last.click.actionTarget.node,granted);
    assert.equal(d.last.click.checks.expectedTarget.node,granted);
    assert.deepEqual(Array.from(d.last.click.checks.release.point),[b.rect.left+5,b.rect.top+5]);
    assert.equal(d.render.last.status,'cache-hit');assert.equal(d.render.last.source,'mobile-host');
    assert.equal(d.render.last.checks.keySame,true);assert.equal(d.render.last.checks.signatureSame,true);
    assert.deepEqual(h.keys.slice(before),[39]);
});

test('native maker refresh between UP and CLICK records replaced buttons and preserves target rejection',()=>{
    const h=fixture({diagnostics:true});h.data.g_hdSpeActive=1;h.refresh();const old=h.button(0);
    h.fire('pointerdown',old);h.fire('pointerup',old);const before=h.api.debugSnapshot().diagnostics;
    h.data.g_hdRecordSeq++;h.shared.onEngineMaker();const fresh=h.button(0);assert.notEqual(fresh,old);
    // This callback bypasses the host poll: a granted old node remains, but
    // the real full-key change must never authorize the replacement node.
    h.fire('click',fresh);const d=h.api.debugSnapshot().diagnostics;
    assert.equal(d.last.click.reason,'target-changed');assert.equal(d.last.click.checks.targetSame,false);
    assert.equal(d.last.click.checks.expectedTarget.node,before.last.up.grant.target.node);
    assert.equal(d.last.click.checks.expectedTarget.connected,false);
    assert.equal(d.last.click.actionTarget.connected,true);
    assert.notEqual(d.last.click.actionTarget.node,d.last.click.checks.expectedTarget.node);
    assert.equal(d.last.click.actionTarget.item,'0');assert.equal(d.last.click.checks.expectedTarget.item,'0');
    const rebuild=d.render.rebuildHistory.at(-1);
    assert.equal(rebuild.source,'engine-maker');assert.equal(rebuild.checks.keySame,false);
    assert.equal(rebuild.checks.dataSame,true);assert.equal(rebuild.checks.itemsSame,true);
    assert.equal(rebuild.checks.indexSame,true);assert.equal(rebuild.checks.requestSame,true);
    assert.equal(rebuild.speActive,1);assert.equal(d.last.click.render.rebuilds,d.render.rebuilds);
    assert.equal('currentOwner' in d.last.click.checks,false);assert.deepEqual(h.keys,[]);
});

test('CLICK captures its consumed grant and both action nodes without reading a rejected native owner',()=>{
    const h=fixture({diagnostics:true}),expected=h.button(0),wrong=h.button(1);
    h.fire('pointerdown',expected);h.fire('pointerup',expected);
    h.setMenuHook(()=>{throw Error('target rejection must short-circuit native reads');});h.fire('click',wrong);
    const d=h.api.debugSnapshot().diagnostics,click=d.last.click;
    assert.equal(click.reason,'target-changed');assert.equal(click.checks.expectedTarget.item,'0');
    assert.equal(click.actionTarget.item,'1');assert.notEqual(click.actionTarget.node,click.checks.expectedTarget.node);
    assert.deepEqual(Array.from(click.checks.release.point),[expected.rect.left+5,expected.rect.top+5]);
    assert.deepEqual(Array.from(click.point),[wrong.rect.left+5,wrong.rect.top+5]);
    assert.equal(d.grant,null);assert.equal('currentOwner' in click.checks,false);assert.deepEqual(h.keys,[]);
});

test('event child and resolved action use distinct diagnostic identities while the same button stays authorized',()=>{
    const h=fixture({diagnostics:true}),b=h.button(0),child=h.env.document.createElement('span');
    child.textContent='新君登基';child.rect={...b.rect};b.appendChild(child);
    h.fire('pointerdown',child);h.fire('pointerup',child);h.fire('click',child);
    const click=h.api.debugSnapshot().diagnostics.last.click;
    assert.equal(click.reason,'authorized');assert.notEqual(click.eventTarget.node,click.actionTarget.node);
    assert.equal(click.eventTarget.tag,'SPAN');assert.equal(click.actionTarget.tag,'BUTTON');
    assert.equal(click.actionTarget.node,click.checks.expectedTarget.node);assert.deepEqual(h.keys,[39]);
});

for(const fault of ['opaque-data','child-count'])test('list rebuild diagnostic distinguishes '+fault+' from a changed full ticket',()=>{
    const h=fixture({diagnostics:true});
    if(fault==='opaque-data')h.rebind();else h.list.children.pop();
    h.shared.onEngineMaker();const d=h.shared.getMobileRenderDiagnostics(),entry=d.rebuildHistory.at(-1);
    assert.equal(entry.status,'rebuild');assert.equal(entry.checks.keySame,true);
    assert.equal(entry.checks.signatureSame,true);
    assert.equal(entry.checks.dataSame,fault!=='opaque-data');
    assert.equal(entry.checks.childCountSame,fault!=='child-count');assert.deepEqual(h.keys,[]);
});

test('shared list diagnostics are dynamic, bounded, defensive and do not resample native getters',()=>{
    const h=fixture();assert.equal(h.shared.getMobileRenderDiagnostics(),null);
    h.env.BAYE_HD_MOBILE_SYSTEM_DIAGNOSTICS=true;
    for(let i=0;i<24;i++){h.data.g_hdRecordSeq++;h.shared.onEngineMaker();}
    const fail=()=>{throw Error('render diagnostics must not read native');};
    h.setMenuHook(fail);h.env.baye.ensureData=fail;h.env.BayeHdLibIdentity.read=fail;
    const d=h.shared.getMobileRenderDiagnostics();assert.equal(d.attempts,24);
    assert.equal(d.rebuildHistory.length,8);assert.equal(d.last.source,'engine-maker');
    assert.ok(JSON.stringify(d).length<12000);assert.equal(JSON.stringify(d).includes('stableKey'),false);
    assert.equal(JSON.stringify(d).includes('circular'),false);
    d.rebuildHistory.length=0;d.last.source='tampered';
    assert.equal(h.shared.getMobileRenderDiagnostics().rebuildHistory.length,8);
    assert.equal(h.shared.getMobileRenderDiagnostics().last.source,'engine-maker');
    assert.doesNotThrow(()=>JSON.stringify(h.api.debugSnapshot().diagnostics));
    h.env.BAYE_HD_MOBILE_SYSTEM_DIAGNOSTICS=false;assert.equal(h.shared.getMobileRenderDiagnostics(),null);
});

test('native maker diagnostic paths preserve getter counts, inputs and preferences with tracing enabled or disabled',()=>{
    const run=diagnostics=>{const h=fixture({diagnostics});let calls=0;h.setMenuHook(()=>calls++);
        const old=h.button(0);h.fire('pointerdown',old);h.fire('pointerup',old);
        h.data.g_hdRecordSeq++;h.shared.onEngineMaker();h.fire('click',h.button(0));
        h.api.debugSnapshot();h.shared.getMobileRenderDiagnostics();
        return {calls,keys:h.keys,writes:h.writes,mode:h.shared.getMode()};};
    assert.deepEqual(run(true),run(false));
});

for(const screen of ['title','period'])for(const field of ['g_hdSpeActive'])for(const from of [0,1])for(const when of ['down','up']){
    test(`pictorial-key ${screen} ${field} ${from}->${1-from} after ${when} keeps the same selector button`,()=>{
        const h=fixture({screen,diagnostics:true});h.data[field]=from;h.refresh();
        const before=h.api.readInputTicket(),b=h.button(0),rebuilds=h.shared.getMobileRenderDiagnostics().rebuilds;
        h.fire('pointerdown',b);if(when==='up')h.fire('pointerup',b);
        h.data[field]=1-from;h.shared.onEngineMaker();
        const after=h.api.readInputTicket();assert.equal(after.key,before.key);assert.equal(after.data,before.data);
        assert.equal(before.raw[field],from);assert.equal(after.raw[field],1-from);
        assert.equal(h.data[field],1-from);assert.equal(h.button(0),b);
        assert.equal(h.shared.getMobileRenderDiagnostics().rebuilds,rebuilds);
        if(when==='down')h.fire('pointerup',b);h.fire('click',b);
        const d=h.api.debugSnapshot().diagnostics;
        assert.equal(d.last.up.reason,'grant-created');assert.equal(d.last.click.reason,'authorized');
        assert.equal(d.last.click.actionTarget.node,d.last.click.checks.expectedTarget.node);
        assert.equal(d.last.click.checks.dataSame,true);assert.equal(d.last.click.checks.keySame,true);
        assert.deepEqual(h.keys,[39]);assert.deepEqual(h.writes,[]);
    });
}

for(const screen of ['title','period'])test(`pictorial-key ${screen} preserves raw flags while MovieActive still changes the full input key`,()=>{
    const h=fixture({screen});const first=h.api.readInputTicket();
    h.data.g_hdMovieActive=h.data.g_hdSpeActive=1;const next=h.api.readInputTicket();
    assert.notEqual(next.key,first.key);assert.equal(next.owner.stableKey,first.owner.stableKey);
    assert.equal(next.raw.g_hdMovieActive,1);assert.equal(next.raw.g_hdSpeActive,1);
    assert.equal(first.raw.g_hdMovieActive,0);assert.equal(first.raw.g_hdSpeActive,0);
    assert.deepEqual(h.keys,[]);assert.deepEqual(h.writes,[]);
});

for(const screen of ['title','period'])for(const field of ['g_hdMovieActive','g_hdSpeActive'])test(`pictorial-key ${screen} retains full raw torn-read rejection for ${field}`,()=>{
    const h=fixture({screen,diagnostics:true}),b=h.button(0);h.fire('pointerdown',b);
    h.setMenuHook(()=>{h.data[field]=1-h.data[field];});
    assert.equal(h.api.readInputTicket(),null);h.fire('pointerup',b);h.fire('click',b);
    assert.deepEqual(h.keys,[]);assert.equal(h.api.debugSnapshot().diagnostics.last.up.reason,'current-owner-unavailable');
});

for(const screen of ['title','period'])for(const field of ['g_hdMovieActive','g_hdSpeActive'])for(const value of [-1,2,1.5,NaN]){
    test(`pictorial-key ${screen} ${field} illegal ${value} cannot be normalized into authorization`,()=>{
        const h=fixture({screen}),b=h.button(0);h.fire('pointerdown',b);h.data[field]=value;
        assert.equal(h.api.readInputTicket(),null);h.fire('pointerup',b);h.fire('click',b);assert.deepEqual(h.keys,[]);
    });
}

for(const screen of ['king','insystem','confirm','save','load'])for(const field of ['g_hdMovieActive','g_hdSpeActive']){
    test(`pictorial-key scope excludes ${screen} when ${field} becomes active`,()=>{
        const h=fixture({screen,diagnostics:true});h.fire('pointerdown',h.mode);
        assert.equal(h.api.debugSnapshot().diagnostics.last.down.reason,'armed');h.data[field]=1;
        assert.equal(h.api.readInputTicket(),null);h.fire('pointerup',h.mode);h.fire('click',h.mode);
        assert.equal(h.shared.getMode(),'hd');assert.deepEqual(h.keys,[]);assert.deepEqual(h.writes,[]);
    });
}

for(const field of ['g_hdMovieActive','g_hdSpeActive'])test(`pictorial-key scope excludes current MAP opener during ${field}`,()=>{
    const h=fixture({screen:'map',diagnostics:true});h.fire('pointerdown',h.open);
    assert.equal(h.api.debugSnapshot().diagnostics.last.down.reason,'armed');h.data[field]=1;
    h.fire('pointerup',h.open);h.fire('click',h.open);assert.deepEqual(h.keys,[]);
    assert.equal(h.api.debugSnapshot().diagnostics.last.up.reason,'current-owner-unavailable');
});

for(const screen of ['title','period'])for(const from of [0,1])for(const when of ['down','up']){
    test(`pictorial-key ${screen} MovieActive ${from}->${1-from} after ${when} retains old target rejection`,()=>{
        const h=fixture({screen,diagnostics:true});h.data.g_hdMovieActive=from;h.refresh();
        const before=h.api.readInputTicket(),b=h.button(0);h.fire('pointerdown',b);if(when==='up')h.fire('pointerup',b);
        h.data.g_hdMovieActive=1-from;h.shared.onEngineMaker();const after=h.api.readInputTicket();
        assert.notEqual(after.key,before.key);assert.equal(after.data,before.data);assert.notEqual(h.button(0),b);
        if(when==='down')h.fire('pointerup',b);h.fire('click',h.button(0));
        assert.deepEqual(h.keys,[]);assert.equal(h.shared.getMobileRenderDiagnostics().rebuildHistory.at(-1).checks.keySame,false);
    });
}

for(const field of RAW.filter(name=>name!=='g_hdSpeActive')){
    test(`pictorial-key retains the existing strict fence for ${field}`,()=>{
        const h=fixture({diagnostics:true}),b=h.button(0);h.fire('pointerdown',b);
        assert.equal(h.api.debugSnapshot().diagnostics.last.down.reason,'armed');h.data[field]++;
        h.fire('pointerup',b);h.fire('click',b);assert.deepEqual(h.keys,[]);
        assert.notEqual(h.api.debugSnapshot().diagnostics.last.up.reason,'grant-created');
    });
}

test('pictorial-key background normalization still rejects same-values opaque data replacement after release',()=>{
    const h=fixture({diagnostics:true}),b=h.button(0);h.fire('pointerdown',b);h.fire('pointerup',b);
    h.rebind();h.data.g_hdSpeActive=1;h.fire('click',b);
    const click=h.api.debugSnapshot().diagnostics.last.click;
    assert.equal(click.reason,'owner-data-changed');assert.equal(click.checks.keySame,true);assert.deepEqual(h.keys,[]);
});
