import fs from 'node:fs';
import http from 'node:http';
const directory=process.argv[2],rows=fs.readFileSync(directory+'/owned-process-samples.jsonl','utf8').trim().split('\n').map(x=>JSON.parse(x));
const last=rows.findLast(r=>r.rootVerified),root=last.owned.find(r=>r.ProcessId===last.rootPid),port=Number(root.CommandLine.match(/--remote-debugging-port=(\d+)/)[1]);
const targets=await new Promise((resolve,reject)=>http.get('http://127.0.0.1:'+port+'/json/list',r=>{let b='';r.on('data',x=>b+=x);r.on('end',()=>resolve(JSON.parse(b)));}).on('error',reject));
const target=targets.find(t=>t.type==='page'),ws=new WebSocket(target.webSocketDebuggerUrl);
const timeout=setTimeout(()=>{ws.close();throw Error('Owned diagnostic timed out');},25000);
await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
const result=await new Promise(resolve=>{ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id===1)resolve(m);});
 ws.send(JSON.stringify({id:1,method:'Runtime.evaluate',params:{returnByValue:true,expression:`(() => {
 const s=BayeHdCityMenu.debugSnapshot(),p=baye.hd.personProperties();
 return {at:new Date().toISOString(),person:s.personDetail?.personIndex,equipment:s.personDetail?.equipment,menu:baye.hd.menuItems(),
 properties:{pageStart:p.pageStart,pageEnd:p.pageEnd,paintSeq:p.paintSeq},keys:__mobileMapKeys.slice(-12),
 scrollers:['hd-city-menu-person-details','hd-city-menu-person-properties-fields','hd-city-menu-deep'].map(id=>{const n=document.getElementById(id);return {id,scrollTop:n?.scrollTop,scrollHeight:n?.scrollHeight,clientHeight:n?.clientHeight};})};})()`}}));});
clearTimeout(timeout);ws.close();fs.writeFileSync(directory+'/root-live-diagnostic.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result.result?.result?.value||result));
