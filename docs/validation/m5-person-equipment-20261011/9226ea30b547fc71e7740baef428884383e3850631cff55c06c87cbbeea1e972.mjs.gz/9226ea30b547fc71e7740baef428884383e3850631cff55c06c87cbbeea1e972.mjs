import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const base='build/person-equipment-20261011',stem='m5-person-equipment-20261011';
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const mobile=read(base+'/mobile-v2/result.json'),pcs=['pc-1080-v2','pc-720-v1'].map(n=>({name:n,result:read(base+'/'+n+'/result.json')}));
const failed=read(base+'/mobile-v1/result.json'),failedPc=read(base+'/pc-1080-v1/result.json'),suite=read(base+'/final-suite/result.json'),cleanup=read(base+'/cleanup-verification.json');
assert.equal(failed.accepted,false);assert.equal(mobile.accepted,true);assert.equal(mobile.sourceDrift.length,0);
assert.equal(failedPc.ok,false);assert.equal(failedPc.accepted,false);assert.equal(failedPc.equipmentAccepted,false);assert.ok(failedPc.finishedAt);
for(const p of pcs){
 const r=p.result;assert.equal(r.ok,true);assert.equal(r.accepted,true);assert.equal(r.equipmentAccepted,true);assert.equal(r.hdAccepted,true);assert.ok(r.finishedAt);
 assert.equal(r.exceptions.length,0);assert.equal(r.sourceVerification.ok,true);assert.equal(r.sourceVerification.drift.length,0);assert.equal(r.sourceVerification.added.length,0);
 assert.equal(r.cleanup.treeExited,true);assert.equal(r.serverClosed,true);assert.equal(r.people.length,3);
 assert.equal(r.summary.people,3);assert.equal(r.summary.cards,3);assert.equal(r.summary.propertyRows,18);assert.equal(r.summary.cardInspectionKeys,0);assert.equal(r.summary.nativeTouches,0);
 for(const x of r.people){assert.equal(x.equipmentCards.length,1);assert.equal(x.equipmentCards[0].accepted,true);assert.equal(x.equipmentCards[0].visible.length,x.equipmentCount*6);assert.equal(x.equipmentCards[0].keys.length,0);}
}
assert.equal(suite.exitCode,0);assert.equal(suite.sourceDrift.length,0);assert.equal(cleanup.ok,true);
const archive=read('docs/validation/'+stem+'-archive.json');
const ref=source=>{const r=archive.entries.find(e=>e.source===source);assert.ok(r,source);return r;};
const layouts=[...mobile.previewChecks.map(p=>({name:p.label,people:p.equipmentCards.map(c=>({personId:c.personId,name:c.snapshot.name,cards:c.expected.length,visibleRows:c.visible.length,nativeKeys:c.keys.length})),
  properties:p.checks.filter(c=>c.kind==='visible-current-property'&&c.menuKind===3).length,scrolls:p.scrollChecks.length})),
  ...pcs.map(p=>({name:p.name,people:p.result.people.map(x=>({personId:x.personId,name:x.name,cards:x.equipmentCount,visibleRows:x.equipmentCards[0].visible.length,nativeKeys:x.equipmentCards[0].keys.length})),summary:p.result.summary}))];
const sourcePaths=['js/hd-city-menu.js','css/hd-city-menu.css','css/hd-mobile.css','pc.html','m.html','package.json','scripts/test-hd-city-hud.mjs','scripts/hd-person-equipment-runtime-checks.mjs','scripts/hd-mobile-preview-runtime-checks.mjs','scripts/test-hd-mobile-city-runtime.mjs','scripts/test-hd-person-equipment-runtime.mjs'];
const sources=sourcePaths.map(path=>{const b=fs.readFileSync(path);return {path,bytes:b.length,sha256:sha(b)};});
const result={schemaVersion:1,createdAt:new Date().toISOString(),globalHdComplete:false,status:'partial',originalOnly:true,versionSelectorRemoved:true,
 product:'Current standard-original CITY/context1/kind3 PERSON details show read-only actual equipment cards; five tool attributes plus range description. Native equipment and derived stats remain authoritative.',
 scope:'P1 DongZhuo Luoyang double/single/empty equipment at PC1920x1080/1280x720 and emulated mobile844x390/667x375. Every displayed field checked against real ROM; card reads/scrolls zero keys and unchanged measured native world.',
 layouts,sources,suite:{...suite,sources:undefined,sourceCount:suite.sources.length,evidence:ref(base+'/final-suite/result.json'),log:ref(base+'/final-suite/test-output.log')},
 attempts:[{name:'mobile-v1',accepted:false,error:failed.error,evidence:ref(base+'/mobile-v1/result.json')},{name:'mobile-v2',accepted:true,evidence:ref(base+'/mobile-v2/result.json')},
 {name:'pc-1080-v1',accepted:false,classification:'tool-geometry-failure',error:failedPc.error,
  reason:'The geometry probe treated zero-height BODY/HTML normal-flow boxes as clipping ancestors of a fixed HD layer. The actual root buttons were visible in the saved screenshot; card inspection had not started.',
  correction:'Only the tool viewport-root clipping calculation was corrected; product and input authorization were unchanged. Fresh pc-1080-v2 passed the complete PC equipment scenario.',
  evidence:ref(base+'/pc-1080-v1/result.json'),screenshot:ref(base+'/pc-1080-v1/failure-equipment.png'),executedTool:ref(base+'/pc-1080-v1/executed-tool.mjs')},
 ...pcs.map(p=>({name:p.name,accepted:true,evidence:ref(base+'/'+p.name+'/result.json')})),
 {name:'pc-preflight-v1',accepted:false,preflightOnly:true,evidence:ref(base+'/pc-preflight-v1/result.json')}],
 cleanup:{...cleanup,evidence:ref(base+'/cleanup-verification.json')},native:{changed:false,sourceCount:128,sourceSha256:pcs[0].result.nativeSourceCheck.aggregate,installedManifest:pcs[0].result.engineManifest},
 limits:['No new native build or gameplay changes','Actual acceptance covers only initial equipment in the sampled original P1 city; other cities/periods, all tool classes and changed equipment require further actual coverage',
 'Library/custom/missing/race fallback is tested in pure VM; no claim of actual Mod workflow','Measured world equality is not full ABI or RNG continuity','Real Android/iOS and performance remain pending'],
 archive:'./'+stem+'-archive.json'};
fs.writeFileSync('docs/validation/'+stem+'.json',JSON.stringify(result,null,2)+'\n');
const counts=suite.counts;
const note=`2026-10-11 最新[原版人物装备属性卡](validation/${stem}.md)：原版CITY/context1/kind3当前人物详情直接显示实际装备的用法、武力／智力／移动加成、兵种变化与攻击范围说明，限定当前原版LIB及真实人物／两槽／代次双读，不增加输入。P1董卓洛阳吕布双装备、董卓单装备、李儒空装备，在PC1080／720及手机模拟844×390／667×375共四种布局核对原版ROM名称、六字段、可见滚动及零卡片指令，已采世界不变。新增57项专项，最终${suite.modules}模块串行 **${counts.pass}／${counts.tests}通过**，失败／取消／跳过／todo均0，${suite.sources.length}执行来源无漂移。mobile-v1滚动工具失败、pc-1080-v1视口裁切探针失败与各自修复后的完整实跑均保留；无新native构建，全部私局退出、原8080服务不变。其它人物／时期、完整HD、真机及性能仍待，完整HD保持 **partial**。`;
const md=`# 原版人物装备属性卡验证（2026-10-11）\n\n${note.replace('最新[原版人物装备属性卡](validation/'+stem+'.md)：','')}\n\n## 产品行为\n\n原版标准LIB的CITY/context1/kind3当前人物详情直接显示两槽已装备道具的真实属性；本批不扩展其它人物显示上下文。名称、用法、加成和兵种变化来自当前标准资源；攻击范围仅显示是否改变，具体范围仍以战场为准。卡片为只读，人物的武力和智力数值不重复叠加装备收益。电脑使用原有方向键切换人物，手机使用原有“查看”。\n\n原版身份、完整人物ID／名称名单、当前焦点、两个装备槽、资源数量、对象引用与详情代次均复核。工具读数两遍不一致、缺失资源、自定义属性、重入或菜单退休时不发布卡片，原有名称回退保留。本批不增加装备或卸装操作。\n\n## 实际验证\n\n| 布局 | 人物 | 卡片／可见字段 | 卡片读取与滚动原生键 |\n| --- | --- | --- | --- |\n${layouts.map(l=>'| '+l.name+' | '+l.people.map(p=>p.name+'('+p.personId+')').join('、')+' | '+l.people.reduce((n,p)=>n+p.cards,0)+'／'+l.people.reduce((n,p)=>n+p.visibleRows,0)+' | '+l.people.reduce((n,p)=>n+p.nativeKeys,0)+' |').join('\n')}\n\nPC两尺寸分别独立公开新局；手机两尺寸在同一公开新局中依次验证。每项卡片名称与六个字段均由独立读取原版LIB资源66／73比对，DTO原始字段、行、来源及当前人物票据均核对。浏览与实际滚动保持已采200人物、38城池、队列、装备、道具资源及订单等字段不变，0LCD触摸。手机同时完成原生13属性显式分页、两道具属性浏览、取消与返回地图回归。\n\n## 失败记录与边界\n\nmobile-v1未接受：旧手势起点落在静态分页按钮区域，36次滚动在1217／1328之间循环，未读全原生人物属性。独立审查核对所有36次为零键、票据与已采世界不变；焦点滚动原因有据推断，未直接采focusin。修正工具选点为实际非交互区域后，mobile-v2完成原生属性回归及全部装备卡。本批没有以跳过原生回归来取得通过。预检只证明来源／清单，不算浏览器接受。早期单测名称预期遗漏编号的失败日志也保留。\n\npc-1080-v1未接受，单独归为工具几何探针失败：探针把BODY／HTML正常文档流中的零高度盒误当成固定HD层的裁切边界，导致“内政”按钮被误判不可见；失败截图中真实按钮实际可见，尚未开始装备卡验收。仅修正工具对视口根节点裁切的处理，未改产品或放宽输入票据；fresh pc-1080-v2完成完整场景并通过，pc-720-v1也独立通过。pc-1080-v1原始result、failure-equipment.png和executed-tool.mjs均单独归档，不用后续成功覆盖失败。\n\n最终默认${suite.modules}模块串行${counts.tests}项全部通过；无失败、取消、跳过或todo，${suite.sources.length}来源无漂移。原生128份来源聚合仍为\`${pcs[0].result.nativeSourceCheck.aggregate}\`，安装四件与manifest一致，无新原生构建。独立OS核对${cleanup.recordedCount}个历史身份无存活、私有端口全部关闭，8080仍为原PID57860／出生时间及HTTP200。私有浏览器目录保留，未删除。\n\n接受仅限本批实际场景；其它城市／时期、更多道具类别、装备改变后的实跑、完整ABI／RNG、真机及性能待验。原版单一入口及移除版本切换保持，完整HD仍为partial。\n\n[结构化结果](${stem}.json) · [归档索引](${stem}-archive.json)\n`;
fs.writeFileSync('docs/validation/'+stem+'.md',md);
for(const name of ['docs/hd-remaining-work.md','docs/hd-development-plan.md']){
 let text=fs.readFileSync(name,'utf8');const first=text.indexOf('\n');text=text.slice(0,first+1)+'\n'+note+'\n'+text.slice(first+1).replace('2026-10-11 最新[原版战场状态效果高清场景]','2026-10-11 前批[原版战场状态效果高清场景]');
 if(name.endsWith('hd-remaining-work.md'))text=text.replace('人物原生属性捕获、显式分页与模式恢复已验，完整视觉仍为 partial','人物原生属性捕获、显式分页与模式恢复已验；原版当前人物装备六字段卡及四布局零键只读已验，完整视觉仍为 partial');
 fs.writeFileSync(name,text);
}
console.log(JSON.stringify({layouts:layouts.length,tests:counts.tests,sources:suite.sources.length,globalHdComplete:false}));
