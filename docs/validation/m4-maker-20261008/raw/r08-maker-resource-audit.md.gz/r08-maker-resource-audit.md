# R08 制作群组原生资源审计

日期2026-10-08；base `30ab9a8`。只读复核标准LIB、实际C和原生参考，没有运行/改写游戏，也没有生成美术。详细字段及96个时间单元见 `build/r08-maker-resource-audit.json`。

## 实际资源与输入图

- `libs/dat-mod.lib`：207195bytes，SHA-256 `3bd20146084054163d045c90987c756a6a210664e78253cc56bc4a274727903e`。
- MAKER_SPE6/index0：资源起点18481，RCHEAD14bytes，完整项2413bytes，`fnv1a32:b961053e:2413`，payload SHA-256 `1bf7052e0272c3ebcc4385b7716dfc9bf67465ecd007a5f894025e0c35ffc277`。
- SPERES六bytes为 `[0,0,96,1,0,95]`；96units全部x0、y95→0逐次减1、cdelay10、ndelay10、picIndex0。
- 唯一图片槽：159×96/count1/mask0；item offset486，bitmap offset493，20bytes/row、1920bitmap bytes，末尾无剩余。
- 实际输入PNG `build/r07-spe-native/resource-6-index-0-picture-0.png`，2184bytes、RGBA、159×96，SHA-256 `8f80160866de44d2425ff62fb9078484aa3c8d4d3bcf92a5f5c44f19987a104e`。Fresh实际MSB-first逐bit解码与其RGBA一致；没有resize/crop任何保存图片。

## 文字与画面

实际 view 原生PNG，并用内存整数倍最近邻显示复查字形；也实际 view `build/r08-maker-baseline-v2/04-full-natural-1080p-classic-hold.png`。原图是制作署名位图，以下属于像素的视觉转写，不是可提取的GBK字符串或引擎人物身份字段：

1. 策划：BBK Game Group
2. 程序：谢育虫
3. 南方小鬼
4. 美工：Sword.dy
5. 2005年7月30日

首次将程序署名末字读作“杰”是误读，已在生成前纠正。放大真实图可见口/贯穿竖、下横及点的“虫”，没有“杰”的木+灬；主任务独立复查同样发现此点，不能用推测真实姓名改写原署名。

第一行位于上方，程序标签和第一个署名在下一行，“南方小鬼”再下一行按姓名起点缩进，不重复程序标签；美工行在下半部分，日期位于底部中央偏右。原生坐标的近似可见区在JSON逐项记录，只作美术布局参考，不伪造文本桥。

左右各窄黑白棋盘边带，内侧细矩形框。程序第一行右边有圆脸/短弯身体的小虫样轮廓；下一行右边有毛茸/小鬼样不规则脸轮廓。均为小符号，不是新增武将头像。没有另一个公司图形logo、霸业标题、龙纹战斗、人物或场景。

## 原生行为与覆盖边界

`gamEng.c:321`主菜单choice2进入 `GamMakerInf:417`。先清scratch，再通过原有单次 `call_hook_a("showAbout",NULL)`：仅返回-1播放默认制作动画，其他返回由Mod处理。不得新增hook探测或二次调用。

默认 `GamMovie6→PlcMovie(6,0,0,255,true,0,0)`，原生结束帧裁为95。159×96唯一图片从y95移动到0，按原生视口逐渐露出；96是位置/时间单元，不是96张素材。当前SPE桥对6自动归OPENING1，`g_hdMovieId`跟踪仍只用于MAIN3。

自然结束时最后unit95保留在0,0，`PlcMovie`发布end，SPEactive退役。随后 `GamMakerInf`运行 `GamDelay(5000,2)`，没有新绘图/静态resource调用。Web timer ratio10ms，名义5000ticks约50秒，实际仍受调度影响；原生任一VM_CHAR_FUN或touchUP可结束尾等，timer0不是用户ACK。

`GamMakerInf`忽略 `GamMovie`返回值：提前按键跳过也进入尾等，此时LCD可以停在中间滚动位置。不能一见end就假设完整最后图已显示，也不能固定换成y0的信用卡。尾等结束后返回真正主菜单循环，不自动确认/选项。

当前C没有独立about-hold生命周期观察字段。只加MAKER6素材manifest可覆盖active滚动部分，却不足以安全识别并替换post-SPE静态尾等。完整替换需从实际原生调用建立只读owner/代次/阶段，同时保留提前skip实际显示位置、hook自定义回退、实际未知LIB回退、报告/菜单/新世界退休，不能按菜单inactive或本地计时猜测静态尾等。

图片逻辑宽度159和x0必须保留：160屏幕上最后一列余白不应被居中padding或拉伸吞掉。本审计没有发键、改原生状态、编辑LIB/C/WASM或触碰8080服务。
