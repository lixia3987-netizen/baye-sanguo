@echo off
call "F:\env\vs\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
set "CC=F:\project\baye-sanguo\build\toolchain\emsdk\upstream\bin\clang.exe"
call npm test > build/r08-all-tests.log 2>&1
exit /b %errorlevel%
