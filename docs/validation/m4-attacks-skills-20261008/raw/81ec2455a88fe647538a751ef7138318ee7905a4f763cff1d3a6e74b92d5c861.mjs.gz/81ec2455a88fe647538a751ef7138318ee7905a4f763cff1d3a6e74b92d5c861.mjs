import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
const base='docs/validation/m4-attacks-skills-20261008',file=base+'/runtime-index.json';
const r=JSON.parse(fs.readFileSync(file)),groups=new Map();
const primary=new Set(['r10-cavalry-staged-v6','r10-infantry-staged-v3','r10-infantry-installed-digitfit','r10-skill-installed-1080-final-v3','r10-skill-installed-720-final']);
for(const i of r.images.filter(x=>x.retained)){
  const dir=i.original.split('/')[1],name=path.posix.basename(i.original);
  if(/opening|maker/.test(dir)||/-native\.png$|-lcd\.png$/.test(name))continue;
  if(primary.has(dir)&&/^(attack-|fire-)/.test(name))continue;
  const type=/^(attack-|fire-).*hd\.png$/.test(name)?'capture-hd':'whole-page';
  const key=dir+'/'+type;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(i);
}
for(const [group,list] of groups){
  list.sort((a,b)=>a.original.localeCompare(b.original));
  const keep=new Set([list[0],list.at(-1)]);
  if(group.endsWith('capture-hd'))keep.add(list[Math.floor(list.length/2)]);
  if(primary.has(group.split('/')[0]))for(const i of list)if(/06[ab]-|14-battle-ready/.test(i.original))keep.add(i);
  for(const i of list){if(keep.has(i)||/hold/.test(i.original))continue;
    i.retained=false;i.omittedArchivePath=i.archived;delete i.archived;
    i.omittedReason='Intermediate whole-page or compatibility-regression HD PNG omitted from committed archive; exact hash/size, full native snapshots/input stream/pixel/draw JSON and selected keyframes retained. Original build output unchanged.';
  }
}
const needed=new Set(r.images.filter(x=>x.retained).map(x=>path.resolve(x.archived)));
const collect=v=>{if(typeof v==='string'&&v.includes(base+'/png/'))needed.add(path.resolve(v));else if(Array.isArray(v))v.forEach(collect);else if(v&&typeof v==='object')Object.values(v).forEach(collect);};collect(JSON.parse(fs.readFileSync(base+'/art-input-index.json')));
const root=path.resolve(base+'/png');let removed=0;
for(const i of r.images.filter(x=>!x.retained)){const p=path.resolve(i.omittedArchivePath);assert.equal(path.dirname(p),root);assert.match(path.basename(p),/^[a-f0-9]{64}\.png$/);if(!needed.has(p)&&fs.existsSync(p)){fs.unlinkSync(p);removed++;}}
r.scope='All completed real-browser raw reports/capture JSON/input/source records retained as gzip original bytes. All actual native LCD PNGs and primary new cavalry/infantry plus final digit-fit FIRE capture pairs retained. Intermediate whole-page/compatibility/MAKER/old-FIRE HD PNGs selectively omitted with exact hash/size/reason; selected original HD keyframes retained. No historical source tuple is upgraded to final acceptance.';
r.pngRetention={retained:r.images.filter(x=>x.retained).length,omitted:r.images.filter(x=>!x.retained).length,removedUniquePngThisStep:removed,policy:'All actual native LCD PNGs retained. Complete callback HD pairs retained for primary new cavalry/infantry and final digit-fit FIRE. Compatibility and old HD regressions retain first/midpoint/last/holds; whole-page checks retain selected keyframes. Art inputs preserved independently.'};
fs.writeFileSync(file,JSON.stringify(r,null,2)+'\n');console.log(r.pngRetention);
