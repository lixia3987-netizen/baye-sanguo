import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const base='docs/validation/m4-attacks-skills-20261008';
const file=base+'/runtime-index.json',r=JSON.parse(fs.readFileSync(file));
const groups=new Map();
for(const i of r.images){
  const maker=/^build\/r10-maker-staged-regression\/[^/]+\/.*-hd\.png$/.test(i.original);
  const oldFire=/^build\/r10-skill-(?:staged-|installed-1080-final\/)/.test(i.original)&&/-hd\.png$/.test(i.original);
  if(maker||oldFire){const group=path.posix.dirname(i.original);if(!groups.has(group))groups.set(group,[]);groups.get(group).push(i);}
}
for(const [group,list] of groups){
  list.sort((a,b)=>a.original.localeCompare(b.original));
  const chosen=new Set([list[0],list.at(-1),list[Math.floor(list.length/2)]]);
  for(const i of list){
    if(chosen.has(i)||/hold/.test(i.original))continue;
    i.retained=false;i.omittedReason='Intermediate HD regression PNG omitted from committed archive; original hash/size and complete source-stamp/draw/pixel JSON remain. Actual LCD PNGs and selected HD keyframes retained. Original build output is unchanged.';
    i.omittedArchivePath=i.archived;delete i.archived;
  }
}
const needed=new Set(r.images.filter(i=>i.retained).map(i=>path.resolve(i.archived)));
const art=JSON.parse(fs.readFileSync(base+'/art-input-index.json'));
// Art evidence shares the same SHA directory; preserve every path present in
// that independent index even if a runtime screenshot has the same bytes.
const collect=v=>{if(typeof v==='string'&&v.includes(base+'/png/'))needed.add(path.resolve(v));else if(Array.isArray(v))v.forEach(collect);else if(v&&typeof v==='object')Object.values(v).forEach(collect);};collect(art);
const pngRoot=path.resolve(base+'/png');let removed=0;
for(const i of r.images.filter(i=>!i.retained)){
  const abs=path.resolve(i.omittedArchivePath);
  assert.equal(path.dirname(abs),pngRoot);assert.match(path.basename(abs),/^[a-f0-9]{64}\.png$/);
  if(!needed.has(abs)&&fs.existsSync(abs)){fs.unlinkSync(abs);removed++;}
}
r.scope='Completed real-browser and actual-native evidence. All actual LCD callback PNGs and primary new cavalry/infantry and final digit-fit FIRE PNG pairs retained as original bytes. Intermediate MAKER and pre-digit-fit FIRE HD regression PNGs selectively omitted with hashes/reasons; complete raw capture JSON retained. Historical runs are not upgraded to final source acceptance.';
r.pngRetention={retained:r.images.filter(i=>i.retained).length,omitted:r.images.filter(i=>!i.retained).length,removedUniquePng:removed,policy:'No native LCD image or art input is omitted. All primary new attack and final digit-fit FIRE images retained. MAKER and old FIRE intermediate HD only: first, midpoint, last and hold keyframes retained.'};
fs.writeFileSync(file,JSON.stringify(r,null,2)+'\n');console.log(r.pngRetention);
