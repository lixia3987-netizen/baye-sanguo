import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const expected={
  'baye.js':'71e906da1485bebb598607d1e3899dbc240bb936615b57770c3e09ddecd96f60',
  'baye.wasm':'bd708dd8c7561c383c05ea0ca88c8164b5aa6d467f5ad5f42dcb19b965d3973e',
  'baye.wasm.map':'e2364dd054be4665e48ac96601046b9f06d5a01a808d547ca200514c2fa797a4',
  'baye.build.json':'59191e60421006bf3c43a4fb51f9e5f22494d47ff3533fa985f6f96c58971dc8'
};
for(const [file,hash] of Object.entries(expected))assert.equal(sha(fs.readFileSync('build/wasm/src/'+file)),hash,file);
const files=[];
for(const [file,hash] of Object.entries(expected)){
  const bytes=fs.readFileSync('build/wasm/src/'+file);fs.writeFileSync('js/'+file,bytes);
  assert.deepEqual(fs.readFileSync('js/'+file),bytes);files.push({staged:'build/wasm/src/'+file,installed:'js/'+file,bytes:bytes.length,sha256:hash,byteEqual:true});
}
const manifest=JSON.parse(fs.readFileSync('js/baye.build.json'));
assert.equal(manifest.sourceRevision,'9ca9c40855ddc545667179abfc094a5203cb6036');
assert.equal(manifest.engineSourceSha256,'56b01e4becf3c06e6b4cc154dfa6585e37a2c9aa91cd3ada744420c72228e02f');
assert.equal(manifest.engineSourceModified,true);
fs.writeFileSync('build/r10-install-proof.json',JSON.stringify({installedAt:new Date().toISOString(),sourceRevision:manifest.sourceRevision,engineSourceModified:true,engineSourceSha256:manifest.engineSourceSha256,files},null,2)+'\n');
console.log(JSON.stringify({installed:true,files:files.length,sourceRevision:manifest.sourceRevision}));
