import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import assert from 'node:assert/strict';
const base='docs/validation/m4-attacks-skills-20261008';
fs.mkdirSync(base+'/raw',{recursive:true});fs.mkdirSync(base+'/png',{recursive:true});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const prior=fs.existsSync(base+'/runtime-index.json')?JSON.parse(fs.readFileSync(base+'/runtime-index.json')):{files:[],images:[]};
const raws=new Map(prior.files.map(x=>[x.original,x])),images=new Map(prior.images.map(x=>[x.original,x]));
function exact(p,b){if(fs.existsSync(p))assert.deepEqual(fs.readFileSync(p),b);else fs.writeFileSync(p,b);}
function save(file){const b=fs.readFileSync(file),hash=sha(b);
    if(file.endsWith('.png')){
        const archived=base+'/png/'+hash+'.png';exact(archived,b);images.set(file,{original:file,archived,bytes:b.length,sha256:hash,originalBytesPreserved:true,retained:true});
    }else{
        const archived=base+'/raw/'+hash+'.'+(path.extname(file).slice(1)||'raw')+'.gz',compressed=zlib.gzipSync(b,{level:9});
        exact(archived,compressed);const packed=fs.readFileSync(archived);assert.deepEqual(zlib.gunzipSync(packed),b);
        raws.set(file,{original:file,archived,bytes:b.length,sha256:hash,gzipBytes:packed.length,gzipSha256:sha(packed),decompressedByteEqual:true});
    }
}
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>{const p=dir+'/'+e.name;return e.isDirectory()?walk(p):[p];});}
for(const item of process.argv.slice(2)){
    if(fs.statSync(item).isDirectory()){
        const report=JSON.parse(fs.readFileSync(item+'/result.json'));assert(report.finishedAt||report.sourceVerification||report.isolation?.cleaned);
        for(const f of walk(item).filter(f=>/\.(png|json|log|mjs|txt|rgba)$/.test(f)))save(f);
    }else save(item);
}
const rows=[...images.values()];
const report={capturedAt:new Date().toISOString(),scope:'Completed real-browser and actual-native evidence; original raw text/JSON/source bytes retain gzip roundtrip checks. All actual native LCD and primary new cavalry/infantry plus final digit-fit FIRE callback PNG pairs retained as original bytes. Intermediate HD regression and whole-page PNGs selectively omitted with hashes/reasons. No historical run is upgraded to final source acceptance.',files:[...raws.values()],images:rows,
    pngRetention:{retained:rows.filter(x=>x.retained).length,omitted:rows.filter(x=>!x.retained).length,policy:'All actual native LCD PNGs retained. Complete callback HD pairs retained for primary new cavalry/infantry and final digit-fit FIRE. Intermediate HD regressions and whole-page checks retain selected original keyframes; omitted items preserve hash/size/reason. Art inputs preserved independently.'}};
fs.writeFileSync(base+'/runtime-index.json',JSON.stringify(report,null,2)+'\n');
console.log({raw:raws.size,logicalPNG:images.size,uniquePNG:new Set([...images.values()].map(p=>p.sha256)).size});
