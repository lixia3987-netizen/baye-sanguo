import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import assert from 'node:assert/strict';
const pre='build/mobile-minimap-validation-20261011',id='m5-mobile-minimap-20261011',base='docs/validation/'+id;
const runs=['844-v1','844-v2','844-v3','844-v4','844-v5','667-v1','667-v2'].map(n=>'build/mobile-minimap-installed-'+n+'-20261011');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const ref=p=>{const b=fs.readFileSync(p);return {path:p,bytes:b.length,sha256:sha(b)};};
const reports=runs.map(dir=>({dir,r:read(dir+'/result.json')})),accepted=reports.filter(x=>x.r.accepted);
assert.equal(accepted.length,2);assert.deepEqual(accepted.map(x=>x.r.minimapWidth),[844,667]);
for(const {r} of accepted){assert.equal(r.ok,true);assert.equal(r.minimapAccepted,true);assert.equal(r.fullHdAccepted,false);assert.equal(r.realDeviceAccepted,false);assert.equal(r.exceptions.length,0);assert.equal(r.nativeTouches.length,0);assert.equal(r.sourceDrift.length,0);assert.equal(r.cleanup.treeExited,true);assert.equal(r.serverClosed,true);assert.equal(r.minimapChecks[0].rounds.length,2);assert.equal(r.minimapChecks[0].negativeChecks.length,3);for(const f of r.sourceFiles)assert.equal(ref(f.path).sha256,f.sha256);}
const sources=accepted.map(x=>x.r.sourceFiles.map(f=>[f.path,f.bytes,f.sha256]).sort((a,b)=>a[0].localeCompare(b[0])));assert.deepEqual(sources[0],sources[1]);
const tests=read(pre+'/final-suite/final-test-sources.json');assert.equal(tests.modules,81);for(const f of tests.files)assert.equal(ref(f.path).sha256,f.sha256);
const suite=p=>{const s=fs.readFileSync(p,'utf8'),v={log:ref(p)};for(const k of ['tests','pass','fail','cancelled','skipped','todo','duration_ms'])v[k]=Number(s.match(new RegExp('ℹ '+k+' ([\\d.]+)'))?.[1]);return v;};
const full=suite(pre+'/final-suite/full-suite-serial-v3.log');assert.equal(full.pass,3354);for(const k of ['fail','cancelled','skipped','todo'])assert.equal(full[k],0);
const cleanup=read(pre+'/cleanup-user8080-verification.json');assert.equal(cleanup.user8080Unchanged,true);assert.equal(cleanup.allRuntimeCleanupPassed,true);assert.equal(cleanup.survivingRecorded.length,0);assert.equal(cleanup.privateListeners.length,0);
const tested=accepted[0].r.engine;assert.equal(tested.sourceTree.verified,true);assert.equal(tested.sourceTree.count,128);for(const f of tested.files)assert.equal(ref(f.path).sha256,f.sha256);
for(const name of fs.readdirSync('build').filter(n=>/^mobile-minimap.*\.log$/.test(n))){const dst=pre+'/history-'+name;if(!fs.existsSync(dst))fs.copyFileSync('build/'+name,dst,fs.constants.COPYFILE_EXCL);}
assert.ok(!fs.existsSync(base));fs.mkdirSync(base+'/raw',{recursive:true});
const seen=new Map(),entries=[];
const add=file=>{const b=fs.readFileSync(file),hash=sha(b);let zipped=seen.get(hash);if(!zipped){const name=hash.slice(0,16)+'-'+path.basename(file)+'.gz',g=zlib.gzipSync(b,{level:9});fs.writeFileSync(base+'/raw/'+name,g,{flag:'wx'});zipped={file:id+'/raw/'+name,gzipBytes:g.length,gzipSha256:sha(g)};seen.set(hash,zipped);}entries.push({source:file,bytes:b.length,sha256:hash,...zipped});};
const walk=dir=>{for(const name of fs.readdirSync(dir)){const p=dir+'/'+name;if(fs.statSync(p).isFile())add(p);else if(name!=='private-browser-profile')walk(p);}};
walk(pre);for(const dir of runs)walk(dir);
for(const e of entries){const b=zlib.gunzipSync(fs.readFileSync('docs/validation/'+e.file));assert.equal(b.length,e.bytes);assert.equal(sha(b),e.sha256);}
const archive={schemaVersion:1,createdAt:new Date().toISOString(),globalHdComplete:false,portableClosedArchive:false,scope:'Batch raw logs, screenshots, failed/passed runs, frozen production/native/test sources. Private browser profiles and host toolchain excluded.',logicalFiles:entries.length,uniqueGzipFiles:seen.size,gzipBytes:[...seen.values()].reduce((n,x)=>n+x.gzipBytes,0),roundTripExact:true,entries};
fs.writeFileSync(base+'-archive.json',JSON.stringify(archive,null,2)+'\n',{flag:'wx'});
const summarize=({dir,r})=>{const e=r.minimapChecks[0];return {directory:dir,ok:r.ok,accepted:r.accepted,viewport:[r.minimapWidth,r.minimapWidth===844?390:375],phases:r.phases.length,nativeKeys:r.nativeKeys?.length,nativeTouches:r.nativeTouches?.length,sources:r.sourceFiles.length,sourceDrift:r.sourceDrift,exceptions:r.exceptions.length,treeExited:r.cleanup.treeExited,serverClosed:r.serverClosed,error:r.error,result:ref(dir+'/result.json'),overview:e&&{accepted:e.accepted,rounds:e.rounds.length,negativeChecks:e.negativeChecks.map(n=>n.type),touchPans:e.scrollChecks.length,originalCities:e.originalCities,cycles:e.rounds.map(v=>({round:v.round,keys:v.keys,visibleCities:v.visibleCities,bitmap:v.bitmap,scrolls:v.scrolls.length,returnedHud:v.returned.state.hud,native:v.opened.overview.native}))}};};
const record={schemaVersion:1,date:'2026-10-11',accepted:true,scope:'Original era1 Dong Zhuo mobile SEARCH overview in Chrome touch emulation at 844x390 and667x375. Two real native51/40 cycles per viewport, all38 city names/allegiance/coordinates and readonly scroll.',globalHdComplete:false,realDeviceAccepted:false,wholeNativeAbiAccepted:false,newNativeBuild:false,defaultParallelSuiteAccepted:false,implementation:{originalLibrary:ref('libs/dat-mod.lib'),mapTicket:'Strict ordinary MAP double-read with opaque data reference, current original identity and no march/transfer target owner',returnTicket:'Native SEARCH seq/generation/inputSeq, all raw fields and blockers double-read, current data reference and complete original38-city assets',input:'Header trusted pointer or focused Enter/Space emits oneSEARCH51. Shared return trusted DOWN/UP/click emits oneEXIT40. Expired, multitouch, scroll and lifecycle gestures retire without keys.',fixes:['Initial hidden-layout drawing retries without caching an empty canvas','Page lock permits only current original mobile overview city-list pans','Normal post-UP implicit capture release retains current grant; lost capture before UP retires it','Fresh mobile native owner resets city-list scroll while same owner preserves user scroll']},tests:{fullList:{...full,modules:81,testConcurrency:1,nodeVersion:process.version,sourceManifest:ref(pre+'/final-suite/final-test-sources.json')},earlierFullLists:[suite(pre+'/full-suite-serial-v1.log'),suite(pre+'/full-suite-serial-v2.log')],note:'Earlier complete runs passed before final browser-driven fixes; only v3 certifies final frozen sources. Focused counts overlap default list.'},engine:{newBuild:false,sourceRevision:tested.manifest.sourceRevision,engineSourceModified:tested.manifest.engineSourceModified,sourceTree:tested.sourceTree,files:tested.files},runtime:reports.map(summarize),acceptedSourcesByteEqual:true,visualInspection:{viewports:[[844,390],[667,375]],mapAndTextVisible:true,scope:'Local actual screenshots plus runtime clipping/hit tests; no real-phone or pixel-perfect claim'},cleanup,archive:{manifest:id+'-archive.json',logicalFiles:archive.logicalFiles,uniqueGzipFiles:archive.uniqueGzipFiles,gzipBytes:archive.gzipBytes,roundTripExact:true,portableClosedArchive:false},limits:['Only original mobile38-city SEARCH overview accepted. Battle HELP9/VIEW10, diplomacy actor-target lineage and other pending command paths are not accepted by this batch.','Monthly arrival/return, all periods/cities, complete succession/save/RNG/cloud flows, real Android/iOS and fixed-device performance remain pending.','Historical failed runs preserve their actual scope and source drift. Full HD remains partial.']};
fs.writeFileSync(base+'.json',JSON.stringify(record,null,2)+'\n',{flag:'wx'});
const md=`# 原版移动地图概览验证

手机横屏新增“概览”，由原版 SEARCH51 打开高清38城总览；原生当前归属决定可用时点，普通地图、出征与输送目标互不借票。城名、归属与原生坐标逐项核对，列表只读滑动，返回只发送一次 EXIT40。

| 手机模拟视口 | 完整打开／返回 | 全38城触控浏览 | 取消／双指／跨旋转 | 原生键／LCD触摸 |
|---|---:|---:|---|---:|
| 844×390 | 2轮 | 12次滑动 | 3项通过 | 16／0 |
| 667×375 | 2轮 | 14次滑动 | 3项通过 | 16／0 |

每局16键含12次真实标题／时期／君主开局键与两组51／40。只读浏览和三项取消均零键、零LCD触摸；已采原版世界与地图游标保持，返回后HUD逐字段一致。每局6检查点，198份来源无漂移、0未捕获异常，两个通过局来源路径及字节相同。实际截图已检查地图、文字及44px返回按钮可见；原生城池数据与全部38行的裁切、命中测试由浏览器记录。

实际验证发现并修复首次隐藏布局绘图缓存、全局页面锁阻止新列表滑动、正常抬指后隐式lostcapture误清返回授权，以及重新打开保留上次列表底部位置四处问题。取消、失焦、多指、滚动及当前节点／几何变更继续退休旧手势。5次失败局原件保留，其中第三次还记录到测试源码更新造成来源漂移；没有把失败重标为通过。

最终81模块串行 **3354／3354通过**，失败／取消／跳过／todo均0；${(full.duration_ms/1000).toFixed(3)}秒。此前两次完整列表3350／3351项通过发生在最终浏览器修复前，仅最终冻结来源对应第三次全量。无新native构建，沿用上一批输送的四件安装产物，128份原生来源聚合核对一致；原版唯一入口与暂停版本切换保持。

完整记录见[验证JSON](${id}.json)和[归档映射](${id}-archive.json)。归档${archive.logicalFiles}份逻辑文件去重为${archive.uniqueGzipFiles}份gzip，共${archive.gzipBytes}字节，全部解压核对。保存失败／通过局、截图、日志及冻结的页面、原生、测试来源；浏览器profile及SDK／宿主运行时排除，不是封闭可移植包。${cleanup.recordedIdentities}个历史测试身份退出、私有服务关闭，用户8080原PID／程序／创建时间保持且HTTP200。

仅接受本机Chrome手机模拟的原版地图概览。移动战场HELP／VIEW、外交双人物归属、其它待办命令、月末到达／归队、四时期完整流程、继任／完整存读档与RNG、云账号、Android／iOS真机及性能仍待，完整HD保持partial。
`;
fs.writeFileSync(base+'.md',md,{flag:'wx'});
console.log(JSON.stringify({accepted:true,tests:full.pass,logicalFiles:archive.logicalFiles,gzipFiles:archive.uniqueGzipFiles,gzipBytes:archive.gzipBytes}));
