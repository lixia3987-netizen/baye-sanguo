const fs=require('fs'),path=require('path'),crypto=require('crypto'),zlib=require('zlib'),assert=require('assert/strict');
const read=p=>fs.readFileSync(p),json=p=>JSON.parse(read(p).toString('utf8').replace(/^\uFEFF/,'')),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const dirs=process.argv.slice(2),runs=dirs.map(d=>({directory:d,result:json(d+'/result.json')}));
const accepted=runs.filter(v=>v.result.accepted),failed=runs.filter(v=>!v.result.accepted);
assert.equal(accepted.length,2);assert.deepEqual(accepted.map(v=>v.result.equipmentWidth).sort(),[667,844]);
for(const {result:r} of runs){assert.ok(r.cleanup.treeExited&&r.serverClosed);assert.deepEqual(r.sourceDrift,[]);}
for(const {result:r} of accepted){assert.ok(r.ok&&r.equipmentAccepted&&r.equipmentPreviewRegressionAccepted&&r.equipmentOnly);assert.equal(r.equipmentChecks.length,1);assert.equal(r.equipmentChecks[0].operations.length,4);assert.ok(r.equipmentChecks[0].accepted&&r.equipmentChecks[0].emptyInventory&&r.equipmentChecks[0].fullEquipment);assert.equal(r.nativeTouches.length,0);assert.deepEqual(r.exceptions,[]);
  for(const ref of r.sourceFiles){const b=read(ref.path);assert.equal(b.length,ref.bytes);assert.equal(sha(b),ref.sha256);}}
const suite='build/mobile-equipment-suite-v5-20261011.log',suiteText=read(suite).toString('utf8'),count=k=>Number([...suiteText.matchAll(new RegExp('(?:ℹ|#) '+k+' (\\d+)','g'))].at(-1)?.[1]);
assert.ok(count('tests')>=2553);assert.equal(count('pass'),count('tests'));for(const k of ['fail','cancelled','skipped','todo'])assert.equal(count(k),0);
const before=json('build/mobile-equipment-user-service-before-20261011.json'),after=json('build/mobile-equipment-user-service-after-20261011.json'),history=json('build/mobile-equipment-owned-historical-after-20261011.json');
assert.deepEqual(after.identities,before.identities);assert.equal(before.httpStatus,200);assert.equal(after.httpStatus,200);assert.ok(history.rows.every(v=>v.currentPidPresent===false));
const base='docs/validation/m5-mobile-equipment-20261011',rawDir=base+'/raw';assert.ok(!fs.existsSync(base+'.json'));fs.mkdirSync(rawDir,{recursive:true});
const files=new Set(),add=p=>{assert.ok(fs.existsSync(p),'Missing evidence '+p);files.add(p.replaceAll('\\','/'));};
for(const {directory:d}of runs){for(const name of ['result.json','executed-tool.mjs','source-verification.json','owned-process-samples.jsonl'])add(d+'/'+name);add(d.replace(/-20261011$/,'')+'-cli-20261011.log');
  for(const name of fs.readdirSync(d).filter(v=>v.endsWith('.png')&&(/equipment-.*(?:confiscated|rewarded|all-properties|map).*\.png$/.test(v)||/^failure.*\.png$/.test(v))))add(d+'/'+name);}
for(const name of fs.readdirSync('build').filter(v=>/^mobile-equipment-.*\.(?:json|log|txt|mjs|js)$/.test(v)))add('build/'+name);
for(const dir of fs.readdirSync('build').filter(v=>/^mobile-equipment-product-.*-source-20261011$/.test(v)))for(const name of fs.readdirSync('build/'+dir))add('build/'+dir+'/'+name);
for(const p of ['build/mobile-equipment-independent-audit-20261011.txt','build/archive-mobile-equipment-20261011.cjs','build/check-mobile-equipment-cleanup-20261011.ps1',
  'js/hd-city-menu.js','css/hd-mobile.css','m.html','pc.html','package.json','scripts/test-hd-city-mobile-host.mjs','scripts/test-hd-mobile-city-runtime.mjs',
  'scripts/hd-mobile-preview-runtime-checks.mjs','scripts/hd-mobile-equipment-runtime-checks.mjs','scripts/hd-mobile-equipment-runtime-oracle.mjs','scripts/test-hd-mobile-equipment-runtime-oracle.mjs','scripts/test-hd-mobile-detail-runtime-checks.mjs'])add(p);
const originals=[];let index=0;for(const file of files){const b=read(file),compressed=zlib.gzipSync(b,{level:9});assert.deepEqual(zlib.gunzipSync(compressed),b);const target=rawDir+'/'+String(++index).padStart(3,'0')+'-'+path.basename(file)+'.gz';fs.writeFileSync(target,compressed,{flag:'wx'});originals.push({original:file,bytes:b.length,sha256:sha(b),archive:target,archiveBytes:compressed.length,archiveSha256:sha(compressed),roundTripExact:true});}
const flows=accepted.map(({directory,result:r})=>{const f=r.equipmentChecks[0],p=r.previewChecks[0];return {directory,viewport:f.baseline.state.viewport,cityIndex:f.cityIndex,actors:f.actors,phases:r.phases.length,nativeKeys:r.nativeKeys.length,nativeLcdTouches:r.nativeTouches.length,sourceFiles:r.sourceFiles.length,previewChecks:p.checks.length,equipmentChecks:f.checks.length,trustedPans:f.scrollChecks.length+p.scrollChecks.length,
  operations:f.operations.map(v=>({kind:v.kind,personId:v.personId,toolId:v.toolId,oracle:v.oracle})),reports:f.reports.map(v=>({label:v.label,native:v.native,ackKeys:v.keys.map(k=>k.code)})),cancellations:f.cancellations.map(v=>({label:v.label,keys:v.keys.map(k=>k.code),nativeKind:v.after.state.menu.kind,seq:v.after.state.menu.seq})),emptyInventory:true,fullEquipmentRejected:true,returnedHud:f.returned.state.hud,expectedHud:f.returned.state.expected};});
const summary={schemaVersion:1,date:'2026-10-11',accepted:true,scope:'Original mobile equipment confiscation and granting through actual native controls in two independent fresh original games',fullHdAccepted:false,realDeviceAccepted:false,wholeNativeAbiAccepted:false,nativeBuildChanged:false,flows,
  tests:{modules:74,tests:count('tests'),pass:count('pass'),fail:0,cancelled:0,skipped:0,todo:0,log:suite},failedRuns:failed.map(v=>({directory:v.directory,accepted:false,error:v.result.error})),userService:{before,after,unchanged:true},ownedHistoricalRows:history.rows.length,ownedHistoricalPidAbsent:true,ownedHistoricalBirthExact:false,cleanupNote:'All recorded PIDs are absent. Historical birth timestamp normalization is inaccurate; no exact UTC tick comparison is claimed. Original proof retained with independent audit correction.',portableClosedArchive:false,
  limits:['Desktop Chrome landscape touch emulation, not real mobile hardware','Only recorded world fields, not the complete native ABI','Actual grants cover useflag0 weapon tools 0/1; not every tool class or error path','No new battle, succession, save-load, other-period or performance acceptance','Selected originals and byte-exact compressed receipts are not a standalone replay package'],
  archive:{originalCount:originals.length,originalBytes:originals.reduce((s,v)=>s+v.bytes,0),archiveBytes:originals.reduce((s,v)=>s+v.archiveBytes,0),originals}};
fs.writeFileSync(base+'.json',JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
const lines=['# 原版移动 HD 没收与赏赐','',
  '日期：2026-10-11。限定本机 Chrome 横屏触控模拟及实际词典原版。完整HD、真实设备与完整原生ABI继续待验。','',
  '修复赏赐的道具→人物交接、拒绝重试、取消、报告及下一份真实名单恢复；没收成功后恢复真实人物名单。空库存和命令结束按原版返回地图并关闭旧HD页，等待期间不自动确认或补按键。PC只有共享脚本缓存版本更新，本批没有重编译引擎。','',
  '| 视口 | 检查点 | 原生按键 | LCD触摸 | 四次真实装备操作 |','|---|---:|---:|---:|---|',
  ...flows.map(f=>`| ${f.viewport.join('×')} | ${f.phases} | ${f.nativeKeys} | ${f.nativeLcdTouches} | 全部通过 |`),'',
  '每尺寸使用独立新原版董卓局：空库存赏赐提示→地图；没收董卓七星刀；尝试赏赐给装备已满的吕布被原版拒绝且世界不变；取消并真正授予李儒；没收吕布方天画戟并赏回。包含内部道具／人物取消、报告单次确认，以及李儒和吕布更新后的13列属性实读。每局先复跑人物与道具只读浏览，全部操作通过可见、至少44像素的当前触控按钮。','',
  '真实原版报告时序分别核对：没收非君主在报告关闭后才扣忠诚、卸装和入库；赏赐在报告中装备和库存已变，报告关闭后再加忠诚。纯验算器逐字段核对200人物、38城已采字段、完整2000项道具队列及发现位、队列移动和33项实际LIB道具字段；其余已采字段保持一致。君主没收没有人物报告或忠诚损失。','',
  `最终74模块 ${count('pass')}/${count('tests')} 通过，失败／取消／跳过／todo均0。新增资料helper空值专项9/9通过，旧helper对同套测试8通过／1失败。旧源负例及修复前测试按历史范围留存，不计入最终接受。`,'',
  '首轮实际验证揭示上层返回路径遗漏：原版空库存提示关闭后直接返回地图，HD仍留在旧赏赐页。修复真实MAP退休，并纠正验证脚本此前假定返回SUB的错误。第二轮脚本错误地用城内库存核对人物装备；第三轮实际授予已通过，但脚本又错误地把PERSON诊断数据中的空字符串当成DOM占位文案。最终明确区分人物装备／城市库存、原生及PERSON诊断空字符串／DOM“（空）”，补专项后两尺寸完整复跑。失败记录、旧源及冻结差异均保留。一次并行全量的既有状态效果模块异常退出，未确定原因，独立22/22复验及最终完整回归通过。','',
  `自有私服和Chrome树退出，${history.rows.length} 条历史记录中的PID均已不存在；用户8080服务前后身份、启动时间相同，HTTP200。历史清理证明的birth时间转换有时区及精度问题，不据此声称原始UTC ticks精确相等；保留原件及独立审计纠正。`,'',
  `见[结构化证据](m5-mobile-equipment-20261011.json)。${originals.length}份原件以字节数和SHA-256归档，gzip解压逐字节一致；这是选择性证据，不是独立完整重放包。`,'',
  '原版唯一入口及暂时移除版本切换的范围保持。其它道具类别、无法使用拒绝、其它时期／城池、完整战果／继任／存读档、真机及性能仍待验，完整HD仍partial。',''];
fs.writeFileSync(base+'.md',lines.join('\n'),{flag:'wx'});console.log(JSON.stringify({base,tests:summary.tests,files:originals.length,bytes:summary.archive.originalBytes,gzip:summary.archive.archiveBytes,flows:flows.map(f=>({viewport:f.viewport,phases:f.phases,keys:f.nativeKeys,operations:f.operations.length}))}));
