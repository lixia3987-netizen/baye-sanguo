import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const ref=p=>{const b=fs.readFileSync(p);return {path:p,bytes:b.length,sha256:sha(b)};};
const write=(p,v)=>fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n',{flag:'wx'});
const previous=JSON.parse(fs.readFileSync('build/mobile-equipment-product-freeze-v1.json','utf8'));
const frozen=previous.frozen.map(old=>{
    const before=ref('build/mobile-equipment-product-freeze-v1-source-20261011/'+path.basename(old.path));
    assert.equal(before.bytes,old.bytes);assert.equal(before.sha256,old.sha256);
    return {before,after:ref(old.path)};
});
const edits=[];
for(const {before,after} of frozen){
    const a=fs.readFileSync(before.path),b=fs.readFileSync(after.path);if(a.equals(b))continue;
    let prefix=0,suffix=0;
    while(prefix<Math.min(a.length,b.length)&&a[prefix]===b[prefix])prefix++;
    while(suffix<Math.min(a.length,b.length)-prefix&&a[a.length-1-suffix]===b[b.length-1-suffix])suffix++;
    const removed=a.subarray(prefix,a.length-suffix),added=b.subarray(prefix,b.length-suffix);
    assert.ok(Buffer.concat([b.subarray(0,prefix),removed,b.subarray(b.length-suffix)]).equals(a));
    edits.push({path:after.path,before,after,prefixBytes:prefix,suffixBytes:suffix,
        removedBase64:removed.toString('base64'),addedBase64:added.toString('base64'),inverseByteExact:true});
}
assert.deepEqual(edits.map(e=>e.path),['js/hd-city-menu.js','m.html','pc.html','scripts/test-hd-city-mobile-host.mjs']);
const focused='build/mobile-equipment-focused-v5-20261011.log',negative='build/mobile-equipment-map-old-source-negative-v1-20261011.log';
for(const [p,total,pass,fail] of [[focused,502,502,0],[negative,53,47,6]]){
    const value=fs.readFileSync(p,'utf8');
    for(const [key,count] of [['tests',total],['pass',pass],['fail',fail],['skipped',0]])assert.match(value,new RegExp(key+' '+count+'(?:\\r?\\n|$)'));
}
for(const p of ['m.html','pc.html'])assert.equal((fs.readFileSync(p,'utf8').match(/js\/hd-city-menu\.js\?ver=20261011n/g)||[]).length,1);
write('build/mobile-equipment-product-delta-v2.json',{schema:'baye.mobile-equipment.product-delta.v2',edits});
const failed=JSON.parse(fs.readFileSync('build/mobile-equipment-844-v1-20261011/result.json','utf8'));
assert.equal(failed.ok,false);assert.equal(failed.accepted,false);
const state=failed.phases.at(-1).state;
assert.equal(state.menu.active,0);assert.equal(state.menu.context,0);assert.equal(state.menu.kind,0);
assert.equal(state.menu.seq,28);assert.equal(state.march.pick,1);assert.equal(state.march.mapInputSeq,4);
assert.equal(state.report.active,0);assert.equal(state.cityUi.open,true);assert.equal(state.cityUi.deepKind,'goods-person');
const proof={schema:'baye.mobile-equipment.product-freeze.v2',createdAt:new Date().toISOString(),
    scope:'Narrow original mobile equipment command return-to-MAP retirement. Previous actual failure and all frozen v1 bytes retained.',
    frozen:frozen.map(f=>f.after),preservedV1:frozen.map(f=>f.before),previousFreeze:ref('build/mobile-equipment-product-freeze-v1.json'),
    delta:ref('build/mobile-equipment-product-delta-v2.json'),modifiedPaths:edits.map(e=>e.path),unchanged:['css/hd-mobile.css'],
    observedFailure:{result:ref('build/mobile-equipment-844-v1-20261011/result.json'),accepted:false,
        native:{menuActive:0,menuContext:0,menuKind:0,menuSeq:28,mapPick:1,mapInputSeq:4,reportActive:0},
        retainedUi:{open:true,deepKind:'goods-person'},
        correction:'The v1 controlled fixture incorrectly expected a new SUB. Actual native command completion returns through PlayerTactic to GetCitySet.'},
    behavior:{sourceDataAndOriginalLibGenerationFence:true,fullRawAndNativeMapDoubleRead:true,
        mapPick1BattlePick0:true,phase0Or7Only:true,sameCityAndMarchOwner:true,
        nextNonzeroMapInputSequence:true,menuInactiveContext0Kind0:true,nextNonzeroLastPickerMenuSequence:true,
        allCompetingOwnersInactive:true,queuedOrSendingInputRefusesRetirement:true,
        emptyAndLastInventoryReturnsMap:true,finalRewardGoodsAndConfiscatePersonExitReturnsMap:true,
        internalRewardPersonCancelAndConfiscateGoodsCancelRemainFreshPicker:true,
        hostRetirementDoesNotKeepOldEquipmentPaneOnTrueMap:true,silentUiRetirementOnly:true,noExtraExitOrEnter:true,
        noNativeWrites:true,pcBehaviorUnchanged:true,unexpectedSubNotAssumed:true},
    checks:{nodeSyntax:true,focused:{tests:502,pass:502,fail:0,skip:0,log:ref(focused)},
        addedCases:21,correctedPriorCases:3,
        frozenV1Negative:{tests:53,pass:47,fail:6,skip:0,expectedExit:1,
            harness:ref('build/mobile-equipment-map-old-source-negative-test-v1.mjs'),log:ref(negative),
            interpretation:'Six true-MAP retirement positives fail on unchanged v1; forty-seven other equipment checks pass. No claim of a full old-source regression.'},
        intermediate:ref('build/mobile-equipment-focused-v4-20261011.log'),
        intermediateCorrection:'Null-parent historical preview flows needed a nonnull lastSeq guard; one new qty rejection fixture also lacked the existing LCD bayeQtyNativeClosed global. Original failing log is retained.',
        inverseAllModifiedFilesByteExact:true},
    cache:{cityScript:'20261011n',mobileCssUnchanged:'20261011j'},
    nativeSources:[{...ref('vendor/iBaye/src/tactic.c'),lines:'69-113',rule:'PlayerTactic calls CityCommon once then returns to GetCitySet, not InteriorOrderMenu.'},
        {...ref('vendor/iBaye/src/citycmdb.c'),lines:'1093-1203',rule:'Empty inventory and final GOODS EXIT return from LargessMake; PERSON EXIT remains an internal GOODS loop.'},
        {...ref('vendor/iBaye/src/citycmde.c'),lines:'40-140',rule:'Final PERSON EXIT returns from ConfiscateMake; GOODS EXIT remains the internal PERSON loop.'}],
    limits:['Controlled VM only; new source has no real browser acceptance yet.',
        'Frozen v1 actual exit1 remains rejected even though its earlier static suite passed.',
        'No layout/input protocol change or automatic acknowledgment is introduced.'],
    noBrowser:true,noService:true,noOsLifecycle:true,noGitMutation:true};
write('build/mobile-equipment-product-freeze-v2.json',proof);
console.log(JSON.stringify({freeze:ref('build/mobile-equipment-product-freeze-v2.json'),delta:proof.delta,frozen:proof.frozen,focused:proof.checks.focused},null,2));
