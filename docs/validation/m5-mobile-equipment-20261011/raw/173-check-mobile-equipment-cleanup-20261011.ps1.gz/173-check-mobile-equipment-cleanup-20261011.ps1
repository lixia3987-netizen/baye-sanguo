$ErrorActionPreference = 'Stop'
$equipmentRuns = @('build/mobile-equipment-844-v1-20261011', 'build/mobile-equipment-844-v2-20261011', 'build/mobile-equipment-667-v2-20261011', 'build/mobile-equipment-844-v3-20261011', 'build/mobile-equipment-667-v3-20261011', 'build/mobile-equipment-844-v4-20261011', 'build/mobile-equipment-667-v4-20261011')
$equipmentIdentities = @{}
foreach ($equipmentDir in $equipmentRuns) {
    $equipmentResult = Get-Content -LiteralPath "$equipmentDir/result.json" -Encoding UTF8 -Raw | ConvertFrom-Json
    if (-not $equipmentResult.cleanup.treeExited -or -not $equipmentResult.serverClosed) { throw 'A runtime cleanup is not terminal' }
    foreach ($equipmentRecorded in $equipmentResult.historicalRecordedIdentities) {
        $equipmentKey = "$($equipmentRecorded.ProcessId)|$($equipmentRecorded.CreationDate)|$($equipmentRecorded.ExecutablePath)"
        $equipmentIdentities[$equipmentKey] = $equipmentRecorded
    }
}
$equipmentLive = @(Get-CimInstance Win32_Process)
$equipmentRows = @($equipmentIdentities.Values | ForEach-Object {
    $equipmentRecorded = $_
    $equipmentCurrent = @($equipmentLive | Where-Object { $_.ProcessId -eq $equipmentRecorded.ProcessId })
    $equipmentBirth = [datetime]::Parse($equipmentRecorded.CreationDate).ToUniversalTime()
    $equipmentExact = @($equipmentCurrent | Where-Object { $_.CreationDate.ToUniversalTime().Ticks -eq $equipmentBirth.Ticks -and $_.ExecutablePath -eq $equipmentRecorded.ExecutablePath })
    [ordered]@{ProcessId=$equipmentRecorded.ProcessId;CreationDateUtc=$equipmentBirth.ToString('o');ExecutablePath=$equipmentRecorded.ExecutablePath;currentPidPresent=($equipmentCurrent.Count -gt 0);exactIdentityPresent=($equipmentExact.Count -gt 0)}
})
if ($equipmentRows.Count -eq 0) { throw 'Missing historical process identities' }
[ordered]@{checkedAt=(Get-Date).ToUniversalTime().ToString('o');runtimes=$equipmentRuns;comparison='PID, executable path and exact UTC DateTime ticks';rows=$equipmentRows} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath 'build/mobile-equipment-owned-historical-after-20261011.json' -Encoding utf8
if (@($equipmentRows | Where-Object { $_.exactIdentityPresent }).Count -ne 0) { throw 'An exact recorded owned browser identity still exists' }
$equipmentServicePids = @(Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
$equipmentServiceIdentities = @($equipmentServicePids | ForEach-Object { Get-CimInstance Win32_Process -Filter "ProcessId = $_" | Select-Object ProcessId, ExecutablePath, @{Name='CreationDateUtc';Expression={$_.CreationDate.ToUniversalTime().ToString('o')}} })
$equipmentServiceHttp = (Invoke-WebRequest -Uri 'http://localhost:8080/' -UseBasicParsing).StatusCode
[ordered]@{checkedAt=(Get-Date).ToUniversalTime().ToString('o');listenPort=8080;identities=$equipmentServiceIdentities;httpStatus=$equipmentServiceHttp} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath 'build/mobile-equipment-user-service-after-20261011.json' -Encoding utf8
Write-Output "Historical owned identities checked: $($equipmentRows.Count); exact survivors: 0; user service HTTP: $equipmentServiceHttp"
