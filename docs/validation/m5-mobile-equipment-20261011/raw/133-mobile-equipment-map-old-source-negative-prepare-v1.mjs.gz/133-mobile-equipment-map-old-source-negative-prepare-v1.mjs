import fs from 'node:fs';
import assert from 'node:assert/strict';
const source=fs.readFileSync('scripts/test-hd-city-mobile-host.mjs','utf8');
const old="new URL('../js/hd-city-menu.js', import.meta.url)";
assert.equal(source.split(old).length,2);
fs.writeFileSync('build/mobile-equipment-map-old-source-negative-test-v1.mjs',source.replace(old,
    "new URL('./mobile-equipment-product-freeze-v1-source-20261011/hd-city-menu.js', import.meta.url)"),{flag:'wx'});
