import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const ref=p=>{const b=fs.readFileSync(p);return {path:p,bytes:b.length,sha256:sha(b)};};
const write=(p,v)=>fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n',{flag:'wx'});
const paths=['js/hd-city-menu.js','css/hd-mobile.css','m.html','pc.html','scripts/test-hd-city-mobile-host.mjs'];
const baselineDir='build/mobile-equipment-product-v1-source-20261011';
const previous=JSON.parse(fs.readFileSync('build/mobile-preview-product-freeze-v2.json','utf8'));
const frozen=paths.map(p=>{
    const before=ref(baselineDir+'/'+path.basename(p)),old=previous.frozen.find(r=>r.path===p);
    assert.ok(old);assert.equal(before.bytes,old.bytes);assert.equal(before.sha256,old.sha256);
    return {before,after:ref(p)};
});
const edits=[];
for(const {before,after} of frozen){
    const a=fs.readFileSync(before.path),b=fs.readFileSync(after.path);if(a.equals(b))continue;
    let prefix=0,suffix=0;
    while(prefix<Math.min(a.length,b.length)&&a[prefix]===b[prefix])prefix++;
    while(suffix<Math.min(a.length,b.length)-prefix&&a[a.length-1-suffix]===b[b.length-1-suffix])suffix++;
    const removed=a.subarray(prefix,a.length-suffix),added=b.subarray(prefix,b.length-suffix);
    assert.ok(Buffer.concat([b.subarray(0,prefix),removed,b.subarray(b.length-suffix)]).equals(a));
    edits.push({path:after.path,before,after,prefixBytes:prefix,suffixBytes:suffix,
        removedBase64:removed.toString('base64'),addedBase64:added.toString('base64'),inverseByteExact:true});
}
assert.deepEqual(edits.map(e=>e.path),['js/hd-city-menu.js','m.html','pc.html','scripts/test-hd-city-mobile-host.mjs']);
const focused='build/mobile-equipment-focused-v3-20261011.log',negative='build/mobile-equipment-old-source-negative-v1-20261011.log';
for(const [p,total,pass,fail] of [[focused,481,481,0],[negative,32,20,12]]){
    const value=fs.readFileSync(p,'utf8');
    for(const [key,count] of [['tests',total],['pass',pass],['fail',fail],['skipped',0]])assert.match(value,new RegExp(key+' '+count+'(?:\\r?\\n|$)'));
}
for(const p of ['m.html','pc.html'])assert.equal((fs.readFileSync(p,'utf8').match(/js\/hd-city-menu\.js\?ver=20261011m/g)||[]).length,1);
write('build/mobile-equipment-product-delta-v1.json',{schema:'baye.mobile-equipment.product-delta.v1',edits});
const proof={schema:'baye.mobile-equipment.product-freeze.v1',createdAt:new Date().toISOString(),
    baselineRevision:'9daf0e8',scope:'Mobile original CITY LargessMake and ConfiscateMake picker/report/return handoffs only. Controlled VM evidence; actual C/browser validation is pending root.',
    frozen:frozen.map(f=>f.after),preservedBaseline:frozen.map(f=>f.before),
    previousPreviewFreeze:ref('build/mobile-preview-product-freeze-v2.json'),
    delta:ref('build/mobile-equipment-product-delta-v1.json'),modifiedPaths:edits.map(e=>e.path),unchanged:['css/hd-mobile.css'],
    behavior:{originalStandardLibAndDataGenerationFence:true,completeNativeIdsNamesBeforePublish:true,
        rewardGoodsPersonAndInventoryLoop:true,rewardRejectionReturnsActualPersonIndex:true,
        changedRewardInventoryAcceptedOnlyAfterActualSourceEnter:true,confiscationRetainsActualPersonIndexAndFullList:true,
        kind1AndActualActorKind2ReportsWaitForPlayer:true,noSyntheticReportAck:true,
        sourceEnterOrExitOnce:true,nativeU32NonzeroNextNext:true,
        pendingBlocksPreviewMainBackAndPropertyInputs:true,retirementAbortsObservation:true,
        noNativeWrites:true,noAutomaticKeys:true,noSpeculativeNativeIndex:true,pcRewardRoutePreserved:true,
        reportAndIncompletePublicationUseNativeLcdOrExistingDialog:true},
    checks:{nodeSyntax:true,focused:{tests:481,pass:481,fail:0,skip:0,log:ref(focused)},newEquipmentCases:32,
        oldSourceNegative:{tests:32,pass:20,fail:12,skip:0,expectedExit:1,
            source:ref(baselineDir+'/hd-city-menu.js'),harness:ref('build/mobile-equipment-old-source-negative-test-v1.mjs'),log:ref(negative),
            interpretation:'Twelve new positive/current-flow requirements fail on the unchanged old source; twenty fail-closed/PC checks already pass. Not twelve independent unsafe-input defects, not a full old regression.'},
        inverseAllModifiedFilesByteExact:true,
        preservedIntermediate:{focusedV1:{tests:449,pass:444,fail:5,log:ref('build/mobile-equipment-focused-v1-20261011.log'),
            reason:'Five source-extraction tests omitted the newly shared pure personDeepKind helper in their VM context; only that fixture boundary was corrected.'},
            focusedV2:{tests:471,pass:471,fail:0,log:ref('build/mobile-equipment-focused-v2-20261011.log')}}},
    cache:{cityScript:'20261011m',mobileCssUnchanged:'20261011j'},
    nativeSourceRefs:[{...ref('vendor/iBaye/src/citycmdb.c'),lines:'1093-1203',rule:'Largess actual GOODS/PERSON loops, report/rejection/empty-inventory branches and current inventory.'},
        {...ref('vendor/iBaye/src/citycmde.c'),lines:'40-140',rule:'Confiscate actual PERSON pcode, GOODS cancellation/commit, king report omission.'},
        {...ref('vendor/iBaye/src/hd-bridge.c'),lines:'1308-1314,1431-1460',rule:'Nonzero U32 input sequence and separate menu begin/ID publication.'}],
    limits:['No native C, real browser or touch/layout acceptance in this controlled proof.',
        'Details renderers are isolated in the handoff VM fixture; actual PERSON/GOODS detail rendering awaits root runtime.',
        'Existing generic report UI owns actual report acknowledgment; this code only observes the current report and subsequent menu.',
        'An unexpected owner, incomplete publication timeout or lifecycle retirement does not fabricate a picker or send a retry key.',
        'Only original mobile equipment handoffs are added; PC behavior and other command flows remain unchanged.'],
    noBrowser:true,noService:true,noOsLifecycle:true,noGitMutation:true};
write('build/mobile-equipment-product-freeze-v1.json',proof);
console.log(JSON.stringify({freeze:ref('build/mobile-equipment-product-freeze-v1.json'),delta:proof.delta,frozen:proof.frozen,focused:proof.checks.focused},null,2));
