#!/usr/bin/env node
/** Read-only city/person/tool HUD rendered from real native menu contracts. */
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import vm from 'node:vm';

const read = path => readFileSync(new URL('../' + path, import.meta.url), 'utf8');
const standardHash = '3bd20146084054163d045c90987c756a6a210664e78253cc56bc4a274727903e';
const plain = value => JSON.parse(JSON.stringify(value));
function element(tagName = 'div') {
    const attrs = new Map(), classes = new Set(), listeners = new Map();
    let ownText = '';
    const item = { tagName: tagName.toUpperCase(), attrs, listeners, children: [], style: {}, hidden: false,
        parentElement: null, parentNode: null, scrollCalls: 0,
        setAttribute(key, value) { attrs.set(key, String(value)); },
        getAttribute(key) { return attrs.get(key) ?? null; },
        appendChild(child) {
            if (child.parentElement) child.parentElement.removeChild(child);
            this.children.push(child); child.parentElement = child.parentNode = this; return child;
        },
        removeChild(child) { this.children.splice(this.children.indexOf(child), 1); child.parentElement = child.parentNode = null; },
        insertBefore(child, other) {
            if (child.parentElement) child.parentElement.removeChild(child);
            this.children.splice(this.children.indexOf(other), 0, child); child.parentElement = child.parentNode = this;
        },
        scrollIntoView() { this.scrollCalls++; },
        addEventListener(type, listener) { if (!listeners.has(type)) listeners.set(type, []); listeners.get(type).push(listener); },
        querySelector(selector) { return this.querySelectorAll(selector)[0] ?? null; },
        querySelectorAll(selector) { return walk(this).filter(node => matches(node, selector)); },
        classList: { add(...names) { names.forEach(name => classes.add(name)); },
            remove(...names) { names.forEach(name => classes.delete(name)); },
            contains(name) { return classes.has(name); },
            toggle(name, on) { on ??= !classes.has(name); on ? classes.add(name) : classes.delete(name); } }
    };
    Object.defineProperties(item, {
        className: { get: () => [...classes].join(' '), set(value) { classes.clear(); value.split(/\s+/).filter(Boolean).forEach(v => classes.add(v)); } },
        textContent: { get: () => ownText + item.children.map(child => child.textContent).join(''),
            set(value) { ownText = String(value); item.children.forEach(child => { child.parentElement = child.parentNode = null; }); item.children = []; } },
        innerHTML: { get: () => '', set(value) {
            assert.equal(value, '', 'HUD fixture does not silently parse untested HTML'); item.textContent = '';
        } }
    });
    return item;
}
function walk(node) { return node.children.flatMap(child => [child, ...walk(child)]); }
function matches(node, selector) {
    if (selector.startsWith('[')) return node.attrs.has(selector.slice(1, -1).split('=')[0]);
    if (selector.startsWith('.')) return node.classList.contains(selector.slice(1));
    if (selector.startsWith('#')) return node.id === selector.slice(1);
    return node.tagName.toLowerCase() === selector.toLowerCase();
}

function harness() {
    const html = element('html'), body = element('body'); html.appendChild(body);
    const root = element(); root.id = 'hd-city-menu'; body.appendChild(root);
    const stage = element(); stage.className = 'hd-city-menu-stage'; root.appendChild(stage);
    const nodes = {};
    for (const id of ['hd-city-menu-title', 'hd-city-menu-sub', 'hd-city-menu-root',
        'hd-city-menu-sublist', 'hd-city-menu-status', 'hd-city-menu-deep']) {
        const node = element(); node.id = id; nodes[id] = node; stage.appendChild(node);
    }
    const lcdButton = element('button'); lcdButton.setAttribute('data-hd-menu-lcd', ''); stage.appendChild(lcdButton);
    const document = { documentElement: html, body, hidden: false,
        getElementById: id => [html, ...walk(html)].find(node => node.id === id) ?? null,
        querySelectorAll: selector => walk(html).filter(node => matches(node, selector)),
        querySelector(selector) { return this.querySelectorAll(selector)[0] ?? null; },
        createElement: element, addEventListener() {} };
    const keys = [], writes = [], timers = [], intervals = [], names = new Map([[0, '君主甲'], [254, '主人二五四'], [599, '主人五九九'],
        [600, '很长的人物姓名甲乙丙丁戊己庚辛壬癸测试'], [601, '人物乙']]);
    const context = vm.createContext({ document, TextDecoder, TextEncoder,
        console: { log() {}, warn() {}, error() {} }, alert() {}, lcdBlur() {},
        Module: { HEAPU8: new Uint8Array(8192) }, addEventListener() {},
        setTimeout(fn) { timers.push(fn); return timers.length; }, clearTimeout() {}, setInterval(fn) { intervals.push(fn); }, clearInterval() {},
        localStorage: { getItem: key => key === 'baye/cityMenuMode' ? 'hd' : 'hd-map' },
        navigator: { userAgent: 'Node fixture' } });
    context.window = context;
    const bridge = read('js/bridge.js');
    for (const name of new Set(bridge.match(/\b_baye\w+/g))) context[name] = () => 0;
    context._bayeHdReady = () => 1; context._bayeGetPersonCount = () => 786;
    context._bayeSendKey = key => keys.push(key);
    vm.runInContext(bridge, context); context.baye_bridge_init();
    const city = { State: 0, Belong: 255, SatrapId: 600, FarmingLimit: 900, Farming: 300,
        CommerceLimit: 700, Commerce: 0, PeopleDevotion: 78, AvoidCalamity: 62,
        PopulationLimit: 500000, Population: 400000, Money: 532, Food: 1790,
        MothballArms: 975, Persons: 2, Tools: 3, PersonQueue: 7, ToolQueue: 11 };
    const person = { OldBelong: 0, Belong: 255, Level: 7, Force: 91, IQ: 88, Devotion: 67,
        Character: 4, Experience: 99, Thew: 0, ArmsType: 2, Arms: 1234,
        Equip: [0, 600], Tool1: 0, Tool2: 600, Age: 34 };
    const people = []; people.length = 786; people[600] = person;
    people[601] = { ...person, Equip: [1, 0], Belong: 255 };
    const queue = Array(7).fill(0).concat([600, 601]);
    const raw = { g_Cities: [city], g_Persons: people, g_PersonsQueue: queue,
        g_PlayerKing: 254, g_PIdx: 1, g_hdQtyActive: 0, g_asyncActionID: 0 };
    function readonly(value, path = '') {
        if (!value || typeof value !== 'object') return value;
        return new Proxy(value, { get(target, key) { return readonly(target[key], path + '.' + String(key)); },
            set(target, key) { writes.push(path + '.' + String(key)); throw new Error('engine write'); } });
    }
    context.baye.data = readonly(raw); context.baye.ensureData = () => context.baye.data;
    context.baye.getPersonName = index => names.get(index) ?? '';
    context.baye.getCityName = () => '长安'; context.baye.hdCityLimit = () => 1;
    const toolCalls = [];
    context.baye.getToolCount = () => 512;
    context.baye.getToolName = index => { toolCalls.push(index); return index === 0 ? '很长的装备名称甲乙丙丁' : ''; };
    const armCalls = [];
    context.baye.getArmType = index => { armCalls.push(index); throw new Error('U8 derived getter must not be used'); };
    const derivedCalls = [];
    const menu = { active: 1, context: 1, kind: 3, seq: 9, count: 2, index: 0,
        names: [names.get(600), names.get(601)] };
    const report = { active: 0 }, help = { active: 0 }, qty = { active: 0 };
    const goods = { active: 0 };
    Object.assign(context.baye.hd, { ready: () => true, menuItems: () => menu, report: () => report,
        help: () => help, qty: () => qty, march: () => null, fight: () => null, goods: () => goods,
        toolDetails: () => null, personArmType: id => { derivedCalls.push(id); return null; } });
    let identity = { status: 'ready', generation: 1, sha256: standardHash }, current = true;
    context.BayeHdLibIdentity = { read: () => identity, isCurrent: value => current && value === identity };
    let source = read('js/hd-city-menu.js');
    source = source.replace(/\}\)\(window\);\s*$/, `
        global.__hud = { state: state, cityDetails: cityDetails, personDetails: personDetails,
            renderStatus: renderStatus, renderPersonDetails: renderPersonDetails,
            renderToolDetails: renderToolDetails,
            deepMenuOwner: deepMenuOwner, fillDeepList: fillDeepList, applyHighlight: applyHighlight,
            chooseRoot: chooseRoot, chooseSub: chooseSub, back: back, bind: bindUi,
            applyDocAttr: applyDocAttr, lcdPresentation: cityLcdPresentation, render: render };
    })(window);`);
    vm.runInContext(source, context, { filename: 'js/hd-city-menu.js' });
    const hud = context.__hud;
    Object.assign(hud.state, { open: true, cityIndex: 0, cityName: '长安', layer: 'deep',
        deepKind: 'person', wizardStep: 'none', idleIndex: 0 });
    hud.state.deepMenuOwner = hud.deepMenuOwner(menu);
    return { context, hud, nodes, root, lcdButton, document, city, person, people, queue, menu, names, report, help, qty, goods,
        raw, keys, writes, timers, intervals, armCalls, derivedCalls, toolCalls, setIdentity(value, isCurrent = true) { identity = value; current = isCurrent; } };
}

function goodsHarness({custom = true} = {}) {
    const h = harness();
    Object.assign(h.hud.state, { deepKind: 'goods', deepStep: 0 });
    Object.assign(h.menu, { kind: 4, generation: 3, detailGeneration: 3, idsValid: true, ids: [2, 17],
        names: ['同名道具', '同名道具'], count: 2, index: 0 });
    Object.assign(h.goods, { active: 1, complete: 0, custom: custom ? 1 : 0, generation: 3, detailGeneration: 3,
        menuSeq: h.menu.seq, index: 0, tool: 2, name: '很长的真实道具名称甲乙丙丁戊己',
        propertyCount: 5, pageStart: 0, pageEnd: 3, properties: Array.from({length: 5}, (_, i) => ({
            index: i, title: i < 3 ? '实际属性' + i : '', value: i < 3 ? String(i) : '', captured: i < 3 })) });
    h.hud.fillDeepList(); h.hud.bind();
    return h;
}
function dispatch(h, type, target, options = {}) {
    h.root.listeners.get(type).forEach(listener => listener({target, preventDefault() {}, stopPropagation() {}, ...options}));
}
function pageButton(h, direction) {
    return h.document.querySelectorAll('[data-hd-tool-page]').find(button => button.getAttribute('data-hd-tool-page') === direction);
}

function rows(details) { return Object.fromEntries(details.groups.flatMap(group => group.rows)); }
function backHarness({retired = false} = {}) {
    const h = harness();
    Object.assign(h.raw, {g_hdDetailGeneration: 3, g_hdMapInputSeq: 2, g_hdMapCity: 0,
        g_hdMenuSeq: 9, g_hdMenuActive: retired ? 0 : 1, g_hdQtyActive: 0,
        g_hdReportActive: 0, g_hdHelpActive: 0, g_hdFightActive: 0,
        g_hdMapPick: retired ? 1 : 0, g_hdBattlePick: 0, g_hdMarchPhase: 0});
    Object.assign(h.menu, {active: retired ? 0 : 1, detailGeneration: 3,
        idsValid: true, ids: [600, 601]});
    h.backButton = element('button'); h.backButton.setAttribute('data-hd-menu-back', '');
    h.root.appendChild(h.backButton); h.hud.bind();
    return h;
}
function runBackQueue(h) {
    for (let i = 0; h.timers.length && i < 30; i++) h.timers.shift()();
    assert.equal(h.timers.length, 0, 'Back must not leave a repeating input task');
}


// BEGIN R17 SEARCH INCREMENT: insert after existing backHarness/runBackQueue helpers.
// This drives the real production chooseSub/start poll/DOM input chain, not a copied controller.
const searchSubNames = ['开垦', '招商', '搜寻', '治理', '出巡', '招降', '处斩', '流放', '赏赐', '没收', '交易', '宴请', '输送', '移动'];
function searchHarness({ delayed = false } = {}) {
    const h = backHarness();
    h.context.baye.hd.march = () => ({phase: 0, session: 0, mapCity: 1, pick: h.raw.g_hdMapPick, mapInputSeq: h.raw.g_hdMapInputSeq});
    Object.assign(h.hud.state, { layer: 'sub', subKind: 'neizheng', deepKind: '', deepLabel: '', deepMenuOwner: null, idleIndex: 2 });
    Object.assign(h.menu, { active: 1, context: 1, kind: 2, seq: 30, generation: 3, detailGeneration: 3,
        count: searchSubNames.length, index: 2, names: [...searchSubNames], idsValid: false, ids: [] });
    Object.assign(h.raw, { g_hdMenuSeq: 30, g_hdMenuActive: 1 });
    h.context.sendKey = key => h.keys.push(key);
    h.hud.chooseSub(2);
    assert.equal(h.hud.state.deepKind, 'person', 'SEARCH must enter the production person route');
    assert.equal(h.hud.state.deepLabel, '搜寻'); assert.equal(h.hud.state.wizardStep, 'none');
    assert.deepEqual(h.keys, [0x27], 'The player command issues only the existing native Enter');
    h.keys.length = 0; h.timers.length = 0;
    h.context.BayeHdCityMenu.start(); h.poll = h.intervals.at(-1);
    h.publishPeople = ({ seq = 31, ids = [600, 601], names = ids.map(id => h.names.get(id)), index = 0 } = {}) => {
        Object.assign(h.menu, { active: 1, context: 1, kind: 3, seq, generation: 3, detailGeneration: 3,
            count: ids.length, index, names, idsValid: true, ids: [...ids] });
        Object.assign(h.raw, {g_hdMenuSeq: seq, g_hdMenuActive: 1});
    };
    if (!delayed) { h.publishPeople(); h.poll(); }
    return h;
}
function searchRow(h, index = 0) { return h.document.querySelectorAll('[data-hd-deep]')[index]; }
function armSearch(h, index = 0) {
    const target = searchRow(h, index); assert.ok(target, 'An actual native row must exist before arming');
    dispatch(h, 'pointerdown', target); return target;
}

test('SEARCH real poll waits for a delayed native person menu, then reads the full owned U16 IDs without another input', () => {
    const h = searchHarness({delayed: true});
    for (let i = 0; i < 4; i++) h.poll();
    assert.equal(h.hud.state.deepItems.length, 0); assert.equal(h.hud.state.personDetail, null);
    assert.equal(h.document.querySelectorAll('[data-hd-deep]').length, 0);
    assert.deepEqual(h.keys, []);
    h.people[700] = {...h.person, Belong: 0}; h.people[701] = {...h.person, Belong: 65535};
    h.people[777] = {...h.person, Force: 77}; h.names.set(777, '真实高ID人物');
    h.queue.splice(7, 2, 600, 700, 701, 777); h.city.Persons = 4;
    h.publishPeople({ids: [600, 777]}); h.poll();
    assert.deepEqual(Array.from(h.hud.state.deepItems, row => row.pind), [600, 777]);
    assert.equal(h.hud.state.personDetail.personIndex, 600);
    assert.equal(searchRow(h, 1).getAttribute('data-hd-deep-pind'), '777');
    assert.ok(h.hud.state.deepItems.every(row => ![700, 701].includes(row.pind)));
    assert.deepEqual(h.keys, []); assert.deepEqual(h.writes, []);
});

test('SEARCH exact native IDs survive reordered duplicate names and use current native index for the person fields', () => {
    const h = searchHarness(); h.people[601].Force = 33;
    h.publishPeople({ids: [601, 600], names: ['同名人物', '同名人物'], index: 1}); h.poll();
    assert.deepEqual(Array.from(h.hud.state.deepItems, row => [row.i, row.pind]), [[0, 601], [1, 600]]);
    assert.equal(h.hud.state.personDetail.personIndex, 600); assert.equal(rows(h.hud.state.personDetail).武力, '91');
    h.menu.index = 0; h.poll();
    assert.equal(h.hud.state.personDetail.personIndex, 601); assert.equal(rows(h.hud.state.personDetail).武力, '33');
    assert.deepEqual(h.keys, []); assert.deepEqual(h.writes, []);
});

test('SEARCH malformed claimed full-ID lists never attach a person by matching names', () => {
    for (const ids of [[600], [600, 65535], [600, '601'], [600, true]]) {
        const h = searchHarness(); h.menu.ids = ids; h.poll();
        assert.equal(h.hud.state.personDetail, null);
        assert.ok(h.hud.state.deepItems.every(row => row.pind === undefined));
        assert.deepEqual(h.keys, []); assert.deepEqual(h.writes, []);
    }
});

test('SEARCH old held rows cannot confirm after a new native sequence, detail generation or same-name ID reorder', () => {
    for (const change of [h => { h.menu.seq++; h.raw.g_hdMenuSeq++; },
        h => { h.menu.detailGeneration++; h.raw.g_hdDetailGeneration++; },
        h => { h.menu.ids.reverse(); h.menu.names.reverse(); }, h => { h.menu.context = 2; }]) {
        const h = searchHarness(), target = armSearch(h);
        change(h); dispatch(h, 'click', target, {detail: 1});
        assert.deepEqual(h.keys, []); assert.deepEqual(h.writes, []);
    }
});

test('SEARCH genuine inactive picker on native report takeover cannot confirm its old row', () => {
    const h = searchHarness(), target = armSearch(h);
    h.menu.active = 0; h.raw.g_hdMenuActive = 0; h.report.active = 1; h.raw.g_hdReportActive = 1;
    h.poll(); dispatch(h, 'click', target, {detail: 1});
    assert.equal(h.hud.state.personDetail, null); assert.deepEqual(h.keys, []); assert.deepEqual(h.writes, []);
});

for (const field of ['report', 'help']) {
    test('SEARCH active underlying picker retained by ' + field + ' cannot receive an old pressed Enter', () => {
        const h = searchHarness(), target = armSearch(h);
        h[field].active = 1; h.raw[field === 'report' ? 'g_hdReportActive' : 'g_hdHelpActive'] = 1;
        h.poll(); assert.equal(h.hud.state.personDetail, null);
        dispatch(h, 'click', target, {detail: 1});
        assert.deepEqual(h.keys, [], field + ' owns input even if the old native menu remains active');
        assert.deepEqual(h.writes, []);
    });
}

test('SEARCH a delayed native Down ACK followed by report takeover must never send pending Enter', () => {
    const h = searchHarness(), target = armSearch(h, 1);
    dispatch(h, 'click', target, {detail: 1});
    assert.deepEqual(h.keys, [0x23], 'Only one native Down, waiting for the actual highlighted index ACK');
    assert.ok(h.hud.state.nativeMenuRequest); assert.equal(h.hud.state.personDetail, null);
    h.menu.index = 1; h.report.active = 1; h.raw.g_hdReportActive = 1;
    runBackQueue(h);
    assert.deepEqual(h.keys, [0x23], 'No Enter may be sent to the report after its takeover');
    assert.deepEqual(h.writes, []);
});

test('SEARCH a normal current row selection follows the actual native Down ACK and sends exactly one Enter', () => {
    const h = searchHarness(), target = armSearch(h, 1);
    dispatch(h, 'click', target, {detail: 1});
    assert.deepEqual(h.keys, [0x23]); assert.ok(h.hud.state.nativeMenuRequest);
    h.menu.index = 1; runBackQueue(h);
    assert.deepEqual(h.keys, [0x23, 0x27]); assert.equal(h.hud.state.nativeMenuRequest, null);
    assert.ok(h.hud.state.deepSelectionPending, 'Retain the existing pending selection until native menu transition');
    assert.equal(h.hud.state.personDetail, null); assert.deepEqual(h.writes, []);
});

test('SEARCH Back delivers exactly one Exit, waits for native map ACK/queue drain and does not alter the world', () => {
    const h = searchHarness();
    h.context.sendKey = key => {
        h.keys.push(key);
        if (key === 0x28) { h.menu.active = 0; h.raw.g_hdMenuActive = 0; h.raw.g_hdMapPick = 1; h.raw.g_hdMapInputSeq++; }
    };
    const target = h.backButton; dispatch(h, 'pointerdown', target); dispatch(h, 'click', target, {detail: 1});
    assert.equal(h.hud.state.personDetail, null); assert.equal(h.hud.state.open, true);
    h.poll(); assert.equal(h.hud.state.open, true, 'No map ACK before the queued native Exit');
    runBackQueue(h); h.poll();
    assert.deepEqual(h.keys, [0x28]); assert.equal(h.hud.state.open, false); assert.deepEqual(h.writes, []);
});

test('SEARCH Back refuses a report-held picker and a queued Exit retires on seq/generation/ID changes', () => {
    for (const change of [h => { h.menu.seq++; h.raw.g_hdMenuSeq++; },
        h => { h.menu.detailGeneration++; h.raw.g_hdDetailGeneration++; }, h => { h.menu.ids.reverse(); },
        h => { h.report.active = 1; h.raw.g_hdReportActive = 1; }]) {
        const h = searchHarness(); h.hud.back(); change(h); runBackQueue(h);
        assert.deepEqual(h.keys, []); assert.deepEqual(h.writes, []);
    }
    const h = searchHarness(); h.report.active = 1; h.raw.g_hdReportActive = 1;
    h.hud.back(); assert.equal(h.hud.state.layer, 'deep'); assert.deepEqual(h.keys, []); assert.deepEqual(h.writes, []);
});
// END R17 SEARCH INCREMENT
