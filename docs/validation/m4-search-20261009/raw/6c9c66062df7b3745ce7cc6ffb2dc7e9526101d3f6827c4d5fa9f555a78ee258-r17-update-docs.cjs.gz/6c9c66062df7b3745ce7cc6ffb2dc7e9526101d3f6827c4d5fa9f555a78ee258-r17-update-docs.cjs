const fs = require('node:fs');
const assert = require('node:assert/strict');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const record = JSON.parse(fs.readFileSync(path.join(root, 'docs/validation/m4-search-20261009.json'), 'utf8'));
assert.equal(record.accepted, true);
assert.equal(record.globalHdComplete, false);
const amend = (file, change) => {
  const p = path.join(root, file), old = fs.readFileSync(p, 'utf8');
  assert.ok(!old.includes('## 2026-10-09：SEARCH3人物列表与原生搜寻订单'), 'Do not append a duplicate milestone');
  fs.writeFileSync(p, change(old), 'utf8');
};
const detailCount = record.actual.detailChecks;
const failures = record.attempts.filter(a => !a.ok).length;
const section = '\n\n## 2026-10-09：SEARCH3人物列表与原生搜寻订单\n\n' +
  '内政搜寻现复用高清人物列表，按当前原生 CITY/PERSON 菜单的完整 U16 编号、顺序与高亮显示详情；名单未到达时不预填居民。报告、帮助、数量和菜单换代会退休旧点击及待发方向键，最终发键再次核对当前输入层与菜单。拒绝确认后仍允许点击当前人物。\n\n' +
  `独立私局以标准时期2刘表/襄阳26验证真实搜寻。1080p与720p共${detailCount}次实际详情观察核对15项数据、当前画像来源和可见性；沿用原生24×24参考图，本批未生成新立绘。选择蒯良110后真实体力减8、金钱不变；原生台词先于订单，玩家确认后新增SEARCH3订单并从当前队列移除该人物。旧DOM按钮在报告期间和新名单出现后均零键；返回等待真实菜单退休及地图回执，无额外EXIT。未执行月份或声称搜寻取得人物。\n\n` +
  `Windows完整713项、人物HUD65项通过，0失败/跳过；新增21项回归。${failures}次先前私局失败及最终通过的原始结果分别保留，脚本入口错误不算产品或高清通过。最终${record.sourceVerification.count}份来源零漂移，128份原生内容与既有编译来源9ca9c408/modified=true保持；城池菜单缓存20261009x。全部本批实际PNG和原始报告/输入/源码按原字节归档，见[搜寻专项](validation/m4-search-20261009.json)及[归档索引](validation/m4-search-20261009/runtime-index.json)。\n\n` +
  '下一批补人物列表原生属性标题、值与显式分页，重点核对标准13列和实际sc-mod的12列自定义输出；保留完整视觉、其它28攻击组合、其它计谋/状态、过河、继任、完整战役与存档、固定设备性能、移动横屏及云账号待办。搜寻命令SEARCH3不等同人物/道具菜单的SEARCH/HELP翻页。\n';
amend('docs/hd-remaining-work.md', text => {
  text = text.replace('资金耗尽旧征兵面板返回零键、分配取消后的地图回执退壳已修；完整视觉仍为 partial', '资金耗尽旧征兵面板返回零键、分配取消后的地图回执退壳已修；SEARCH3高清名单、原生订单/报告及返回已验；完整视觉仍为 partial');
  text = text.replace('[返回专项](validation/m4-city-back-20261009.json) | 本机当前返回路径已验', '[返回专项](validation/m4-city-back-20261009.json)、[搜寻专项](validation/m4-search-20261009.json) | 本机当前返回与搜寻路径已验');
  text = text.replace('继续核查人物/道具 SEARCH/HELP 图文与实际 Mod 完整场景', '继续核查人物/道具菜单 SEARCH/HELP 翻页与实际 Mod 完整场景；内政搜寻SEARCH3名单已另验，不能代替这些属性页');
  text = text.replace('奇门接入后Windows692/692，0失败/跳过，并行4；native与引擎四件未改', '搜寻人物HD接入后Windows713/713，0失败/跳过，并行4；native与引擎四件未改');
  text = text.replace('PC缓存20261009w | 奇门最终来源', `PC全局缓存20261009w/城池菜单20261009x | 搜寻${record.sourceVerification.count}来源0漂移，[搜寻](validation/m4-search-20261009.json)；奇门最终来源`);
  text = text.replace('下一批推进搜寻人物列表HD：当前SEARCH3仍为原生LCD', '该批完成时，下一批计划推进搜寻人物列表HD：SEARCH3当时仍为原生LCD');
  return text + section;
});
amend('docs/hd-development-plan.md', text => text.replace('下一批是SEARCH3人物列表HD及真实名单、取消/报告归属验证。', '该批结束时，下一批计划为SEARCH3人物列表HD及真实名单、取消/报告归属验证。') + section);
console.log('Updated remaining-work and development-plan with accepted R17 scope');
