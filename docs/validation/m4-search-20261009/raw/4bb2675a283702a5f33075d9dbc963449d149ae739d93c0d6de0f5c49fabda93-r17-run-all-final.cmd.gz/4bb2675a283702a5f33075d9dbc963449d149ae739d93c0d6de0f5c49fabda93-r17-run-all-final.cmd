@echo off
call "F:\env\vs\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
set "CC=F:\project\baye-sanguo\build\toolchain\emsdk\upstream\bin\clang.exe"
node --test --test-concurrency=4 scripts/test-hd-input.mjs scripts/test-hd-battle-mode.mjs scripts/test-hd-battle-commands.mjs scripts/test-hd-march.mjs scripts/test-hd-city-entry.mjs scripts/test-hd-engine-protocol.mjs scripts/test-hd-dialog-routing.mjs scripts/test-hd-portraits.mjs scripts/test-hd-campaign-flow.mjs scripts/test-hd-campaign-engine.mjs scripts/test-hd-save-transaction.mjs scripts/test-hd-saveload-ui.mjs scripts/test-hd-save-pages.mjs scripts/test-hd-campaign-telemetry.mjs scripts/test-hd-render-visibility.mjs scripts/test-hd-performance-metrics.mjs scripts/test-hd-road-presentation.mjs scripts/test-hd-battle-terrain.mjs scripts/test-hd-battle-feedback.mjs scripts/test-hd-spe.mjs scripts/test-hd-spe-engine.mjs scripts/test-hd-maker-engine.mjs scripts/test-hd-maker-bridge.mjs scripts/test-hd-attack-engine.mjs scripts/test-hd-attack-bridge.mjs scripts/test-hd-skill-engine.mjs scripts/test-hd-skill-bridge.mjs scripts/test-hd-lib-identity.mjs scripts/test-hd-overworld-identity.mjs scripts/test-hd-ownership.mjs scripts/test-hd-city-hud.mjs scripts/test-hd-idb-mod-compat.mjs scripts/test-hd-details-engine.mjs scripts/test-hd-details-bridge.mjs scripts/test-hd-overviews-engine.mjs scripts/test-hd-overviews-bridge.mjs scripts/test-hd-minimap.mjs scripts/test-hd-overworld-layers.mjs scripts/test-hd-overworld-environment.mjs > build/r17-all-tests-final.log 2>&1
exit /b %errorlevel%


