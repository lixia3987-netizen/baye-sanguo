const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const target = path.join(root, 'docs/validation/m4-search-20261009');
const actualDir = process.argv[2] || 'build/r17-search-hd-installed-v1';
const read = p => JSON.parse(fs.readFileSync(path.join(root, p), 'utf8'));
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
const result = read(actualDir + '/result.json');
assert.equal(result.ok, true);
assert.equal(result.hdAccepted, true);
assert.equal(result.sourceVerification.ok, true);
assert.equal(result.isolation.cleaned, true);
assert.ok(!fs.existsSync(path.join(target, 'runtime-index.json')), 'Preserve every prior archive');
fs.mkdirSync(path.join(target, 'raw'), {recursive: true});
fs.mkdirSync(path.join(target, 'screenshots'), {recursive: true});
const all = new Set();
function addDirectory(dir) {
  for (const e of fs.readdirSync(path.join(root, dir), {withFileTypes: true})) {
    const p = dir + '/' + e.name;
    if (e.isDirectory()) addDirectory(p);
    else if (/\.(json|log|mjs|cjs|txt|cmd|patch|png)$/.test(p)) all.add(p);
  }
}
for (const e of fs.readdirSync(path.join(root, 'build'), {withFileTypes: true})) {
  if (!e.name.startsWith('r17-') && e.name !== 'r18-next-hd-plan.json') continue;
  if (e.isDirectory()) addDirectory('build/' + e.name);
  else if (/\.(json|log|mjs|cjs|txt|cmd|patch)$/.test(e.name)) all.add('build/' + e.name);
}
for (const p of ['scripts/test-hd-search-runtime.mjs', 'scripts/test-hd-city-hud.mjs', 'js/hd-city-menu.js', 'pc.html', 'package.json', 'js/baye.build.json']) all.add(p);
const entries = [];
for (const source of [...all].sort()) {
  const bytes = fs.readFileSync(path.join(root, source)), sha256 = hash(bytes), png = source.endsWith('.png');
  const relative = (png ? 'screenshots/' : 'raw/') + sha256 + '-' + path.basename(source) + (png ? '' : '.gz');
  const output = path.join(target, relative);
  if (!fs.existsSync(output)) fs.writeFileSync(output, png ? bytes : zlib.gzipSync(bytes, {level: 9}));
  const archived = fs.readFileSync(output), restored = png ? archived : zlib.gunzipSync(archived);
  assert.equal(hash(restored), sha256);
  assert.equal(restored.length, bytes.length);
  entries.push({source, archived: relative, bytes: bytes.length, sha256, storedBytes: archived.length, storedSha256: hash(archived), encoding: png ? 'original PNG bytes' : 'gzip of original bytes'});
}
fs.writeFileSync(path.join(target, 'runtime-index.json'), JSON.stringify({schemaVersion: 1, createdAt: new Date().toISOString(), actualDir, completeLocalRuntimePngs: true, omittedPngs: [], entries}, null, 2) + '\n');
const source = p => {const b = fs.readFileSync(path.join(root, p)); return {path: p, bytes: b.length, sha256: hash(b)};};
const worldSummary = w => ({keys: w.keys, period: w.period, playerKing: w.playerKing, cityBelong: w.cityBelong, money: w.money, food: w.food, reserve: w.reserve, queue: w.queue, orders: w.orders, date: w.date, cursor: w.cursor, observedPersons: w.persons.length, actor: w.persons[result.searchOrder.personIndex]});
const order = result.searchOrder, returned = result.returnToMap;
const searchSummary = {...order, before: worldSummary(order.before), atReport: worldSummary(order.atReport), after: worldSummary(order.after)};
const returnSummary = {...returned, before: worldSummary(returned.before), after: worldSummary(returned.after)};
const staleSummary = result.staleChecks.map(c => ({label: c.label, method: c.method, before: worldSummary(c.before), after: worldSummary(c.after)}));
const attempts = fs.readdirSync(path.join(root, 'build'), {withFileTypes: true})
  .filter(e => e.isDirectory() && e.name.startsWith('r17-search-hd-installed-') && fs.existsSync(path.join(root, 'build', e.name, 'result.json')))
  .map(e => {const directory = 'build/' + e.name, r = read(directory + '/result.json'); return {directory, result: source(directory + '/result.json'), ok: r.ok, hdAccepted: r.hdAccepted, runner: r.tool, checkpoints: r.phases.length, engineInputs: (r.engineInputs || []).length, exceptionCount: r.exceptions.length, error: r.error || null, sourceOk: r.sourceVerification.ok, isolation: r.isolation};});
const docs = {
  schemaVersion: 1, batch: 'R17 SEARCH3 city person list HD', accepted: true, globalHdComplete: false,
  baseRevision: '4dd7fd8a2ee7ef4ae26fda9cff9dcb6d773dc41c',
  idConventions: {personIndex: 'Actual native U16 zero-based PersonID: menu IDs, report.person and order.Person all use 110 for KuaiLiang.', legacyRawNativeId: 'The raw runner nativeId field inherits an older one-based display number convention (111); it is not the native command ID and is never sent to the engine.'},
  scope: 'PC standard P2 LiuBiao / XiangYang26 SEARCH list, native actor details and portrait reference, actual order speech/ACK/filter, current-owner input, cancellation and map retirement at 1920x1080 and 1280x720.',
  changes: ['SEARCH route now reuses native person panel', 'Pending selection retires on report/help/quantity or changed native owner', 'Final send samples the native menu after potentially reentrant overlay readers', 'Rejected confirmation restores previous commit marker', 'City-menu script cache 20261009x'],
  production: ['js/hd-city-menu.js', 'pc.html'].map(source),
  runner: source('scripts/test-hd-search-runtime.mjs'),
  attempts,
  tests: {windowsFull: {passed: 713, failed: 0, skipped: 0, log: 'build/r17-all-tests-final.log'}, cityHud: {passed: 65, failed: 0, skipped: 0, log: 'build/r17-city-hud-final-published.log'}, newCases: 21, originalRegression: {passed: 8, failed: 3, log: 'build/r17-search-unit-before.log', scope: 'Offline production-controller VM, not a browser attempt'}},
  actual: {directory: actualDir, result: source(actualDir + '/result.json'), runner: result.tool, startedAt: result.startedAt, finishedAt: result.finishedAt, checkpoints: result.phases.length, detailChecks: result.detailChecks.length, viewports: result.viewports, viewportChecks: result.viewportChecks, fontValidation: result.fontValidation, selection: searchSummary, returnToMap: returnSummary, staleChecks: staleSummary, engineInputCount: result.engineInputs.length, exceptions: result.exceptions, dialogs: result.dialogs, observerErrors: result.observerErrors, isolation: result.isolation},
  sourceVerification: {ok: result.sourceVerification.ok, count: result.sourceVerification.count, drift: result.sourceVerification.drift, added: result.sourceVerification.added},
  nativeSource: {count: result.nativeSourceCheck.count, aggregate: result.nativeSourceCheck.aggregate, compiledRevision: result.engineManifest.sourceRevision, engineSourceModified: result.engineManifest.engineSourceModified},
  assets: {newGeneratedImages: 0, note: 'Existing native 24x24 portrait refs inside the HD person pane; no new HD portrait art or claim of full character art completion. LIB, SPE manifest, native sources and engine quartet unchanged.'},
  archived: {index: 'm4-search-20261009/runtime-index.json', originalBytesVerified: true, entries: entries.length, pngCount: entries.filter(e => e.encoding === 'original PNG bytes').length, allActualPngsIncluded: true},
  notRun: ['Native month execution, SEARCH finding or acquisition RNG', 'Full Mod person properties and campaign/save matrices', 'Other 28 attack combinations and other unverified spells/states', 'Mobile physical device, cloud account, fixed performance and complete visual art'],
  next: {plan: 'build/r18-next-hd-plan.json', focus: 'Capture and display actual selected-person native property titles/values/pages, including the specific sc-mod person hooks. R17 does not claim this is implemented.'}
};
fs.writeFileSync(path.join(root, 'docs/validation/m4-search-20261009.json'), JSON.stringify(docs, null, 2) + '\n');
fs.writeFileSync(path.join(target, 'README.md'), '# 搜寻人物列表 HD 验收\n\n[专项记录](../m4-search-20261009.json)与[runtime-index.json](runtime-index.json)记录每个原始文件的路径、字节数和 SHA256。raw 为原字节 gzip，screenshots 为原 PNG；本批实际运行目录的全部 PNG 都已收录。\n\n只读预检、旧判据诊断和 Node/VM 回归分别保存，不算实际游戏运行。compiledRevision 和 engineSourceModified 保持安装引擎原始来源。后续独立归档/实机审计写在本目录，其审计文件不会被追溯加入先前索引。\n');
console.log(JSON.stringify({entries: entries.length, pngs: docs.archived.pngCount, main: 'docs/validation/m4-search-20261009.json'}));
