import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
const base='build/water-window-20261011',stem='m5-water-window-20261011';
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=args=>execFileSync('git',args);
const suite=read(base+'/final-suite-v2/result.json'),first=read(base+'/final-suite/result.json');
assert.equal(suite.exitCode,0);assert.equal(suite.modules,89);assert.equal(suite.sourceDrift.length,0);
assert.equal(suite.counts.tests,suite.counts.pass);
for(const key of ['fail','cancelled','skipped','todo'])assert.equal(suite.counts[key],0);
assert.equal(first.counts.fail,15);assert.equal(first.sourceDrift.length,0);
for(const s of suite.sources){const b=fs.readFileSync(s.path);assert.equal(b.length,s.bytes,s.path);assert.equal(sha(b),s.sha256,s.path);}
const products=read(base+'/water12-product-final-freeze-v1.json');
for(const p of products.products){const b=fs.readFileSync(p.path);assert.equal(b.length,p.bytes,p.path);assert.equal(sha(b),p.sha256,p.path);}
const manifest=read('assets/hd-spe/manifest.json');
const previous=JSON.parse(git(['show','HEAD:assets/hd-spe/manifest.json']).toString('utf8'));
assert.equal(previous.entries.length,53);assert.equal(manifest.entries.length,54);
assert.deepEqual(manifest.entries.slice(0,53),previous.entries);
const {entries:oldEntries,...oldTop}=previous,{entries:newEntries,...newTop}=manifest;
assert.deepEqual(newTop,oldTop);assert.equal(manifest.entries.at(-1).waterVersion,1);
const nativeFiles=git(['ls-files','-z','vendor/iBaye']).toString('utf8').split('\0').filter(Boolean).sort();
const hash=crypto.createHash('sha256');
for(const file of nativeFiles){hash.update(file+'\0');hash.update(fs.readFileSync(file));}
const nativeAggregate=hash.digest('hex'),build=read('js/baye.build.json');
assert.equal(nativeFiles.length,128);assert.equal(nativeAggregate,build.engineSourceSha256);
assert.equal(nativeAggregate,'713f2425551f3fbf3b9f0f892eeada969161c070c465e159f4126f1dd1944d9d');
const nativeChanged=git(['diff','--name-only','--','vendor/iBaye','js/baye.js','js/baye.wasm','js/baye.wasm.map','js/baye.build.json']).toString('utf8').trim();
assert.equal(nativeChanged,'');
for(const name of ['baye.js','baye.wasm','baye.wasm.map']){const b=fs.readFileSync('js/'+name);assert.equal(b.length,build.artifacts[name].bytes);assert.equal(sha(b),build.artifacts[name].sha256);}
const frontend=read(base+'/frontend-tests-freeze-v1.json');
assert.equal(frontend.results.passed,304);assert.equal(frontend.results.water12NewTests,53);
const preparation=read(base+'/runtime-safety-preparation-v1.json');
const service=read(base+'/user-service-verification.json');
assert.equal(service.ProcessId,57860);assert.equal(service.CreationUtc,'2026-10-10T11:26:04.2797180Z');assert.equal(service.httpStatus,200);
const parseCounts=file=>{const text=fs.readFileSync(file,'utf8'),counts={};for(const key of ['tests','pass','fail','cancelled','skipped','todo'])counts[key]=Number(text.match(new RegExp('(?:ℹ|#) '+key+' (\\d+)'))?.[1]??NaN);return counts;};
const nativeCounts=parseCounts(base+'/native-shared-fixtures-v2.log');assert.equal(nativeCounts.pass,67);assert.equal(nativeCounts.fail,0);
fs.copyFileSync('build/hd-battle-scene-20261011/run-final-suite.mjs',base+'/run-final-suite-executed.mjs');
const summary={schemaVersion:1,recordedAt:new Date().toISOString(),status:'source-validated-runtime-pending',globalHdComplete:false,
 native:{changed:false,rebuilt:false,count:nativeFiles.length,aggregate:nativeAggregate},
 manifest:{previousEntries:53,entries:54,oldEntriesAndOrderUnchanged:true,topLevelUnchanged:true},
 product:products.products,defaultSuite:{modules:suite.modules,...suite.counts,sourceCount:suite.sources.length,sourceDrift:[]},
 addedTests:{spe:17,skillBridge:36,mobileControlledVm:10,compiledNativeFixture:2,total:65},
 targeted:{frontend:frontend.results,compiledNativeThreeModules:nativeCounts},
 initialFullSuite:{...first.counts,sourceDrift:[],cause:'The WATER fixture edit broke WOOD source customization anchors and reused modes24. Restore the shared setup/selector and reserve WATER modes91/92. No native or runtime product edits were needed.'},
 actualRuntime:{executed:false,preflightExecuted:false,pc1080:'pending',pc720:'pending',missingAssets:'pending',classic:'pending',mobileBrowser:'pending',device:'pending'},
 userService:service,limits:['Controlled VM and compiled C fixtures are not playable browser acceptance.','11264 outside pixels is the geometric window count, not a new actual browser pixel-equivalence result.','Terrain outside the effect remains native LCD; complete HD and other skills remain partial.','Runtime and cleanup scripts are prepared; no execution or owned-process cleanup is claimed in this batch.'],
 runtimePreparationProof:base+'/runtime-safety-preparation-v1.json'};
fs.writeFileSync(base+'/batch-summary.json',JSON.stringify(summary,null,2)+'\n');
execFileSync(process.execPath,[base+'/archive.mjs'],{stdio:'inherit'});
const archive=read('docs/validation/'+stem+'-archive.json');
const evidence=source=>{const e=archive.entries.find(e=>e.source===source);assert.ok(e,source);return e;};
const sources=[base+'/batch-summary.json',base+'/final-suite-v2/result.json',base+'/final-suite-v2/test-output.log',base+'/final-suite/result.json',base+'/final-suite/test-output.log',base+'/frontend-tests-freeze-v1.json',base+'/native-shared-fixtures-v2.log',base+'/runtime-safety-preparation-v1.json',base+'/water12-product-final-freeze-v1.json',base+'/water12-product-forward-inverse-delta-v1.json',base+'/user-service-verification.json'];
const result={...summary,evidence:sources.map(evidence),archive:stem+'-archive.json',archiveUniqueFiles:new Set(archive.entries.map(e=>e.file)).size};
fs.writeFileSync('docs/validation/'+stem+'.json',JSON.stringify(result,null,2)+'\n');
const md=`# 原版水淹高清窗口：源码验证检查点（2026-10-11）

按用户“当前已修改的内容提交并推送”要求提交当前阶段。WATER36／技能12保留完整160×96原版LCD底图，只在实际64×64@48,16范围重放已显示图片及清除；数字、原生标签和等待继续跟随真实会话。新增独立waterVersion1清单项，旧53项及顺序、顶层字段完整保持；共享36的海啸19继续原路径，未新增素材或原生构建。

错误清单、未知技能上下文、缺图、经典模式与数据对象失效均保留完整LCD，不借旧130像素裁剪。桥中补齐WATER数字阶段最终数据对象一致性检查；PC与移动页面缓存版本更新。窗口外11264像素仅是几何范围计数，本批没有新的实际浏览器像素等价证明。

新增65项受控用例：前端17、桥36、移动VM10、编译C夹具2。前端两模块304／304通过；编译技能、SPE及滚木三模块67／67通过。最终默认${suite.modules}模块串行 **${suite.counts.pass}／${suite.counts.tests}通过**，失败／取消／跳过／todo均0，${suite.sources.length}份执行来源无漂移。

首轮完整回归4389通过、15失败，均由新增水淹夹具破坏滚木共用源码替换锚点及复用mode24造成；恢复原有锚点并独立使用91／92后，三模块专项及最终默认套件通过。首轮与最终执行日志、冻结来源和前端先期失败均保留；未将失败覆盖为成功。

运行器已准备独立1080、720、缺图及经典场景，并收紧参数、新目录、进程身份及完整LCD检查。本批 **未执行实际预检或游戏内施放**，以上四项均pending；移动VM与编译C夹具也不替代手机浏览器或真机验收。之前水淹历史实战及FIRE历史记录保留其原范围，不作为本次新窗口的实际验收。

128份原生来源聚合仍为\`${nativeAggregate}\`，与安装构建清单一致，引擎四件无修改；用户8080服务身份与HTTP200核验保持。本批没有启动私有游戏服务或浏览器，因此不声明执行了新游戏局的清理。完整HD仍为partial，globalHdComplete=false；下一步执行本次WATER窗口的正常、720、缺图与经典实际验收。

[结构化结果](${stem}.json) · [原始日志与来源归档](${stem}-archive.json)
`;
fs.writeFileSync('docs/validation/'+stem+'.md',md);
const latest=`2026-10-11 最新[原版WATER12高清窗口源码检查点](validation/${stem}.md)：水淹36／技能12保留完整160×96原版底图，只替换实际64×64@48,16范围，数字与等待跟随原生会话；新增独立清单项，旧53项及共享海啸19保持，无新素材或native构建。新增65项受控用例（17前端／36桥／10移动VM／2编译C），最终89模块串行 **${suite.counts.pass}／${suite.counts.tests}通过**，失败／取消／跳过／todo均0，${suite.sources.length}执行来源无漂移。首轮共用夹具引起的15项失败及修复记录保留。按用户要求先提交当前阶段；正常1080／720、缺图及经典实际浏览器施放均pending，未执行预检，完整HD保持 **partial**。`;
for(const file of ['docs/hd-remaining-work.md','docs/hd-development-plan.md']){
 let content=fs.readFileSync(file,'utf8');assert.ok(!content.includes('最新[原版WATER12高清窗口源码检查点]'));
 content=content.replace('2026-10-11 最新[原版FIRE5','2026-10-11 前批[原版FIRE5');
 const position=content.indexOf('\n');content=content.slice(0,position+1)+'\r\n'+latest+'\r\n'+content.slice(position+1);
 fs.writeFileSync(file,content);
}
console.log(JSON.stringify({tests:summary.defaultSuite,status:summary.status,archive:result.archiveUniqueFiles,native:summary.native}));
