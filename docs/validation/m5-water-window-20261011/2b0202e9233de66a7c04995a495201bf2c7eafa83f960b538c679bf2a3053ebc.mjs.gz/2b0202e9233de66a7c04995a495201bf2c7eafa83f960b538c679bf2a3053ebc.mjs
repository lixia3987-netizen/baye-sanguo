import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
const base='build/water-window-20261011',stem='m5-water-window-20261011',target='docs/validation/'+stem;
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const files=new Set();
for(const name of fs.readdirSync(base)){
 const directory=path.join(base,name);
 if(fs.statSync(directory).isFile()){if(/\.(json|jsonl|log|mjs|ps1)$/.test(name))files.add(directory);continue;}
 for(const item of fs.readdirSync(directory)){
  const file=path.join(directory,item);if(fs.statSync(file).isFile()&&/\.(json|jsonl|log|mjs)$/.test(item))files.add(file);
 }
 const result=path.join(directory,'result.json');
 if(fs.existsSync(result)){
  const r=read(result),captures=r.skillCaptures||[],movie=captures.filter(c=>c.spe?.active&&c.spe.id===36&&c.spe.skillId===12),
   numeric=captures.filter(c=>c.result?.active&&c.result.skillId===12&&c.result.phase==='numbers'),
   hold=captures.filter(c=>c.result?.active&&c.result.skillId===12&&c.result.phase==='hold');
  for(const capture of [movie[0],movie.at(-1),numeric[0],hold.at(-1)].filter(Boolean))for(const key of ['nativeFile','hdFile']){
   const ref=capture[key];if(ref){const file=path.join(directory,ref.file),b=fs.readFileSync(file);
    if(b.length!==ref.bytes||sha(b)!==ref.sha256)throw Error('Selected checkpoint differs: '+file);files.add(file);}
  }
  for(const name of ['failure.png','31-real-skill-result-retired.png']){const file=path.join(directory,name);if(fs.existsSync(file))files.add(file);}
 }
 const frozen=path.join(directory,'frozen-sources');
 if(fs.existsSync(frozen))for(const name of fs.readdirSync(frozen)){const file=path.join(frozen,name);if(fs.statSync(file).isFile())files.add(file);}
}
fs.mkdirSync(target,{recursive:true});const entries=[];
for(const source of [...files].sort()){
 const raw=fs.readFileSync(source),hash=sha(raw),name=hash+path.extname(source)+'.gz',destination=path.join(target,name);
 if(!fs.existsSync(destination))fs.writeFileSync(destination,zlib.gzipSync(raw,{level:9}),{flag:'wx'});
 const gzip=fs.readFileSync(destination),roundtrip=zlib.gunzipSync(gzip);
 if(roundtrip.length!==raw.length||sha(roundtrip)!==hash)throw Error('Archive roundtrip differs: '+source);
 entries.push({source:source.replaceAll('\\','/'),file:stem+'/'+name,rawBytes:raw.length,rawSha256:hash,bytes:gzip.length,sha256:sha(gzip)});
}
const result={schemaVersion:1,createdAt:new Date().toISOString(),scope:'WATER12 source checkpoint: product/test freeze and delta, preparation checks, initial failures and final default-suite logs, executed suite/archive/document tools and frozen sources. No actual WATER browser run or screenshots were produced in this batch. Prepared runtime/cleanup tools are archived as preparation only; no execution is claimed.',entries};
fs.writeFileSync('docs/validation/'+stem+'-archive.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({files:entries.length,unique:new Set(entries.map(e=>e.file)).size,rawBytes:entries.reduce((n,e)=>n+e.rawBytes,0),bytes:entries.reduce((n,e)=>n+e.bytes,0)}));

