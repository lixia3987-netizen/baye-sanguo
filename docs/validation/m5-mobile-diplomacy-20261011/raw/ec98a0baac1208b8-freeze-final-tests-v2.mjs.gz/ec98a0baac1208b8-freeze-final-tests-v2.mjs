import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
const out='build/mobile-diplomacy-validation-20261011/final-suite-v2',sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const command=JSON.parse(fs.readFileSync('package.json')).scripts.test,files=command.split(' ').slice(2);
fs.mkdirSync(out+'/frozen-tests',{recursive:true});
const entries=files.map(file=>{const b=fs.readFileSync(file),h=sha(b),name=h+path.extname(file);fs.writeFileSync(out+'/frozen-tests/'+name,b,{flag:'wx'});return {path:file,bytes:b.length,sha256:h,file:'frozen-tests/'+name};});
fs.writeFileSync(out+'/final-test-sources.json',JSON.stringify({at:new Date().toISOString(),command,executionConcurrency:1,node:process.version,modules:entries.length,files:entries},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({modules:entries.length,bytes:entries.reduce((n,e)=>n+e.bytes,0)}));

