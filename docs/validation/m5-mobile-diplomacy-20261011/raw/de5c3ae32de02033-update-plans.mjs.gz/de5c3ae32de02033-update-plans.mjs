import fs from 'node:fs';
import assert from 'node:assert/strict';
const v=JSON.parse(fs.readFileSync('docs/validation/m5-mobile-diplomacy-20261011.json','utf8'));
assert.equal(v.accepted,true);assert.equal(v.tests.full.pass,3533);
const note='2026-10-11 追加[原版移动外交人物选择](validation/m5-mobile-diplomacy-20261011.md)：离间／招揽／策反／劝降区分真实己方执行将领与敌方目标，目标取消等待新己方名单；正常派发后沿原版回执返回地图，不补造战报。暂存844通过后成套安装，两尺寸844×390／667×375各实际提交4次、取消8次、26检查点、78键及0LCD触摸；已采完整世界、原版费用、订单、人物队列与返回HUD核对通过。最终83模块串行3533／3533通过，失败／取消／跳过／todo均0。两次暂存失败及旧源负基线保留，非首项菜单方向键交接已修复。新native128份来源聚合核对一致；月末随机外交结果／归队、其它完整流程、真机和性能仍待，完整HD仍partial，原版唯一入口与暂停版本切换保持。';
for(const file of ['docs/hd-remaining-work.md','docs/hd-development-plan.md','docs/hd-full-replacement-checklist.md']){
 let s=fs.readFileSync(file,'utf8');assert.ok(!s.includes('追加[原版移动外交人物选择]'));const eol=s.includes('\r\n')?'\r\n':'\n';s=s.replace(/\r?\n\r?\n/,eol+eol+note+eol+eol);
 if(file==='docs/hd-remaining-work.md'){
  const r13='| R13 | 原生回归与构建闭环：工具链、测试、产物 | 最终83模块串行3533／3533通过，失败／取消／跳过／todo均0；外交安装两尺寸来源相同且无漂移、0异常。修复前3530项全量及两次暂存失败原件保留 | 本批新native已暂存验证并成套安装；sourceRevision '+v.engine.sourceRevision+'，native128聚合'+v.engine.sourceTree.sha256+'；四件安装产物与暂存逐字节一致 | [外交与3533项回归](validation/m5-mobile-diplomacy-20261011.md)、[概览与3354项历史回归](validation/m5-mobile-minimap-20261011.md)、[输送与3210项历史回归](validation/m5-mobile-transfer-20261011.md)；原始范围与失败保持 | 当前本机限定范围已验；未据串行通过声称默认并行全绿，其它平台／完整行动矩阵继续 |';
  const r14='| R14 | M5 移动横屏 HD：前端、输入、布局 | 仅原版、常用窗口唯一入口及移除版本切换保持。已验限定HUD／地图／城池／人物／数量／报告／战场／系统／存读档、交易、输送／移动及38城概览；新增四外交真实双人物选择，两尺寸各8取消／4派发及更新HUD通过，完整移动HD仍partial | 手机战场HELP／VIEW、外交月末随机结果／归队、其它待办命令与完整流程、真机及性能继续 | [外交验证](validation/m5-mobile-diplomacy-20261011.md)、[概览验证](validation/m5-mobile-minimap-20261011.md)、[输送验证](validation/m5-mobile-transfer-20261011.md)；各批代表本机模拟限定范围 | 本机手机触控模拟限定范围已验；真机与完整HD待 |';
  assert.match(s,/^\| R13 \|.*$/m);assert.match(s,/^\| R14 \|.*$/m);s=s.replace(/^\| R13 \|[^\r\n]*/m,r13).replace(/^\| R14 \|[^\r\n]*/m,r14);
 }
 fs.writeFileSync(file,s);
}
console.log('Updated three HD source-of-truth plans.');
